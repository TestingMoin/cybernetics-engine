from datetime import datetime, timedelta, timezone
from cybernetics.market_data.dhan_rest import DhanMarketDataClient
from cybernetics.market_data.recovery import MarketDataRecoveryPlanner, recover_windows

def test_ltp_groups_by_exchange_segment_and_preserves_client_id():
    calls=[]
    def req(method,url,**kwargs):
        calls.append((method,url,kwargs))
        return {"ok":True}
    c=DhanMarketDataClient(req,"CID")
    out=c.ltp([
        {"ExchangeSegment":"NSE_EQ","SecurityId":"1"},
        {"ExchangeSegment":"NSE_EQ","SecurityId":"2"},
        {"ExchangeSegment":"BSE_EQ","SecurityId":"3"},
    ])
    assert out["ok"] is True
    assert calls[0][0]=="POST"
    assert calls[0][1].endswith("/marketfeed/ltp")
    assert calls[0][2]["json"]["NSE_EQ"]==["1","2"]
    assert calls[0][2]["headers"]["client-id"]=="CID"

def test_quote_rejects_more_than_1000_instruments():
    c=DhanMarketDataClient(lambda *a,**k:{})
    instruments=[{"ExchangeSegment":"NSE_EQ","SecurityId":str(i)} for i in range(1001)]
    try:
        c.quote(instruments); assert False
    except ValueError as e:
        assert str(e)=="market_quote_instrument_limit_exceeded"

def test_historical_requires_core_fields():
    c=DhanMarketDataClient(lambda *a,**k:{})
    try:
        c.historical({"securityId":"1"}); assert False
    except ValueError as e:
        assert "historical_missing" in str(e)

def test_intraday_interval_validation():
    c=DhanMarketDataClient(lambda *a,**k:{})
    payload={"securityId":"1","exchangeSegment":"NSE_EQ","instrument":"EQUITY",
             "interval":"2","fromDate":"2026-01-01","toDate":"2026-01-02"}
    try:
        c.intraday(payload); assert False
    except ValueError as e:
        assert str(e)=="intraday_interval_unsupported"

def test_recovery_planner_splits_at_90_days():
    p=MarketDataRecoveryPlanner()
    start=datetime(2026,1,1,tzinfo=timezone.utc)
    end=start+timedelta(days=181)
    plan=p.plan(start,end,"1")
    assert len(plan.windows)==3
    assert (plan.windows[0].end-plan.windows[0].start).days==90
    assert plan.windows[-1].end==end

def test_recovery_windows_are_ordered_and_non_overlapping():
    p=MarketDataRecoveryPlanner()
    start=datetime(2026,1,1,tzinfo=timezone.utc)
    end=start+timedelta(days=181)
    plan=p.plan(start,end)
    for a,b in zip(plan.windows,plan.windows[1:]):
        assert a.end==b.start

def test_recover_windows_calls_fetch_for_each_window():
    p=MarketDataRecoveryPlanner(max_days=2)
    start=datetime(2026,1,1,tzinfo=timezone.utc)
    plan=p.plan(start,start+timedelta(days=5))
    seen=[]
    out=recover_windows(plan,lambda w,i:(w.start,w.end,i))
    assert len(out)==3
    assert out[0][2]=="1"
    assert len(seen)==0

def test_empty_quote_list_is_rejected():
    c=DhanMarketDataClient(lambda *a,**k:{})
    try:
        c.ohlc([]); assert False
    except ValueError as e:
        assert str(e)=="instruments_required"
