from cybernetics.strategy.lifecycle import *
from cybernetics.trading.bridge import StrategyPositionLifecycleBridge

def setup():
    l=StrategyTradeLifecycle(); b=StrategyLifecycleBook()
    return l,b,StrategyPositionLifecycleBridge(l,b)

def go(bridge,**kw): return bridge.apply_decision(**kw)

BASE=dict(trade_id="T1",strategy_id="S1",underlying_key="NIFTY",
          signal_id="SIG1")

def test_entry_decision():
    l,b,x=setup()
    r=go(x,**BASE,action="ENTER_LONG")
    assert r.accepted and r.event.state_after==TradeLifecycleState.ENTRY_DECIDED

def test_entry_submission_then_fill():
    l,b,x=setup()
    go(x,**BASE,action="ENTER_LONG")
    go(x,**BASE,action="SUBMIT_ENTRY")
    r=go(x,**BASE,action="FILL")
    assert r.accepted and r.event.state_after==TradeLifecycleState.OPEN

def test_exit_lifecycle():
    l,b,x=setup()
    go(x,**BASE,action="ENTER_LONG")
    go(x,**BASE,action="SUBMIT_ENTRY")
    go(x,**BASE,action="FILL")
    go(x,**BASE,action="EXIT_LONG")
    go(x,**BASE,action="SUBMIT_EXIT")
    r=go(x,**BASE,action="FILL")
    assert r.accepted and r.event.state_after==TradeLifecycleState.CLOSED

def test_invalid_direct_fill_from_flat_blocked():
    _,b,x=setup()
    r=go(x,**BASE,action="FILL")
    assert not r.accepted and r.event.state_after==TradeLifecycleState.BLOCKED

def test_duplicate_exit_when_entry_not_open_blocked():
    _,b,x=setup()
    go(x,**BASE,action="ENTER_LONG")
    r=go(x,**BASE,action="EXIT_LONG")
    assert not r.accepted

def test_state_conflict_is_rejected():
    l,b,x=setup()
    r1=go(x,**BASE,action="ENTER_LONG")
    # External/stale event says state was FLAT although current state is ENTRY_DECIDED
    stale=StrategyTradeEvent("T1","S1","NIFTY","ENTER_SHORT",
        TradeLifecycleState.FLAT,TradeLifecycleState.ENTRY_DECIDED,"SIG2","stale")
    try:
        b.apply(stale); assert False
    except ValueError as exc:
        assert str(exc)=="lifecycle_state_conflict"

def test_blocked_transition_not_applied():
    _,b,x=setup()
    r=go(x,**BASE,action="SUBMIT_ENTRY")
    assert not r.accepted and b.state("T1")==TradeLifecycleState.FLAT

def test_independent_trade_lifecycles():
    _,b,x=setup()
    go(x,**BASE,action="ENTER_LONG")
    b2=BASE|{"trade_id":"T2","signal_id":"SIG2"}
    assert go(x,**b2,action="ENTER_SHORT").accepted
    assert b.state("T1")==TradeLifecycleState.ENTRY_DECIDED
    assert b.state("T2")==TradeLifecycleState.ENTRY_DECIDED

def test_closed_trade_can_be_cleared_to_flat():
    _,b,x=setup()
    go(x,**BASE,action="ENTER_LONG"); go(x,**BASE,action="SUBMIT_ENTRY")
    go(x,**BASE,action="FILL"); go(x,**BASE,action="EXIT_LONG")
    go(x,**BASE,action="SUBMIT_EXIT"); go(x,**BASE,action="FILL")
    assert b.state("T1")==TradeLifecycleState.CLOSED
    b.clear("T1")
    assert b.state("T1")==TradeLifecycleState.FLAT

def test_no_broker_fields_in_lifecycle_event():
    _,_,x=setup()
    r=go(x,**BASE,action="ENTER_LONG")
    assert not hasattr(r.event,"broker_order_id")
