from dataclasses import dataclass
from cybernetics.strategy.models import StrategyContext, DecisionType
from cybernetics.strategy.engine import StrategyEngine
from cybernetics.signals.lifecycle import SignalLifecycleManager
from cybernetics.execution.intent import ExecutionIntentBuilder, ExecutionAction, OrderType
from cybernetics.execution.binding import ExecutionIntentInstrumentBinder
from cybernetics.execution.instrument import TradeInstrument
from cybernetics.dhan.payload import DhanOrderPayloadMapper

@dataclass(frozen=True)
class ReconciledExecutionPreview:
    decision: DecisionType
    intent_id: str
    security_id: str
    payload: dict

def build_preview(*, lifecycle, strategy_engine, strategy_id, signal_id,
                  instrument, timestamp, direction, strength, trade_id="TRADE-1"):
    ev=lifecycle.evaluate(signal_id,timestamp)
    if not ev.valid:
        raise PermissionError("signal_not_valid")
    ctx=StrategyContext(signal_id,"ICE-NIFTY",instrument.symbol,"5m",
                        timestamp,direction,strength,{})
    decision=strategy_engine.evaluate(strategy_id,ctx)
    if decision.decision not in {DecisionType.ENTER_LONG,DecisionType.ENTER_SHORT}:
        raise PermissionError("strategy_did_not_create_entry")
    action=ExecutionAction.BUY if decision.decision is DecisionType.ENTER_LONG else ExecutionAction.SELL
    intent=ExecutionIntentBuilder().build(
        approved=True, trade_id=trade_id, strategy_id=decision.strategy_id,
        strategy_version="1.0.0", signal_id=signal_id, underlying_key=instrument.symbol,
        action=action, quantity=instrument.lot_size, order_type=OrderType.MARKET)
    bound=ExecutionIntentInstrumentBinder().bind(intent,instrument)
    payload=DhanOrderPayloadMapper().map(bound,dhan_client_id="CLIENT")
    return ReconciledExecutionPreview(decision.decision,intent.intent_id,
                                      instrument.security_id,payload.as_dict())
