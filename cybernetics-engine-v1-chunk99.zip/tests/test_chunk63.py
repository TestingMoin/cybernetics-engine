import pytest
from cybernetics.trading.atomic_fill import (
    CanonicalFill, FillApplicationCoordinator, FillApplicationState,
    InMemoryFillRegistry
)


class Sink:
    def __init__(self, fail=False):
        self.fail = fail
        self.calls = []

    def mark_fill_applied(self, fill):
        if self.fail:
            raise RuntimeError("order-failure")
        self.calls.append(fill.fill_id)


class PositionSink:
    def __init__(self, fail=False):
        self.fail = fail
        self.calls = []

    def apply_fill(self, fill):
        if self.fail:
            raise RuntimeError("position-failure")
        self.calls.append(fill.fill_id)


class LifecycleSink:
    def __init__(self, fail=False):
        self.fail = fail
        self.calls = []

    def on_fill(self, fill):
        if self.fail:
            raise RuntimeError("lifecycle-failure")
        self.calls.append(fill.fill_id)


def fill(fid="F1"):
    return CanonicalFill(fid, "OID1", "T1", "NIFTY", "BUY", 10, 100, 2)


def coordinator(order=None, position=None, lifecycle=None, registry=None):
    return FillApplicationCoordinator(
        fill_registry=registry or InMemoryFillRegistry(),
        order_sink=order or Sink(),
        position_sink=position or PositionSink(),
        lifecycle_sink=lifecycle or LifecycleSink(),
    )


def test_fill_reaches_all_three_boundaries():
    o, p, l = Sink(), PositionSink(), LifecycleSink()
    r = coordinator(order=o, position=p, lifecycle=l).apply(fill())
    assert r.state == FillApplicationState.APPLIED
    assert o.calls == ["F1"]
    assert p.calls == ["F1"]
    assert l.calls == ["F1"]


def test_completed_fill_is_duplicate():
    reg = InMemoryFillRegistry()
    x = coordinator(registry=reg)
    assert x.apply(fill()).state == FillApplicationState.APPLIED
    assert x.apply(fill()).state == FillApplicationState.DUPLICATE


def test_claimed_fill_requires_recovery():
    reg = InMemoryFillRegistry()
    reg.claim("F1", "OID1", "T1")
    x = coordinator(registry=reg)
    r = x.apply(fill())
    assert r.state == FillApplicationState.RECOVERY_REQUIRED
    assert r.reason == "fill_claimed_but_not_completed"


def test_order_failure_requires_recovery():
    reg = InMemoryFillRegistry()
    o, p, l = Sink(fail=True), PositionSink(), LifecycleSink()
    r = coordinator(order=o, position=p, lifecycle=l, registry=reg).apply(fill())
    assert r.state == FillApplicationState.RECOVERY_REQUIRED
    assert reg.status("F1") == "RECOVERY_REQUIRED"


def test_position_failure_requires_recovery():
    reg = InMemoryFillRegistry()
    o, p, l = Sink(), PositionSink(fail=True), LifecycleSink()
    r = coordinator(order=o, position=p, lifecycle=l, registry=reg).apply(fill())
    assert r.state == FillApplicationState.RECOVERY_REQUIRED
    assert reg.status("F1") == "RECOVERY_REQUIRED"


def test_lifecycle_failure_requires_recovery():
    reg = InMemoryFillRegistry()
    o, p, l = Sink(), PositionSink(), LifecycleSink(fail=True)
    r = coordinator(order=o, position=p, lifecycle=l, registry=reg).apply(fill())
    assert r.state == FillApplicationState.RECOVERY_REQUIRED
    assert reg.status("F1") == "RECOVERY_REQUIRED"


def test_invalid_fill_identity_blocked():
    f = CanonicalFill("", "OID1", "T1", "NIFTY", "BUY", 10, 100)
    r = coordinator().apply(f)
    assert r.state == FillApplicationState.BLOCKED


def test_invalid_quantity_blocked():
    f = CanonicalFill("F1", "OID1", "T1", "NIFTY", "BUY", 0, 100)
    r = coordinator().apply(f)
    assert r.state == FillApplicationState.BLOCKED


def test_invalid_price_blocked():
    f = CanonicalFill("F1", "OID1", "T1", "NIFTY", "BUY", 10, 0)
    r = coordinator().apply(f)
    assert r.state == FillApplicationState.BLOCKED


def test_different_fill_ids_apply_independently():
    o, p, l = Sink(), PositionSink(), LifecycleSink()
    x = coordinator(order=o, position=p, lifecycle=l)
    assert x.apply(fill("F1")).state == FillApplicationState.APPLIED
    assert x.apply(fill("F2")).state == FillApplicationState.APPLIED
    assert o.calls == ["F1", "F2"]
    assert p.calls == ["F1", "F2"]
    assert l.calls == ["F1", "F2"]


def test_failure_does_not_mark_completed():
    reg = InMemoryFillRegistry()
    x = coordinator(position=PositionSink(fail=True), registry=reg)
    x.apply(fill())
    assert reg.status("F1") == "RECOVERY_REQUIRED"
    assert reg.status("F1") != "COMPLETED"


def test_registry_error_is_recoverable_information():
    reg = InMemoryFillRegistry()
    x = coordinator(order=Sink(fail=True), registry=reg)
    x.apply(fill())
    assert reg.error("F1") == "order-failure"


def test_no_automatic_retry_on_failure():
    reg = InMemoryFillRegistry()
    o = Sink(fail=True)
    x = coordinator(order=o, registry=reg)
    first = x.apply(fill())
    assert first.state == FillApplicationState.RECOVERY_REQUIRED
    # A second call is blocked by RECOVERY_REQUIRED state; there is no blind retry.
    second = x.apply(fill())
    assert second.state == FillApplicationState.RECOVERY_REQUIRED
