from cybernetics.persistence.unified_fill import (
    CanonicalFillRecord, FillResult, UnifiedFillProcessorPostgres
)
from cybernetics.persistence.repository import (
    FillPersistenceRepository, FillLedgerRecord, LedgerState
)
from cybernetics.persistence.repository import FillOutboxRecord


class Result:
    def __init__(self, rowcount=1): self.rowcount=rowcount


class FakeTx:
    def __init__(self, claim_row=("F1",), existing=None):
        self.claim_row=claim_row
        self.existing=existing
        self.calls=[]
        self.claimed_once=False
    def fetchone(self, sql, params=()):
        self.calls.append(("fetchone",sql,params))
        if "INSERT INTO fill_ledger" in sql:
            row = self.claim_row
            self.claim_row = None
            return row
        if "SELECT fill_id" in sql:
            return self.existing
        if "INSERT INTO fill_outbox" in sql:
            return ("E1",)
        return None
    def fetchall(self, sql, params=()):
        self.calls.append(("fetchall",sql,params))
        return []
    def execute(self, sql, params=()):
        self.calls.append(("execute",sql,params))
        return Result(1)


class FakeConn:
    def __init__(self, tx=None, explode=False):
        self.tx=tx or FakeTx()
        self.explode=explode
    def transaction(self):
        outer=self
        class Ctx:
            def __enter__(self_inner):
                if outer.explode: raise RuntimeError("db down")
                return outer.tx
            def __exit__(self_inner,*args): return False
        return Ctx()


def fill():
    return CanonicalFillRecord(
        "F1","O1","T1","NIFTY", "BUY", 25, 100.0,
        "2026-09-07T09:15:00Z", {"fill_id":"F1","qty":25}
    )


def test_success_runs_order_position_lifecycle_and_completes():
    tx=FakeTx()
    c=FakeConn(tx)
    seen=[]
    p=UnifiedFillProcessorPostgres(c)
    result=p.process(
        fill(),
        apply_order=lambda f: seen.append("order"),
        apply_position=lambda f: seen.append("position"),
        apply_lifecycle=lambda f: seen.append("lifecycle"),
        event_id="E1",
    )
    assert result is FillResult.COMPLETED
    assert seen==["order","position","lifecycle"]


def test_duplicate_completed_is_not_reprocessed():
    existing=("F1","O1","T1","COMPLETED",None)
    c=FakeConn(FakeTx(claim_row=None, existing=existing))
    seen=[]
    result=UnifiedFillProcessorPostgres(c).process(
        fill(), apply_order=lambda f: seen.append(1),
        apply_position=lambda f: seen.append(2),
        apply_lifecycle=lambda f: seen.append(3), event_id="E1"
    )
    assert result is FillResult.DUPLICATE_COMPLETED
    assert seen==[]


def test_duplicate_recovery_blocks_processing():
    existing=("F1","O1","T1","RECOVERY_REQUIRED","manual")
    c=FakeConn(FakeTx(claim_row=None, existing=existing))
    result=UnifiedFillProcessorPostgres(c).process(
        fill(), apply_order=lambda f: None,
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: None, event_id="E1"
    )
    assert result is FillResult.RECOVERY_REQUIRED


def test_duplicate_claimed_blocks_processing():
    existing=("F1","O1","T1","CLAIMED",None)
    c=FakeConn(FakeTx(claim_row=None, existing=existing))
    result=UnifiedFillProcessorPostgres(c).process(
        fill(), apply_order=lambda f: None,
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: None, event_id="E1"
    )
    assert result is FillResult.DUPLICATE_IN_PROGRESS


def test_order_failure_marks_recovery():
    tx=FakeTx()
    result=UnifiedFillProcessorPostgres(FakeConn(tx)).process(
        fill(),
        apply_order=lambda f: (_ for _ in ()).throw(RuntimeError("order fail")),
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: None,
        event_id="E1",
    )
    assert result is FillResult.RECOVERY_REQUIRED
    assert any(
        "RECOVERY_REQUIRED" in str(call) for call in tx.calls
    )


def test_position_failure_marks_recovery():
    tx=FakeTx()
    result=UnifiedFillProcessorPostgres(FakeConn(tx)).process(
        fill(), apply_order=lambda f: None,
        apply_position=lambda f: (_ for _ in ()).throw(RuntimeError("pos fail")),
        apply_lifecycle=lambda f: None, event_id="E1"
    )
    assert result is FillResult.RECOVERY_REQUIRED


def test_lifecycle_failure_marks_recovery():
    tx=FakeTx()
    result=UnifiedFillProcessorPostgres(FakeConn(tx)).process(
        fill(), apply_order=lambda f: None,
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: (_ for _ in ()).throw(RuntimeError("life fail")),
        event_id="E1"
    )
    assert result is FillResult.RECOVERY_REQUIRED


def test_invalid_fill_is_rejected_before_transaction():
    c=FakeConn()
    bad=fill().__class__(**{**fill().__dict__, "price": 0})
    result=UnifiedFillProcessorPostgres(c).process(
        bad, apply_order=lambda f: None,
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: None, event_id="E1"
    )
    assert result is FillResult.INVALID
    assert c.tx.calls==[]


def test_invalid_quantity_is_rejected():
    c=FakeConn()
    bad=fill().__class__(**{**fill().__dict__, "quantity": 0})
    assert UnifiedFillProcessorPostgres(c).process(
        bad, apply_order=lambda f: None,
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: None, event_id="E1"
    ) is FillResult.INVALID


def test_invalid_side_is_rejected():
    c=FakeConn()
    bad=fill().__class__(**{**fill().__dict__, "side": "HOLD"})
    assert UnifiedFillProcessorPostgres(c).process(
        bad, apply_order=lambda f: None,
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: None, event_id="E1"
    ) is FillResult.INVALID


def test_transaction_failure_does_not_blind_retry():
    c=FakeConn(explode=True)
    seen=[]
    result=UnifiedFillProcessorPostgres(c).process(
        fill(), apply_order=lambda f: seen.append(1),
        apply_position=lambda f: seen.append(2),
        apply_lifecycle=lambda f: seen.append(3), event_id="E1"
    )
    assert result is FillResult.RECOVERY_REQUIRED
    assert seen==[]


def test_outbox_identity_is_part_of_success_path():
    tx=FakeTx()
    result=UnifiedFillProcessorPostgres(FakeConn(tx)).process(
        fill(), apply_order=lambda f: None,
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: None, event_id="E1"
    )
    assert result is FillResult.COMPLETED
    assert any("fill_outbox" in call[1] for call in tx.calls if call[0]=="fetchone")


def test_processor_uses_injected_repository_factory():
    class SpyRepo(FillPersistenceRepository):
        created=0
        def __init__(self, tx):
            super().__init__(tx); SpyRepo.created += 1
    tx=FakeTx()
    result=UnifiedFillProcessorPostgres(
        FakeConn(tx), repository_factory=SpyRepo
    ).process(
        fill(), apply_order=lambda f: None,
        apply_position=lambda f: None,
        apply_lifecycle=lambda f: None, event_id="E1"
    )
    assert result is FillResult.COMPLETED
    assert SpyRepo.created==1


def test_no_broker_endpoint_in_processor_source():
    from pathlib import Path
    src=Path("src/cybernetics/persistence/unified_fill.py").read_text()
    assert "/v2/orders" not in src
    assert "access-token" not in src.lower()
