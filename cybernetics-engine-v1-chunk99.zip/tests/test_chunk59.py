from cybernetics.dhan.order_stream import DhanOrderUpdateProcessor,StreamResult

def p(status="PENDING",ts="2026-09-07 09:30:00",**kw):
    d={"orderId":"OID1","correlationId":"C1","orderStatus":status,
       "filledQty":0,"remainingQuantity":10,"averageTradedPrice":0,
       "LastUpdatedTime":ts}; d.update(kw); return d

def test_first_applies():
    r=DhanOrderUpdateProcessor().process(p()); assert r.result==StreamResult.APPLIED

def test_duplicate():
    x=DhanOrderUpdateProcessor(); x.process(p()); assert x.process(p()).result==StreamResult.DUPLICATE

def test_stale():
    x=DhanOrderUpdateProcessor(); x.process(p(ts="2026-09-07 09:31:00"))
    assert x.process(p("TRANSIT","2026-09-07 09:30:00")).result==StreamResult.STALE

def test_partial():
    x=DhanOrderUpdateProcessor(); x.process(p())
    r=x.process(p("PART_TRADED","2026-09-07 09:30:02",filledQty=4,remainingQuantity=6,averageTradedPrice=101))
    assert r.result==StreamResult.APPLIED and r.lifecycle.state.value=="PARTIAL"

def test_terminal_regression_requires_snapshot():
    x=DhanOrderUpdateProcessor(); x.process(p("TRADED","2026-09-07 09:30:02",filledQty=10,remainingQuantity=0))
    assert x.process(p("PENDING","2026-09-07 09:30:03")).result==StreamResult.SNAPSHOT_REQUIRED

def test_unknown_status_safe():
    r=DhanOrderUpdateProcessor().process(p("FUTURE_STATUS"))
    assert r.result==StreamResult.APPLIED and r.lifecycle.state.value=="UNKNOWN"

def test_missing_order_id_invalid():
    d=p(); d.pop("orderId")
    assert DhanOrderUpdateProcessor().process(d).result==StreamResult.INVALID

def test_missing_timestamp_after_prior_event():
    x=DhanOrderUpdateProcessor(); x.process(p())
    d=p("PART_TRADED",ts=""); d.pop("LastUpdatedTime")
    assert x.process(d).result==StreamResult.SNAPSHOT_REQUIRED

def test_raw_payload_retained():
    d=p(); r=DhanOrderUpdateProcessor().process(d); assert r.event.raw["orderId"]=="OID1"

def test_explicit_event_id_dedup():
    x=DhanOrderUpdateProcessor(); d=p(); d["eventId"]="E1"; x.process(d)
    d2=p("PART_TRADED","2026-09-07 09:30:01",filledQty=2); d2["eventId"]="E1"
    assert x.process(d2).result==StreamResult.DUPLICATE

def test_reset():
    x=DhanOrderUpdateProcessor(); x.process(p()); x.reset(); assert x.process(p()).result==StreamResult.APPLIED

def test_terminal_cancel():
    r=DhanOrderUpdateProcessor().process(p("CANCELLED"))
    assert r.lifecycle.state.value=="CANCELLED" and r.lifecycle.terminal
