# Chunk 91 — Unified Source Integration Reconciliation

The original Chunk 83 unified candidate had 11 collection errors because
several winning files from later reconciliation chunks were not physically
applied to the candidate. A second audit also exposed compatibility conflicts
between early public APIs and later implementations.

Chunk 91 applies and validates the reconciled contracts needed to make the
historical suite executable as one repository.

Major repairs:
- canonical WebSocket subscription/manager modules
- canonical signal lifecycle + qualification
- generic strategy models with Golden-model compatibility
- canonical execution instrument and intent/binding
- canonical Dhan payload mapper
- merged idempotency backend/store contract
- merged signal registry contract
- broker interface preserving BrokerAdapter plus order DTOs
- restored Options and Futures namespaces
- canonical scanner runtime models/registry
- canonical indicator library/registry/standard registry
- canonical fill persistence repository
- canonical control command repository
- legacy risk-sizing compatibility retained beside modern sizing API
- project-level SQL schema path compatibility

Final validation:
compileall PASS
pytest 789/789 PASS

No live Dhan order was submitted. No production database was touched.
The original unified candidate was not mutated; validation used a working copy.
