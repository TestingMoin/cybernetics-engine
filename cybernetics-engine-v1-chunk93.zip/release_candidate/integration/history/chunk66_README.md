# Cybernetics Trading Engine — Chunk 66

## Unified Fill Processing Pipeline

Chunks 63–65 are consolidated conceptually into one canonical application
boundary:

Broker Fill
→ Canonical Fill Record
→ Durable claim
→ Order consumer
→ Position consumer
→ Trade Lifecycle consumer
→ Durable complete

The same `fill_id` must never be independently interpreted by multiple entry
points. All downstream application should originate from this processor.

Failure behavior:

- completed fill → DUPLICATE
- claimed/processing/recovery fill → RECOVERY_REQUIRED
- consumer failure → RECOVERY_REQUIRED
- durable completion failure → RECOVERY_REQUIRED
- invalid fill → BLOCKED

The processor provides deterministic at-least-once processing with durable
idempotency/recovery. It deliberately does not claim distributed exactly-once
semantics because Order Manager, Position Manager and Trade Lifecycle may be
independent state stores.

The reference durability object is in-memory for tests. Production must use
the PostgreSQL fill ledger/outbox boundary from Chunks 64–65.

No broker calls are made in this chunk.
