# Cybernetics Trading Engine — Chunk 26

## Persistent Order Idempotency + Transactional Order Ledger Boundary

This chunk moves order identity from purely in-memory state toward the existing PostgreSQL
persistence layer.

### Core guarantee

`client_order_key` becomes a durable unique identifier.

A process restart can therefore recover the submission identity from PostgreSQL instead of
forgetting which logical order was already submitted.

### Included

- Backend-neutral `IdempotencyStore`.
- In-memory backend for deterministic tests.
- PostgreSQL ledger boundary with parameterized SQL.
- `ON CONFLICT ... DO NOTHING` duplicate protection.
- Transaction commit/rollback handling.
- Schema migration adding a unique `client_order_key` index.
- No credentials or database connection strings are hardcoded.

### Important

This chunk does NOT:
- place live Dhan orders;
- claim distributed locking across a broker fleet;
- resolve an UNKNOWN broker outcome automatically.

UNKNOWN outcomes still require broker reconciliation before a new submission is permitted.
