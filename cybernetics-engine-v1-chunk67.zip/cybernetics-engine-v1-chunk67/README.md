# Cybernetics Trading Engine — Chunk 67

## PostgreSQL Adapter Integration & Migration Boundary

This chunk formalizes database migration/startup validation for the durable
fill ledger and fill outbox introduced in Chunks 64–65.

Migrations:

1. schema_version
2. fill_ledger
3. fill_outbox

The migration runner:
- requires unique migration versions
- requires sorted migrations
- exposes only migrations newer than the current schema version
- delegates transaction ownership to the PostgreSQL executor/connection layer

Startup validation checks the required persistence tables before the engine is
considered persistence-ready.

Required tables:
- fill_ledger
- fill_outbox

This chunk does not auto-create/modify a production PostgreSQL instance and
does not run broker calls. The existing PostgreSQL foundation remains the
intended production connection/pool layer.
