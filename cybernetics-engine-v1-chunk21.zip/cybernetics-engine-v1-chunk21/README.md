# Cybernetics Trading Engine — Chunk 21

Persistent Audit / Trading Database Schema.

The PostgreSQL schema covers:
- engine and market events
- signals and rejected opportunities
- strategy decisions
- risk decisions
- orders, order events and fills
- positions
- reconciliation
- health/watchdog
- AI observations and proposals
- versioned software releases with artifact hashes

This chunk provides an in-memory reference audit store for tests.
Production persistence is PostgreSQL and must use transactional writes.
AI proposals default to PROPOSED and are never auto-approved.
