# Chunk 85 — WebSocket Interface Reconciliation

## Conflict resolved

`cybernetics.websocket.subscriptions` existed in Chunks 32 and 33 with
different public surfaces.

### Chunk 32 implementation
Provides:
- `SubscriptionMode`
- `Instrument`
- `SubscriptionManager`
- Dhan request/unsubscribe request codes
- 100-instrument message chunking
- 5000-instrument per-connection ceiling
- desired-state add/remove/set operations

### Chunk 33 implementation
Reduced the module to only:
- `SubscriptionMode`
- `Instrument`

But Chunk 33's `FeedSharder` and `FeedSupervisor` still depend on those public
types, while the historical Chunk 32 tests require `SubscriptionManager`.

## Canonical decision

Use the Chunk 32 implementation as the canonical public subscription contract.

Reason:
- It is a strict superset for the shared public types.
- It preserves Chunk 32 behavior.
- Chunk 33's sharder/supervisor remain compatible with the richer contract.
- Removing `SubscriptionManager` would break an existing required subsystem.

This is a code/interface decision, not merely a test compatibility hack.
