# Chunk 121 — Hostinger Staging Runbook

This runbook is for the **staging/paper-only** deployment on the existing Hostinger Ubuntu VPS. It does not authorize live trading.

## 1. Upload release

Copy the Chunk 120/121 release archive to the VPS staging area and extract it under `/opt/cybernetics-engine/releases/<release-id>` as `cybernetics` (or via root with final ownership set to `cybernetics:cybernetics`).

## 2. Prepare Python environment

Use the existing VPS Python installation. Create `/opt/cybernetics-engine/venv` if it does not already exist, then install the release package into that venv. Do not use `/home/ubuntu/cybernetics_engine` or assume an `ubuntu` service account.

## 3. Create staging environment

Create `/etc/cybernetics-engine/cybernetics-engine.env` from the packaged example. Keep:

- `CYBERNETICS_ENV=staging`
- `CYBERNETICS_TRADING_MODE=paper`
- `CYBERNETICS_ORDER_SUBMISSION_ENABLED=false`

Do not put API secrets into source files or the example file.

## 4. Run preflight

Run as root:

```bash
sudo /opt/cybernetics-engine/current/deploy/scripts/preflight_staging.sh
```

It must finish with:

```text
PREFLIGHT_SAFE: new_trades_allowed=false
PREFLIGHT_OK
```

## 5. Install/activate service

Use:

```bash
sudo /opt/cybernetics-engine/current/deploy/scripts/install_staging.sh /opt/cybernetics-engine/current
```

Then verify:

```bash
sudo systemctl status cybernetics-engine --no-pager
sudo journalctl -u cybernetics-engine -n 100 --no-pager
```

## 6. Staging acceptance gate

The service may be considered staging-healthy only when the CLI self-check succeeds, systemd reports `active`, logs show normal supervisory cycles, and `new_trades_allowed=false`.

Do **not** enable live mode, order submission, or live authorization during this gate.

## 7. Rollback

Keep the previous release under `/opt/cybernetics-engine/releases/`. Stop the service, restore `/opt/cybernetics-engine/current` to the prior known-good release, rerun self-check, and verify paper-only state before restart.
