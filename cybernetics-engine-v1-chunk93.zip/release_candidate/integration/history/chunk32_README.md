# Cybernetics Trading Engine — Chunk 32

## Dhan V2 WebSocket Connection + Subscription Manager

This chunk provides the lifecycle/control layer for Dhan V2 Live Market Feed.

### Implemented
- Dhan V2 market-feed WebSocket URL construction.
- Token-provider based authentication.
- Desired subscription state.
- Ticker / Quote / Full subscription modes.
- Automatic 100-instrument JSON message chunking.
- 5000-instrument per-connection guard.
- Unsubscribe request codes.
- Automatic reconnect with exponential backoff and cap.
- Automatic resubscription after reconnect.
- Async message callback boundary for the existing binary decoder.
- Explicit connection states.

Dhan V2 documents five WebSocket connections per user and 5000 instruments per connection;
subscription JSON messages can contain up to 100 instruments. The server sends ping frames
to maintain the connection and closes connections that fail to respond for more than 40 seconds.

This chunk does not decode binary market packets itself. It hands received bytes to the existing
decoder boundary from the earlier market-data foundation.
