from __future__ import annotations

from cybernetics.runtime.application import RuntimeApplication, RuntimeConfig
from cybernetics.runtime.metrics import RuntimeMetrics


def test_metrics_start_empty():
    m = RuntimeMetrics()
    s = m.snapshot()
    assert s.cycles_total == 0
    assert s.cycle_failures_total == 0
    assert s.readiness_changes_total == 0
    assert s.dependency_failures_total == 0
    assert s.dependency_recoveries_total == 0
    assert s.health_refreshes_total == 0


def test_run_cycle_records_cycle_and_health_refresh():
    m = RuntimeMetrics()
    app = RuntimeApplication(config=RuntimeConfig(poll_interval_seconds=0.01), metrics=m)
    app.start()
    app.run_cycle()
    s = m.snapshot()
    assert s.cycles_total == 1
    assert s.cycle_failures_total == 0
    assert s.health_refreshes_total >= 1
    app.stop()


def test_readiness_change_is_counted_once_per_change():
    m = RuntimeMetrics()
    app = RuntimeApplication(metrics=m)
    app.start()
    first = app.snapshot()
    after_first = m.snapshot().readiness_changes_total
    app.snapshot()
    assert m.snapshot().readiness_changes_total == after_first
    assert first.readiness.engine_ready is False
    app.stop()
