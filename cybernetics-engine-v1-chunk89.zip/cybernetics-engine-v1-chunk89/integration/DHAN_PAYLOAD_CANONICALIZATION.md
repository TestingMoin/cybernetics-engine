# Chunk 89 — Dhan Payload Interface Reconciliation

## Conflict

`cybernetics.dhan.payload` existed in two materially different forms.

Chunk 56 supplies the complete mapper boundary:
- DhanOrderPayload
- DhanOrderPayloadMapper
- Dhan field validation
- exchange/product/validity validation
- MARKET/LIMIT validation
- positive quantity validation
- disclosed quantity validation
- deterministic compact correlation ID
- correlation ID length/character validation
- transaction type validation
- credential/token separation

Chunk 57 retained only the serializable `DhanOrderPayload` dataclass.

## Canonical decision

Chunk 56 is the canonical payload contract.

Chunk 57's reduced copy must not replace it.

This keeps broker-specific validation at the broker adapter boundary while
keeping access tokens out of payload objects.

No HTTP submission occurs in this chunk.
