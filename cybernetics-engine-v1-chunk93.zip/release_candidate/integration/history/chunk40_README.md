# Cybernetics Trading Engine — Chunk 40

## Scanner Processing Bus + Deterministic Indicator State Pipeline

This chunk connects isolated scanner runtimes to deterministic indicator state.

### Included base indicators
- EMA 5
- EMA 15
- RSI 14
- ATR 14 (Wilder-style smoothing)
- Bollinger Bands 20 / 2
- ROC 12

The calculations are maintained inside `IndicatorState`, which must be instantiated
per scanner runtime + timeframe. This preserves the isolation created in Chunk 38.

### Design rule

The indicator bus calculates evidence; it does not generate trades.

No strategy combination, confluence rule, entry/exit rule or broker action is introduced here.

A later integration layer will connect the Chunk 39 event router to this bus and then
feed the resulting indicator snapshot into the existing Signal Registry.
