from cybernetics.runtime.failure_handling import RuntimeDependencyFailureHandler
from cybernetics.runtime.state import ControlState, EmergencyState


def healthy():
    return {name: True for name in RuntimeDependencyFailureHandler.CRITICAL_DEPENDENCIES}


def test_healthy_dependencies_do_nothing():
    h = RuntimeDependencyFailureHandler()
    a = h.evaluate(healthy(), control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR)
    assert a.requested is False
    assert a.action == "NONE"


def test_broker_failure_stops_new_trades():
    state = []
    h = RuntimeDependencyFailureHandler(set_control_state=state.append)
    data = healthy(); data["broker"] = False
    a = h.evaluate(data, control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR)
    assert a.requested is True
    assert a.action == "STOP_NEW_TRADES"
    assert state == [ControlState.STOP_NEW_TRADES]


def test_market_feed_failure_stops_new_trades():
    state = []
    h = RuntimeDependencyFailureHandler(set_control_state=state.append)
    data = healthy(); data["market_data"] = False
    a = h.evaluate(data, control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR)
    assert a.action == "STOP_NEW_TRADES"
    assert state[-1] is ControlState.STOP_NEW_TRADES


def test_multiple_failures_are_reported():
    h = RuntimeDependencyFailureHandler()
    data = healthy(); data["persistence"] = False; data["watchdog"] = False
    a = h.evaluate(data, control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR)
    assert {x.name for x in a.failures} == {"persistence", "watchdog"}


def test_non_running_control_state_is_not_transitioned():
    state = []
    h = RuntimeDependencyFailureHandler(set_control_state=state.append)
    data = healthy(); data["broker"] = False
    a = h.evaluate(data, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR)
    assert a.requested is False
    assert state == []


def test_emergency_state_has_priority():
    state = []
    h = RuntimeDependencyFailureHandler(set_control_state=state.append)
    data = healthy(); data["broker"] = False
    a = h.evaluate(data, control_state=ControlState.RUNNING, emergency_state=EmergencyState.ACTIVE)
    assert a.requested is False
    assert a.reason == "emergency_state_already_active"
    assert state == []


def test_missing_dependency_key_fails_closed():
    h = RuntimeDependencyFailureHandler()
    a = h.evaluate({}, control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR)
    assert len(a.failures) == len(RuntimeDependencyFailureHandler.CRITICAL_DEPENDENCIES)
    assert a.requested is True


def test_failure_record_persists_for_diagnostics():
    h = RuntimeDependencyFailureHandler()
    data = healthy(); data["scanners"] = False
    h.evaluate(data, control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR)
    assert h.last_failures[0].name == "scanners"
    assert h.last_action.reason == "critical_dependency_failure"
