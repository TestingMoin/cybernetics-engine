from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx
import pyotp

logger = logging.getLogger(__name__)

AUTH_URL = "https://auth.dhan.co/app/generateAccessToken"


@dataclass(frozen=True)
class TokenSnapshot:
    expires_at: datetime
    source: str


class DhanTokenManager:
    """Generates/refreshes Dhan 24-hour tokens without persisting secrets or tokens to logs."""

    def __init__(self, client_id: str, pin: str, totp_secret: str, *, skew_seconds: int = 120) -> None:
        if not client_id or not pin or not totp_secret:
            raise ValueError("Dhan client_id, PIN and TOTP secret are required")
        if not pin.isdigit():
            raise ValueError("Dhan PIN must contain digits only")
        self._client_id = client_id
        self._pin = pin
        self._totp_secret = totp_secret.replace(" ", "").upper()
        self._skew = max(30, skew_seconds)
        self._access_token: Optional[str] = None
        self._snapshot: Optional[TokenSnapshot] = None
        self._lock = asyncio.Lock()

    @property
    def snapshot(self) -> Optional[TokenSnapshot]:
        return self._snapshot

    def _totp(self) -> str:
        return pyotp.TOTP(self._totp_secret).now()

    async def generate(self, *, client: Optional[httpx.AsyncClient] = None) -> str:
        owns_client = client is None
        http = client or httpx.AsyncClient(timeout=15.0)
        try:
            response = await http.post(
                AUTH_URL,
                params={"dhanClientId": self._client_id, "pin": self._pin, "totp": self._totp()},
            )
            response.raise_for_status()
            payload = response.json()
            token = payload.get("accessToken")
            expiry_text = payload.get("expiryTime")
            if not token or not expiry_text:
                raise RuntimeError("Dhan authentication response missing accessToken/expiryTime")
            expires_at = datetime.fromisoformat(expiry_text.replace("Z", "+00:00"))
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            self._access_token = token
            self._snapshot = TokenSnapshot(expires_at=expires_at, source="totp")
            logger.info("Dhan access token generated; expires_at=%s", expires_at.isoformat())
            return token
        except httpx.HTTPStatusError as exc:
            raise RuntimeError(f"Dhan authentication failed with HTTP {exc.response.status_code}") from exc
        finally:
            if owns_client:
                await http.aclose()

    async def get_valid_token(self) -> str:
        async with self._lock:
            now = datetime.now(timezone.utc)
            if self._access_token and self._snapshot:
                if now + timedelta(seconds=self._skew) < self._snapshot.expires_at:
                    return self._access_token
            return await self.generate()

    async def clear(self) -> None:
        async with self._lock:
            self._access_token = None
            self._snapshot = None
