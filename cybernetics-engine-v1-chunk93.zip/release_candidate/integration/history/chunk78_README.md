# Cybernetics Trading Engine — Chunk 78

## Emergency Stop Durable Control Path

This chunk makes the emergency-stop state a persistent latch.

### Durable flow

EMERGENCY_STOP command
    -> persistent emergency_control_state
    -> in-process emergency latch
    -> runtime readiness sees emergency active

On VPS/process restart:

startup
    -> load emergency_control_state
    -> restore ACTIVE latch
    -> remain blocked from new trades

### Safety rules

- Emergency state is persisted independently of engine process memory.
- Startup never auto-clears an active emergency.
- The same emergency_id is idempotent.
- Clearing the emergency requires explicit recovery/restore operation.
- Wrong emergency_id cannot clear the latch.
- Clearing the emergency does not itself return the engine to RUNNING.
  The existing state machine still requires its recovery path and new-trade
  authorization checks.
- This chunk contains no broker order submission/cancel/replace operation.

The PostgreSQL repository uses a single GLOBAL row to prevent multiple competing
emergency states within the engine instance.
