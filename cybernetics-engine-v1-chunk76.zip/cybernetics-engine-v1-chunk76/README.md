# Cybernetics Trading Engine — Chunk 76

## Durable Command Idempotency & Control Audit Repository

This chunk moves control-command identity and audit persistence to PostgreSQL.

### Database addition

Migration 4:

`control_command_audit`

The table provides:
- durable command_id primary key
- command/source/result/state/reason audit fields
- issued_at and created_at timestamps
- indexes for audit investigation

### Safety properties

A command ID survives a VPS restart because uniqueness is enforced by the
database, not process memory.

The repository uses `ON CONFLICT (command_id) DO NOTHING` for the first-write
boundary.

The audit sink then records or updates the durable command result.

This chunk only supplies the persistence boundary. The existing Control Command
Gateway remains the authority for command validation and state transitions.

No broker order execution, cancellation, replacement, or live authorization
creation exists in this chunk.
