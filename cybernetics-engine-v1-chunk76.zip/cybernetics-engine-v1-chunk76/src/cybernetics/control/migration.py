from __future__ import annotations

from dataclasses import dataclass


CONTROL_COMMAND_AUDIT_DDL = """
CREATE TABLE IF NOT EXISTS control_command_audit (
    command_id TEXT PRIMARY KEY,
    command TEXT NOT NULL,
    source TEXT NOT NULL,
    result TEXT NOT NULL CHECK (
        result IN ('ACCEPTED','DUPLICATE','REJECTED','STALE')
    ),
    state TEXT NOT NULL,
    reason TEXT NOT NULL,
    issued_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_control_command_audit_issued_at
    ON control_command_audit(issued_at);

CREATE INDEX IF NOT EXISTS idx_control_command_audit_source
    ON control_command_audit(source);

CREATE INDEX IF NOT EXISTS idx_control_command_audit_result
    ON control_command_audit(result);
"""


@dataclass(frozen=True)
class ControlMigration:
    version: int
    name: str
    sql: str


CONTROL_MIGRATION = ControlMigration(
    4,
    "control_command_audit",
    CONTROL_COMMAND_AUDIT_DDL,
)
