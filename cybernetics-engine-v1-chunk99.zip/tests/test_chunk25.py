from cybernetics.order_management.manager import OrderManager, OrderState
from cybernetics.order_management.idempotency import IdempotencyStore, IdempotencyRecord
from cybernetics.brokers.interface import BrokerOrderRequest, BrokerOrderResult

def request():
    return BrokerOrderRequest("NIFTY", "BUY", 50, "MARKET")

def test_duplicate_key_calls_broker_once():
    calls=[]
    def broker(req):
        calls.append(req)
        return BrokerOrderResult("FAKE", True, "B-1", "ACCEPTED")
    m=OrderManager(broker)
    a=m.submit("SIG-1", request())
    b=m.submit("SIG-1", request())
    assert a is b
    assert len(calls)==1
    assert b.broker_order_id=="B-1"

def test_timeout_becomes_unknown_and_is_not_retried():
    calls=[]
    def broker(req):
        calls.append(req)
        raise TimeoutError("timeout")
    m=OrderManager(broker)
    a=m.submit("SIG-2", request())
    b=m.submit("SIG-2", request())
    assert a.state == OrderState.UNKNOWN
    assert b.state == OrderState.UNKNOWN
    assert len(calls)==1

def test_broker_rejection_is_retained():
    def broker(req):
        return BrokerOrderResult("FAKE", False, None, "REJECTED", "margin")
    m=OrderManager(broker)
    a=m.submit("SIG-3", request())
    assert a.state == OrderState.REJECTED
    assert a.message == "margin"

def test_distinct_keys_are_distinct_orders():
    count=0
    def broker(req):
        nonlocal count
        count += 1
        return BrokerOrderResult("FAKE", True, f"B-{count}", "ACCEPTED")
    m=OrderManager(broker)
    m.submit("SIG-4-A", request())
    m.submit("SIG-4-B", request())
    assert count==2

def test_idempotency_store_put_once():
    s=IdempotencyStore()
    r=IdempotencyRecord("K","B","ACCEPTED")
    assert s.put_once(r) is True
    assert s.put_once(r) is False
    assert s.get("K").broker_order_id=="B"

def test_unknown_outcome_is_not_fabricated_as_rejected():
    def broker(req):
        raise TimeoutError("network")
    m=OrderManager(broker)
    o=m.submit("SIG-5", request())
    assert o.state == OrderState.UNKNOWN
    assert o.broker_order_id is None
