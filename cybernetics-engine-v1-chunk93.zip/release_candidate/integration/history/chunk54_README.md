# Cybernetics Trading Engine — Chunk 54

## Instrument Selection & Contract Resolution Boundary

This chunk introduces the final instrument-selection boundary between an approved
execution intent and a broker-specific adapter.

It supports:
- equity/index/future/option/commodity types
- option expiry, strike and CE/PE
- lot size
- tick size
- contract multiplier
- production-eligibility validation

The selector does **not** invent contracts or security IDs. It selects from the
candidate instruments supplied by the existing Universe / Contract Resolver
layers.

A candidate must be validated, approved, active and production-eligible when
`require_production_eligible=True`.

Ambiguous matches are rejected rather than guessing.

No Dhan API calls or order submission are performed by this chunk.
