# Cybernetics Trading Engine — Chunk 9

Observable Iceberg / Absorption Intelligence Foundation.

This is an intelligence detector, not hidden-order visibility and not execution.
Evidence can include relative volume, price-volume absorption, repeated replenishment,
visible depth, trade clustering and optional OI confirmation.

The scanner is configuration-driven. One reusable engine can operate isolated
scanner instances for NIFTY, BANKNIFTY, BSE indices, MCX groups, and later stock groups.
No scanner can place a broker order.
