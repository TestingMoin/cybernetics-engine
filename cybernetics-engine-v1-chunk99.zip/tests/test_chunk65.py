from types import SimpleNamespace
from cybernetics.persistence.outbox import (
    FillOutboxEvent, OutboxState, PostgreSQLFillOutbox,
    FILL_OUTBOX_DDL, OutboxDispatcher
)


class Cursor:
    def __init__(self,row=None,rowcount=1):
        self.row=row; self.rowcount=rowcount; self.sql=None; self.args=None
    def __enter__(self): return self
    def __exit__(self,*a): pass
    def execute(self,sql,args):
        self.sql=sql; self.args=args
    def fetchone(self): return self.row

class Conn:
    def __init__(self,c): self.c=c; self.commits=0
    def __enter__(self): return self
    def __exit__(self,*a): pass
    def cursor(self): return self.c
    def commit(self): self.commits+=1

class CF:
    def __init__(self,row=None,rowcount=1): self.row=row; self.rowcount=rowcount; self.last=None
    def __call__(self):
        cur=Cursor(self.row,self.rowcount); self.last=Conn(cur); return self.last

class Backend:
    def __init__(self):
        self.events={}
    def insert_if_absent(self,e):
        if e.event_id in self.events:return False
        self.events[e.event_id]=e;return True
    def claim(self,eid):
        e=self.events.get(eid)
        if not e or e.state!=OutboxState.PENDING:return False
        self.events[eid]=FillOutboxEvent(e.event_id,e.fill_id,e.order_id,e.trade_id,e.payload,
            OutboxState.PROCESSING,e.attempts+1,e.last_error);return True
    def mark_completed(self,eid):
        e=self.events[eid];self.events[eid]=FillOutboxEvent(e.event_id,e.fill_id,e.order_id,
            e.trade_id,e.payload,OutboxState.COMPLETED,e.attempts,e.last_error)
    def mark_failed(self,eid,error):
        e=self.events[eid];self.events[eid]=FillOutboxEvent(e.event_id,e.fill_id,e.order_id,
            e.trade_id,e.payload,OutboxState.FAILED,e.attempts,error)
    def get(self,eid):return self.events.get(eid)

def event(eid="E1",fid="F1"):
    return FillOutboxEvent(eid,fid,"O1","T1",{"fill_id":fid,"qty":10})

def test_ddl_has_unique_event_and_fill():
    assert "event_id TEXT PRIMARY KEY" in FILL_OUTBOX_DDL
    assert "uq_fill_outbox_fill_id" in FILL_OUTBOX_DDL

def test_insert_if_absent_uses_conflict():
    cf=CF(rowcount=1);l=PostgreSQLFillOutbox(cf)
    assert l.insert_if_absent(event())
    assert "ON CONFLICT (event_id) DO NOTHING" in cf.last.c.sql

def test_insert_conflict_returns_false():
    cf=CF(rowcount=0);l=PostgreSQLFillOutbox(cf)
    assert not l.insert_if_absent(event())

def test_claim_requires_pending():
    cf=CF(rowcount=1);l=PostgreSQLFillOutbox(cf)
    assert l.claim("E1")
    assert "state = 'PENDING'" in cf.last.c.sql

def test_completion_requires_processing():
    cf=CF(rowcount=1);l=PostgreSQLFillOutbox(cf)
    l.mark_completed("E1")
    assert "state = 'PROCESSING'" in cf.last.c.sql

def test_failure_stores_error():
    cf=CF(rowcount=1);l=PostgreSQLFillOutbox(cf)
    l.mark_failed("E1","boom")
    assert cf.last.c.args==("boom","E1")

def test_get_maps_row():
    row=("E1","F1","O1","T1",'{"qty":10}',"PENDING",0,None)
    cf=CF(row=row);l=PostgreSQLFillOutbox(cf)
    e=l.get("E1")
    assert e.event_id=="E1" and e.payload["qty"]==10

def test_dispatch_completes():
    b=Backend();b.insert_if_absent(event());calls=[]
    d=OutboxDispatcher(b,lambda e:calls.append(e.event_id))
    r=d.dispatch("E1")
    assert r.state=="COMPLETED" and calls==["E1"]
    assert b.get("E1").state==OutboxState.COMPLETED

def test_completed_event_is_duplicate():
    b=Backend();b.insert_if_absent(event());b.mark_completed("E1")
    d=OutboxDispatcher(b,lambda e: (_ for _ in ()).throw(RuntimeError()))
    assert d.dispatch("E1").state=="DUPLICATE"

def test_failed_consumer_is_recorded():
    b=Backend();b.insert_if_absent(event())
    d=OutboxDispatcher(b,lambda e: (_ for _ in ()).throw(RuntimeError("bad")))
    r=d.dispatch("E1")
    assert r.state=="FAILED" and b.get("E1").state==OutboxState.FAILED

def test_processing_state_requires_recovery():
    b=Backend();b.insert_if_absent(event());b.claim("E1")
    d=OutboxDispatcher(b,lambda e:None)
    assert d.dispatch("E1").state=="RECOVERY_REQUIRED"

def test_failed_state_requires_recovery():
    b=Backend();b.insert_if_absent(event());b.mark_failed("E1","x")
    d=OutboxDispatcher(b,lambda e:None)
    assert d.dispatch("E1").state=="RECOVERY_REQUIRED"

def test_unknown_event():
    assert OutboxDispatcher(Backend(),lambda e:None).dispatch("NOPE").state=="NOT_FOUND"
