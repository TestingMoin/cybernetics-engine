from pathlib import Path

from cybernetics.audit.events import AuditEventFactory, InMemoryAuditStore

def test_audit_event_is_immutable_and_identifiable():
    e=AuditEventFactory().create("SIGNAL","iceberg",{"symbol":"NIFTY"},severity="INFO")
    assert e.event_id and e.event_type=="SIGNAL" and e.payload["symbol"]=="NIFTY"

def test_store_append_and_filter():
    s=InMemoryAuditStore(); f=AuditEventFactory()
    s.append(f.create("SIGNAL","engine",{}))
    s.append(f.create("RISK","engine",{}))
    assert s.count()==2 and len(s.by_type("RISK"))==1

def test_rejected_opportunities_can_be_logged():
    f=AuditEventFactory()
    e=f.create("OPPORTUNITY_REJECTED","quality",{"reasons":["data_quality_failed"]})
    assert e.payload["reasons"]

def test_ai_proposal_is_not_implicitly_approved():
    p="status TEXT NOT NULL DEFAULT 'PROPOSED'"
    assert "DEFAULT 'PROPOSED'" in p

def test_release_requires_artifact_hash():
    assert "artifact_sha256 TEXT NOT NULL" in (Path(__file__).resolve().parents[1] / "sql/schema.sql").read_text()
