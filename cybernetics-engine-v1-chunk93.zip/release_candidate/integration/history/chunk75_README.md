# Cybernetics Trading Engine — Chunk 75

## Control Command Gateway

This chunk creates the single command boundary intended for external control
surfaces such as the future PWA/mobile panel and Telegram.

Command flow:

External Surface
    ↓
ControlCommandGateway
    ├─ source validation
    ├─ timestamp / stale-command validation
    ├─ duplicate command-id protection
    ├─ expected-state validation
    ├─ guarded state-machine transition
    └─ audit event
           ↓
GuardedController / ControlStateMachine

Supported command names mirror the guarded runtime actions.

Important safety properties:
- stale commands are rejected
- duplicate command IDs are rejected
- external RESUME_NEW_TRADES requires expected state
- actual resume still requires the independent TransitionPolicy guards from
  Chunk 74 (live authorization + recovery clear)
- the gateway never creates live authorization
- the gateway never submits/cancels/replaces broker orders

The in-memory command-ID store is only a local/test implementation. Production
must use the durable persistence boundary already established by the engine.
