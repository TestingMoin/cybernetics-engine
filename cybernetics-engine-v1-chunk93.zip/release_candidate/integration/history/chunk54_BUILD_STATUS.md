# Build Status — Chunk 54

compileall: PASS
pytest: PASS (11/11)
instrument eligibility: INCLUDED
option expiry/strike/type: INCLUDED
lot/tick/multiplier metadata: INCLUDED
ambiguous selection blocking: INCLUDED
security ID invention: NOT PRESENT
broker execution: NOT PRESENT
