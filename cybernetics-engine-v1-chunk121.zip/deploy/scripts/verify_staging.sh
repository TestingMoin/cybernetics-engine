#!/usr/bin/env bash
set -euo pipefail
ROOT=/opt/cybernetics-engine
SERVICE=cybernetics-engine

sudo -u cybernetics "$ROOT/venv/bin/cybernetics-engine" --self-check
sudo systemctl is-enabled --quiet "$SERVICE"
sudo systemctl is-active --quiet "$SERVICE"

snapshot=$(sudo -u cybernetics "$ROOT/venv/bin/cybernetics-engine" --self-check)
python3 - "$snapshot" <<'PY'
import json, sys
payload=json.loads(sys.argv[1])
assert payload["new_trades_allowed"] is False, payload
print("STAGING_SAFE: new_trades_allowed=false")
PY
