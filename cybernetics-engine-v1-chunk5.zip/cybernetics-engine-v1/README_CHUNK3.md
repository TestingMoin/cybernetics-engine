# Cybernetics Trading Engine — Chunk 3

This chunk adds the Dhan V2 transport foundation without enabling live order placement.

## Added
- `app/broker/dhan_rest.py` — async Dhan REST transport.
- `app/broker/dhan.py` — broker boundary with read-only account methods.
- `app/marketdata/dhan_ws.py` — reconnectable market-feed and order-update WebSockets.
- Dhan Option Chain and Market Quote methods.
- Central rate governor integration.

## Deliberate limitation
Market-feed responses are still exposed as raw bytes. The binary packet decoder and normalized market event model belong to the next market-data chunk. Live order endpoints are intentionally not wired.

## Dhan endpoints mapped in this chunk
- `GET /profile`
- `GET /holdings`
- `GET /positions`
- `GET /orders`
- `GET /trades`
- `POST /marketfeed/ltp`
- `POST /marketfeed/ohlc`
- `POST /marketfeed/quote`
- `POST /optionchain`
- `POST /optionchain/expirylist`
