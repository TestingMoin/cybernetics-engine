import asyncio
import os

import pytest

from app.auth.dhan_auth import DhanTokenManager
from app.db.database import normalize_database_url
from app.rate_limit.governor import DhanApiClass, RateLimitGovernor


def test_database_url_normalization():
    assert normalize_database_url("postgresql://u:p@db/c") == "postgresql+asyncpg://u:p@db/c"
    assert normalize_database_url("sqlite:///x.db") == "sqlite+aiosqlite:///x.db"


def test_totp_manager_requires_secret():
    with pytest.raises(ValueError):
        DhanTokenManager("123", "123456", "")

@pytest.mark.asyncio
async def test_rate_limiter_serializes():
    gov = RateLimitGovernor({DhanApiClass.QUOTE: __import__('app.rate_limit.governor', fromlist=['RateLimits']).RateLimits(100)})
    await asyncio.gather(*(gov.acquire(DhanApiClass.QUOTE) for _ in range(10)))
