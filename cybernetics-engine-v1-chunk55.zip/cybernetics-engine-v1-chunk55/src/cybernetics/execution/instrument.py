from dataclasses import dataclass
from enum import Enum
from datetime import date
from typing import Optional

class InstrumentType(str,Enum):
    EQUITY="EQUITY"; INDEX="INDEX"; FUTURE="FUTURE"; OPTION="OPTION"; COMMODITY="COMMODITY"
class OptionType(str,Enum): CE="CE"; PE="PE"

@dataclass(frozen=True)
class InstrumentEligibility:
    validated:bool; approved:bool; active:bool; production_eligible:bool; reason:str=""

@dataclass(frozen=True)
class TradeInstrument:
    exchange_segment:str; security_id:str; symbol:str; instrument_type:InstrumentType
    expiry:Optional[date]=None; strike:Optional[float]=None; option_type:Optional[OptionType]=None
    lot_size:int=1; tick_size:float=0.05; contract_multiplier:float=1.0
    eligibility:Optional[InstrumentEligibility]=None
    def __post_init__(self):
        if not self.exchange_segment or not self.security_id or not self.symbol:
            raise ValueError("instrument_identity_required")
        if self.lot_size<=0: raise ValueError("lot_size_must_be_positive")
        if self.tick_size<=0: raise ValueError("tick_size_must_be_positive")
        if self.contract_multiplier<=0: raise ValueError("contract_multiplier_must_be_positive")
        if self.instrument_type==InstrumentType.OPTION:
            if self.expiry is None: raise ValueError("option_expiry_required")
            if self.strike is None or self.strike<=0: raise ValueError("option_strike_required")
            if self.option_type is None: raise ValueError("option_type_required")
