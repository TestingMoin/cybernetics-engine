# Chunk 101 — Market Feed Runtime Wiring

Adds the canonical, side-effect-free runtime boundary between the production
composition root and the existing `FeedSupervisor` market-feed health model.

The boundary projects `safe_for_market_state()` into runtime market-data
readiness and fails closed on probe errors. It does not open sockets, subscribe
instruments, reconnect, call Dhan, mutate PostgreSQL, or submit orders.
