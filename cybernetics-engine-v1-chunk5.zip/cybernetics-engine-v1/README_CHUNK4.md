# Cybernetics Trading Engine — Chunk 4

## Market Data Normalization + Data Quality + Candle Builder

This chunk converts Dhan V2 binary live-market-feed packets into canonical internal events and deterministic OHLCV candles.

### Included

- Dhan V2 packet decoder for Index, Ticker, Quote, OI, Previous Close, Full, Market Status, and Feed Disconnect packets.
- Little-endian decoding per Dhan V2 market-feed specification.
- Multi-packet websocket-message parsing using the Dhan message-length field.
- Five-level depth extraction from the Dhan `FULL` packet.
- Canonical per-security state merger for asynchronous Ticker/Quote/OI/Previous-Close updates.
- Conservative data-quality checks:
  - non-positive price
  - invalid/crossed best bid/ask
  - invalid day range
  - future trade timestamps
  - missing price
  - disconnect events
- Deterministic candle aggregation for 1m/5m/15m/30m/1h.
- Cumulative-volume delta handling that does not fabricate interval volume and never creates negative volume on resets.
- Dhan websocket subscription mode selection: ticker, quote, or full.
- Five focused tests covering decoding, depth/OI, quality rejection, volume resets, and multi-packet messages.

### Production safety

This chunk does **not** place, modify, cancel, or exit live orders. It only processes market data.

No missing values are backfilled with guessed values. Gaps remain observable so later strategy/scanner layers can enforce data-continuity rules.

### Source authority

The packet layout is based on the current DhanHQ V2 Live Market Feed documentation and Annexure. Dhan documents the market feed as tick-by-tick binary websocket data, with an 8-byte response header and distinct packet codes for Ticker, Quote, OI, Previous Close and FULL packets.
