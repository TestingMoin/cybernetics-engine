from __future__ import annotations
from dataclasses import dataclass
from .models import ScannerRuntime, ScannerState

@dataclass(frozen=True)
class ScannerStateDecision:
    allowed: bool
    reason: str

def can_process_market_event(runtime: ScannerRuntime)->ScannerStateDecision:
    if runtime.state == ScannerState.RUNNING:
        return ScannerStateDecision(True,"scanner_running")
    return ScannerStateDecision(False,f"scanner_state:{runtime.state.value}")
