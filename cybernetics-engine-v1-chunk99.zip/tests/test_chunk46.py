from datetime import datetime, timezone
from cybernetics.strategy.golden import (
 NiftySensexGolden,BankNiftyGolden,NIFTY_SENSEX_ALLOWED_MONTHS,BANKNIFTY_ALLOWED_MONTHS
)
from cybernetics.strategy.models import GoldenContext

T=datetime(2026,5,1,9,30,tzinfo=timezone.utc)

def nifty(**kw):
    d=dict(strategy_id=NiftySensexGolden.strategy_id,signal_id="N1",timestamp=T,month=5,
           close=100, direction="BUY",ema5=102,ema15=101,prev_ema5=99,prev_ema15=100,
           daily_ema5=105,daily_ema15=100,allow_shorts=False)
    d.update(kw); return GoldenContext(**d)

def bank(**kw):
    d=dict(strategy_id=BankNiftyGolden.strategy_id,signal_id="B1",timestamp=T,month=5,
           close=100, direction="BUY",ema40=110,ema120=100,ema200=90,
           daily_ema40=110,daily_ema120=100,daily_ema200=90,daily_close=100,
           md_line=5,md_signal=3,higher_tf_pass=True)
    d.update(kw); return GoldenContext(**d)

def test_nifty_long_reproduction_target():
    r=NiftySensexGolden().evaluate(nifty())
    assert r.action=="ENTER_LONG"

def test_nifty_month_gate():
    r=NiftySensexGolden().evaluate(nifty(month=1))
    assert r.action=="NO_ACTION"
    assert r.rationale=="month_not_allowed"

def test_nifty_requires_crossover():
    r=NiftySensexGolden().evaluate(nifty(prev_ema5=101,prev_ema15=100))
    assert r.action=="NO_ACTION"

def test_nifty_short_requires_explicit_enable():
    r=NiftySensexGolden().evaluate(nifty(direction="SELL",ema5=99,ema15=101,
                                        prev_ema5=101,prev_ema15=100,
                                        daily_ema5=99,daily_ema15=100,allow_shorts=False))
    assert r.action=="NO_ACTION"

def test_nifty_short_when_enabled():
    r=NiftySensexGolden().evaluate(nifty(direction="SELL",ema5=99,ema15=101,
                                        prev_ema5=101,prev_ema15=100,
                                        daily_ema5=99,daily_ema15=100,allow_shorts=True))
    assert r.action=="ENTER_SHORT"

def test_bank_long():
    assert BankNiftyGolden().evaluate(bank()).action=="ENTER_LONG"

def test_bank_requires_daily_filter():
    r=BankNiftyGolden().evaluate(bank(daily_close=80))
    assert r.action=="EXIT_LONG"

def test_bank_requires_momentum_for_entry():
    r=BankNiftyGolden().evaluate(bank(md_line=2,md_signal=3))
    assert r.action=="NO_ACTION"

def test_bank_sell_is_exit_not_short_entry():
    r=BankNiftyGolden().evaluate(bank(direction="SELL"))
    assert r.action=="EXIT_LONG"

def test_month_sets_match_supplied_inputs():
    assert NIFTY_SENSEX_ALLOWED_MONTHS=={4,5,6,7,8,10,11,12}
    assert BANKNIFTY_ALLOWED_MONTHS=={1,4,5,6,7,8,10,11,12}
