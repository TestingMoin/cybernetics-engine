import time
from cybernetics.orders.lifecycle import OrderLifecycle, OrderStatus
from cybernetics.orders.ledger import OrderLedger

def test_full_lifecycle_partial_to_filled():
    x=OrderLifecycle()
    o=x.create("NIFTY","BUY",10,"MARKET")
    o=x.transition(o,OrderStatus.PENDING)
    o=x.transition(o,OrderStatus.PARTIAL,fill_quantity=4,fill_price=100)
    assert o.remaining_quantity==6 and o.filled_quantity==4
    o=x.transition(o,OrderStatus.FILLED,fill_quantity=6,fill_price=102)
    assert o.remaining_quantity==0 and round(o.avg_fill_price,4)==101.2

def test_cancel_path():
    x=OrderLifecycle()
    o=x.transition(x.create("NIFTY","BUY",10,"LIMIT",99),OrderStatus.PENDING)
    o=x.transition(o,OrderStatus.CANCEL_REQUESTED)
    o=x.transition(o,OrderStatus.CANCELLED)
    assert o.status==OrderStatus.CANCELLED

def test_rejection_is_terminal():
    x=OrderLifecycle()
    o=x.transition(x.create("NIFTY","BUY",10,"MARKET"),OrderStatus.REJECTED,reject_reason="risk")
    assert o.remaining_quantity==10
    try: x.transition(o,OrderStatus.PENDING)
    except ValueError: return
    assert False

def test_replace_creates_child_with_parent():
    x=OrderLifecycle()
    o=x.transition(x.create("NIFTY","BUY",10,"LIMIT",99),OrderStatus.PENDING)
    r=x.replace(o,quantity=6,limit_price=98.5)
    assert r.parent_order_id==o.order_id
    assert r.requested_quantity==6

def test_ledger_is_auditable():
    x=OrderLifecycle(); l=OrderLedger()
    o=x.transition(x.create("NIFTY","BUY",10,"MARKET"),OrderStatus.PENDING)
    l.append(o,"STATE_CHANGE",time.time(),source="paper")
    assert len(l.for_order(o.order_id))==1
