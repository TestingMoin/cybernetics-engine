from dataclasses import dataclass
from enum import Enum

class SubscriptionMode(str, Enum):
    TICKER="TICKER"
    QUOTE="QUOTE"
    FULL="FULL"

@dataclass(frozen=True, order=True)
class Instrument:
    exchange_segment: str
    security_id: str
