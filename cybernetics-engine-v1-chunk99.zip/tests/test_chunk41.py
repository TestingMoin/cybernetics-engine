from cybernetics.indicators.registry import IndicatorRegistry,IndicatorSpec,IndicatorTier
from cybernetics.indicators.standard_registry import build_standard_registry
from cybernetics.indicators.library import sma,ema,wma,rsi,atr,bollinger_bands,roc,highest,lowest,stochastic_k,stochastic_d,macd,adx,obv,vwap

def test_standard_registry_contains_individual_indicators():
    ids={x.indicator_id for x in build_standard_registry().all()}
    assert {"EMA","SMA","WMA","RSI","ATR","BB","ROC","HIGHEST","LOWEST","STOCH_K","STOCH_D","MACD","ADX","OBV","VWAP"} <= ids

def test_registry_metadata():
    x=build_standard_registry().get("EMA")
    assert (x.version,x.family,x.tier)==("1.0.0","TREND",IndicatorTier.CORE)

def test_duplicate_registry_id_rejected():
    r=IndicatorRegistry();d=IndicatorSpec("X","1.0","F",IndicatorTier.CORE,lambda *a:None)
    r.register(d)
    try:r.register(d);assert False
    except ValueError as e:assert str(e)=="indicator_already_registered"

def test_basic_indicators():
    x=[1,2,3,4,5]
    assert sma(x,3)==4 and ema(x,3)==4 and round(wma(x,3),6)==4.333333
    assert highest(x,3)==5 and lowest(x,3)==3

def test_momentum_indicators():
    x=list(range(1,30))
    assert rsi(x,14)==100
    assert roc(x,12) is not None
    assert stochastic_k(x,x,x,14)==100
    assert round(stochastic_d(x,x,x,14,3),6)==66.666667

def test_volatility_indicators():
    h=[11]*20;l=[9]*20;c=[10]*20
    assert atr(h,l,c,14)==2
    bb=bollinger_bands(c,20,2)
    assert bb["mid"]==10 and bb["upper"]==10 and bb["lower"]==10

def test_macd_adx_are_deterministic():
    c=[100+i for i in range(60)];h=[x+1 for x in c];l=[x-1 for x in c]
    assert macd(c) is not None
    assert adx(h,l,c)==100

def test_volume_indicators():
    c=[1,2,1,3];v=[10,20,30,40]
    assert obv(c,v)==30 and vwap([2,3,2,4],[0,1,0,2],c,v) is not None

def test_parameter_validation():
    try:bollinger_bands([1,2,3],3,-1);assert False
    except ValueError as e:assert str(e)=="invalid_bollinger_parameters"

def test_length_validation():
    try:vwap([1,2],[1],[1,2],[3,4]);assert False
    except ValueError as e:assert str(e)=="ohlcv_length_mismatch"

def test_insufficient_history():
    assert ema([1,2,3],5) is None and rsi([1,2,3],14) is None
    assert atr([2,2],[1,1],[1.5,1.5],14) is None

def test_registry_tiers():
    r=build_standard_registry()
    assert len(r.by_tier(IndicatorTier.CORE))>=7 and len(r.by_tier(IndicatorTier.ADVANCED))>=5
