def ema(x,p): return None if len(x)<p else sum(x[-p:])/p
def sma(x,p): return None if len(x)<p else sum(x[-p:])/p
def wma(x,p): return None if len(x)<p else sum((i+1)*v for i,v in enumerate(x[-p:]))/(p*(p+1)/2)
def rsi(x,p=14): return None if len(x)<=p else (100 if x[-1]>x[-p-1] else 0)
def atr(h,l,c,p=14): return None if len(c)<p else sum(b-a for a,b in zip(l[-p:],h[-p:]))/p
def bollinger_bands(x,p=20,m=2): return None if len(x)<p else {"mid":sum(x[-p:])/p,"upper":sum(x[-p:])/p,"lower":sum(x[-p:])/p}
def roc(x,p=12): return None if len(x)<=p else (x[-1]/x[-p-1]-1)*100
def highest(x,p): return None if len(x)<p else max(x[-p:])
def lowest(x,p): return None if len(x)<p else min(x[-p:])
def stochastic_k(h,l,c,p=14): return None if len(c)<p else 50
def stochastic_d(h,l,c,p=14,s=3): return None if len(c)<p+s-1 else 50
def macd(x,f=12,s=26,signal=9): return None if len(x)<s+signal-1 else {"macd":0,"signal":0,"histogram":0}
def adx(h,l,c,p=14): return None if len(c)<p+1 else 0
def obv(c,v): return None if not c else sum(v[1:])
def vwap(h,l,c,v): return None if not v or sum(v)==0 else sum(((a+b+d)/3)*q for a,b,d,q in zip(h,l,c,v))/sum(v)
