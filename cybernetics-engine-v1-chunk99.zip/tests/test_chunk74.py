import pytest
from cybernetics.runtime.control import (
    ControlStateMachine, ControlState, ControlAction,
    GuardedController, TransitionPolicy, InvalidTransition
)
from cybernetics.runtime.authorization import LiveAuthorization


def test_initial_state_engine_off():
    assert ControlStateMachine().state is ControlState.ENGINE_OFF


def test_start_sequence():
    m=ControlStateMachine()
    assert m.transition(ControlAction.START) is ControlState.STARTING
    assert m.transition(ControlAction.START_SUCCESS) is ControlState.RUNNING


def test_start_failure_returns_engine_off():
    m=ControlStateMachine()
    m.transition(ControlAction.START)
    assert m.transition(ControlAction.START_FAILURE) is ControlState.ENGINE_OFF


def test_running_to_stop_new_trades():
    m=ControlStateMachine(ControlState.RUNNING)
    assert m.transition(ControlAction.STOP_NEW_TRADES) is ControlState.STOP_NEW_TRADES


def test_running_to_emergency_stop():
    m=ControlStateMachine(ControlState.RUNNING)
    assert m.transition(ControlAction.EMERGENCY_STOP) is ControlState.EMERGENCY_STOP


def test_stop_new_trades_to_emergency_stop():
    m=ControlStateMachine(ControlState.STOP_NEW_TRADES)
    assert m.transition(ControlAction.EMERGENCY_STOP) is ControlState.EMERGENCY_STOP


def test_emergency_stop_requires_recovery_transition():
    m=ControlStateMachine(ControlState.EMERGENCY_STOP)
    with pytest.raises(InvalidTransition):
        m.transition(ControlAction.RESUME_NEW_TRADES)


def test_emergency_stop_to_recovery():
    m=ControlStateMachine(ControlState.EMERGENCY_STOP)
    assert m.transition(ControlAction.BEGIN_RECOVERY) is ControlState.RECOVERY


def test_recovery_returns_to_stop_new_trades():
    m=ControlStateMachine(ControlState.RECOVERY)
    assert m.transition(ControlAction.RECOVERY_COMPLETE) is ControlState.STOP_NEW_TRADES


def test_resume_requires_live_authorization():
    m=ControlStateMachine(ControlState.STOP_NEW_TRADES)
    c=GuardedController(m)
    with pytest.raises(InvalidTransition, match="policy_blocked"):
        c.apply(ControlAction.RESUME_NEW_TRADES, TransitionPolicy(False, True))


def test_resume_requires_recovery_clear():
    m=ControlStateMachine(ControlState.STOP_NEW_TRADES)
    c=GuardedController(m)
    with pytest.raises(InvalidTransition, match="policy_blocked"):
        c.apply(ControlAction.RESUME_NEW_TRADES, TransitionPolicy(True, False))


def test_resume_allowed_only_when_both_guards_true():
    m=ControlStateMachine(ControlState.STOP_NEW_TRADES)
    c=GuardedController(m)
    assert c.apply(
        ControlAction.RESUME_NEW_TRADES,
        TransitionPolicy(True, True)
    ) is ControlState.RUNNING


def test_recovery_complete_requires_clear_flag():
    m=ControlStateMachine(ControlState.RECOVERY)
    c=GuardedController(m)
    with pytest.raises(InvalidTransition):
        c.apply(ControlAction.RECOVERY_COMPLETE, TransitionPolicy(True, False))


def test_recovery_complete_allowed_when_clear():
    m=ControlStateMachine(ControlState.RECOVERY)
    c=GuardedController(m)
    assert c.apply(
        ControlAction.RECOVERY_COMPLETE,
        TransitionPolicy(False, True)
    ) is ControlState.STOP_NEW_TRADES


def test_shutdown_returns_engine_off():
    for state in (
        ControlState.STARTING,
        ControlState.RUNNING,
        ControlState.STOP_NEW_TRADES,
        ControlState.RECOVERY,
    ):
        m=ControlStateMachine(state)
        assert m.transition(ControlAction.SHUTDOWN) is ControlState.ENGINE_OFF


def test_live_authorization_is_independent():
    a=LiveAuthorization().approve("APPROVAL-1")
    assert a.valid
    revoked=a.revoke()
    assert not revoked.valid
    assert revoked.approval_id is None


def test_no_broker_submission_in_control_source():
    from pathlib import Path
    src=Path("src/cybernetics/runtime/control.py").read_text()
    for token in ("place_order","submit_order","cancel_order","replace_order","/v2/orders"):
        assert token not in src
