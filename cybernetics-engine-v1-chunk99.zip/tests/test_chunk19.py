from pathlib import Path
from tempfile import TemporaryDirectory
from cybernetics.control.safety import SafetyController, ControlState
from cybernetics.control.recovery import RecoveryOrchestrator, RecoveryStage
from cybernetics.control.checkpoint import CheckpointStore, EngineCheckpoint

def test_live_never_authorized_by_default():
    s=SafetyController()
    x=s.snapshot()
    assert x.state==ControlState.STOP_NEW_TRADES and not x.live_authorized

def test_emergency_stop_requires_recovery():
    s=SafetyController()
    s.enable_engine()
    s.emergency_stop()
    try:
        s.enable_engine()
    except RuntimeError:
        pass
    else:
        assert False
    s.recover()
    s.enable_engine()
    assert s.snapshot().state==ControlState.RUNNING

def test_live_requires_running_engine():
    s=SafetyController()
    try: s.authorize_live()
    except RuntimeError: return
    assert False

def test_recovery_stops_on_first_failed_stage():
    r=RecoveryOrchestrator()
    result=r.recover(load_state=lambda:True,broker_check=lambda:True,
                     reconcile=lambda:False,restore_data=lambda:True,restore_strategies=lambda:True)
    assert not result.success and result.stage==RecoveryStage.FAILED and not result.new_trades_allowed

def test_atomic_checkpoint_roundtrip():
    with TemporaryDirectory() as d:
        p=Path(d)/"state"/"checkpoint.json"
        s=CheckpointStore(str(p))
        cp=EngineCheckpoint(1,123.0,"STOP_NEW_TRADES",False,{"n":10})
        s.save(cp)
        out=s.load()
        assert out==cp
