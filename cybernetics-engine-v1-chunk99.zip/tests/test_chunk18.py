from cybernetics.reconcile.engine import (
    ReconciliationEngine,InternalOrder,BrokerOrder,InternalPosition,BrokerPosition
)
from cybernetics.reconcile.manager import ReconciliationManager

def test_matching_state():
    e=ReconciliationEngine()
    oi=InternalOrder("1","NIFTY","BUY",10,10,100.0,"FILLED")
    ob=BrokerOrder("1","NIFTY","BUY",10,10,100.0,"FILLED")
    pi=InternalPosition("NIFTY",10,100.0); pb=BrokerPosition("NIFTY",10,100.0)
    r=e.report(e.reconcile_orders([oi],[ob]),e.reconcile_positions([pi],[pb]))
    assert r.matched and not r.no_new_trades

def test_unexpected_broker_order_blocks():
    e=ReconciliationEngine()
    r=e.report(e.reconcile_orders([], [BrokerOrder("X","NIFTY","BUY",10,0,None,"PENDING")]), [])
    assert not r.matched and r.no_new_trades
    assert r.issues[0].kind=="UNEXPECTED_BROKER_ORDER"

def test_fill_mismatch_is_critical():
    e=ReconciliationEngine()
    i=InternalOrder("1","NIFTY","BUY",10,10,100,"FILLED")
    b=BrokerOrder("1","NIFTY","BUY",10,6,100,"PARTIAL")
    issues=e.reconcile_orders([i],[b])
    assert any(x.kind=="FILL_QUANTITY_MISMATCH" and x.severity=="CRITICAL" for x in issues)

def test_position_mismatch_blocks():
    e=ReconciliationEngine()
    issues=e.reconcile_positions([InternalPosition("NIFTY",10,100)],[BrokerPosition("NIFTY",5,100)])
    r=e.report([],issues)
    assert r.no_new_trades

def test_manager_resumes_only_on_clean_report():
    e=ReconciliationEngine(); m=ReconciliationManager()
    clean=e.report([],[])
    dirty=e.report([],e.reconcile_positions([InternalPosition("NIFTY",10,100)],[BrokerPosition("NIFTY",5,100)]))
    assert m.decide(clean).action=="RESUME"
    assert m.decide(dirty).action=="BLOCK_NEW_TRADES"
