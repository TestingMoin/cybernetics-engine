# Cybernetics Trading Engine v1 — Foundation Build

This is the first production-oriented foundation chunk. It deliberately does **not** place broker orders.

## Safety defaults
- `TRADING_MODE=paper`
- `LIVE_TRADING_ENABLED=false`
- `EMERGENCY_TRADING_ENABLED=false`
- Control API binds to localhost by default.
- Live authorization requires engine running and no protective stop.
- Stopping the engine automatically removes live authorization.
- Emergency stop forces engine stopped, kill switch active, and live authorization off.

## Intended architecture
Reusable engines + configuration-driven isolated scanner state. Do not create one Python file per symbol. The universe and scanner registry are the next build chunk.

## Run tests
```bash
python -m pytest -q
```

## Local run
```bash
copy .env.example .env
python main.py
```

## VPS rule
Do not run the old `setup_vps.sh` from the audited scaffold. This repository is designed for `/opt/cybernetics-engine` and the `cybernetics` service account used on the current VPS.
