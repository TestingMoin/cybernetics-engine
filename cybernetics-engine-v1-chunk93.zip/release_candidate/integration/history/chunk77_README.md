# Cybernetics Trading Engine — Chunk 77

## Durable Control Gateway Integration

This chunk composes the external control gateway with the PostgreSQL
`control_command_audit` repository from Chunk 76.

The command lifecycle is:

external PWA/Telegram/System command
    -> gateway validation
    -> guarded state transition
    -> PostgreSQL audit/idempotency persistence
    -> receipt

The wrapper provides a durable status lookup by command_id.

Safety properties:
- existing stale/duplicate/source/state validation remains in the control
  gateway
- runtime transitions remain owned by the guarded state machine
- durable command records survive process restarts
- command persistence uses the PostgreSQL uniqueness boundary
- live authorization is not created by this layer
- broker order endpoints are not present

This is still an independently testable integration chunk, not the final
production service wiring.
