from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal

PacketKind = Literal["index", "ticker", "quote", "oi", "prev_close", "full", "market_status", "disconnect", "unknown"]


@dataclass(frozen=True, slots=True)
class DepthLevel:
    side: Literal["bid", "ask"]
    price: float
    quantity: int
    orders: int


@dataclass(frozen=True, slots=True)
class MarketEvent:
    packet_kind: PacketKind
    exchange_segment: int
    security_id: str
    received_at: datetime
    last_price: float | None = None
    last_quantity: int | None = None
    trade_time: datetime | None = None
    avg_trade_price: float | None = None
    volume: int | None = None
    total_sell_quantity: int | None = None
    total_buy_quantity: int | None = None
    day_open: float | None = None
    day_close: float | None = None
    day_high: float | None = None
    day_low: float | None = None
    open_interest: int | None = None
    highest_oi: int | None = None
    lowest_oi: int | None = None
    prev_close: float | None = None
    prev_oi: int | None = None
    depth: tuple[DepthLevel, ...] = field(default_factory=tuple)
    raw_length: int = 0
    feed_code: int = 0
    error_code: int | None = None

    @property
    def age_seconds(self) -> float:
        return max(0.0, (datetime.now(timezone.utc) - self.received_at).total_seconds())
