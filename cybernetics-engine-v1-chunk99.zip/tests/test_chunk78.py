from cybernetics.control.emergency import (
    DurableEmergencyStop, EmergencyRecord, EmergencyAction,
    EmergencyState
)
from cybernetics.control.emergency_repository import PostgresEmergencyRepository


class Result:
    def __init__(self,rowcount=1): self.rowcount=rowcount


class Tx:
    def __init__(self, fetch=None, rowcount=1):
        self.fetch=list(fetch or [])
        self.rowcount=rowcount
        self.calls=[]
    def fetchone(self,sql,params=()):
        self.calls.append(("fetchone",sql,params))
        return self.fetch.pop(0) if self.fetch else None
    def execute(self,sql,params=()):
        self.calls.append(("execute",sql,params))
        return Result(self.rowcount)


class Persist:
    def __init__(self, active=None):
        self.active=active
        self.trips=[]
        self.clears=[]
    def load_active(self): return self.active
    def persist_trip(self, record): self.trips.append(record)
    def persist_clear(self, eid, actor, issued_at): self.clears.append((eid,actor,issued_at))


def rec(eid="E1"):
    return EmergencyRecord(
        eid, EmergencyAction.TRIP, "manual emergency", "PWA", 1000.0
    )


def test_initial_state_clear():
    p=Persist()
    assert DurableEmergencyStop(p).status.state is EmergencyState.CLEAR


def test_trip_persists_and_activates():
    p=Persist()
    e=DurableEmergencyStop(p)
    s=e.trip(rec())
    assert s.state is EmergencyState.ACTIVE
    assert p.trips[0].emergency_id=="E1"


def test_same_emergency_id_is_idempotent():
    p=Persist()
    e=DurableEmergencyStop(p)
    first=e.trip(rec())
    second=e.trip(rec())
    assert first==second
    assert len(p.trips)==1


def test_different_emergency_id_replaces_durable_latch():
    p=Persist()
    e=DurableEmergencyStop(p)
    e.trip(rec("E1"))
    s=e.trip(rec("E2"))
    assert s.emergency_id=="E2"
    assert len(p.trips)==2


def test_startup_restores_active_emergency():
    from cybernetics.control.emergency import EmergencyStatus, EmergencyState
    active=EmergencyStatus(
        EmergencyState.ACTIVE,"E9","server fault","SYSTEM",900.0
    )
    e=DurableEmergencyStop(Persist(active))
    s=e.restore_on_startup()
    assert s.state is EmergencyState.ACTIVE
    assert s.emergency_id=="E9"


def test_startup_without_persisted_emergency_is_clear():
    e=DurableEmergencyStop(Persist())
    assert e.restore_on_startup().state is EmergencyState.CLEAR


def test_active_emergency_can_only_clear_with_matching_id():
    p=Persist()
    e=DurableEmergencyStop(p)
    e.trip(rec("E1"))
    import pytest
    with pytest.raises(ValueError,match="emergency_id_mismatch"):
        e.restore_for_recovery(emergency_id="E2",actor="PWA",issued_at=1001)


def test_clear_requires_active_emergency():
    e=DurableEmergencyStop(Persist())
    import pytest
    with pytest.raises(ValueError,match="emergency_not_active"):
        e.restore_for_recovery(emergency_id="E1",actor="PWA",issued_at=1001)


def test_clear_requires_actor():
    p=Persist()
    e=DurableEmergencyStop(p)
    e.trip(rec())
    import pytest
    with pytest.raises(ValueError,match="recovery_actor_required"):
        e.restore_for_recovery(emergency_id="E1",actor="",issued_at=1001)


def test_clear_persists_and_deactivates():
    p=Persist()
    e=DurableEmergencyStop(p)
    e.trip(rec("E1"))
    s=e.restore_for_recovery(emergency_id="E1",actor="PWA",issued_at=1001)
    assert s.state is EmergencyState.CLEAR
    assert p.clears==[("E1","PWA",1001)]


def test_trip_requires_id():
    import pytest
    with pytest.raises(ValueError,match="emergency_id_required"):
        DurableEmergencyStop(Persist()).trip(rec(""))


def test_trip_requires_reason():
    import pytest
    with pytest.raises(ValueError,match="emergency_reason_required"):
        DurableEmergencyStop(Persist()).trip(
            EmergencyRecord("E1",EmergencyAction.TRIP,"","PWA",1000)
        )


def test_trip_requires_actor():
    import pytest
    with pytest.raises(ValueError,match="emergency_actor_required"):
        DurableEmergencyStop(Persist()).trip(
            EmergencyRecord("E1",EmergencyAction.TRIP,"x","",1000)
        )


def test_repository_ddl_has_global_key():
    assert "control_key TEXT PRIMARY KEY" in PostgresEmergencyRepository.DDL


def test_repository_ddl_has_active_index():
    assert "idx_emergency_control_active" in PostgresEmergencyRepository.DDL


def test_repository_loads_active_row():
    tx=Tx(fetch=[(True,"E1","reason","PWA",1000.0)])
    s=PostgresEmergencyRepository(tx).load_active()
    assert s is not None
    assert s.emergency_id=="E1"


def test_repository_loads_clear_as_none():
    tx=Tx(fetch=[(False,None,None,"PWA",1000.0)])
    assert PostgresEmergencyRepository(tx).load_active() is None


def test_repository_trip_uses_upsert():
    tx=Tx()
    PostgresEmergencyRepository(tx).persist_trip(rec())
    assert "ON CONFLICT (control_key)" in tx.calls[0][1]


def test_repository_clear_checks_active_and_id():
    tx=Tx(rowcount=1)
    PostgresEmergencyRepository(tx).persist_clear("E1","PWA",1001)
    sql=tx.calls[0][1]
    assert "active=TRUE" in sql
    assert "emergency_id=%s" in sql


def test_repository_clear_failure_is_blocked():
    import pytest
    tx=Tx(rowcount=0)
    with pytest.raises(ValueError,match="emergency_clear_not_persisted"):
        PostgresEmergencyRepository(tx).persist_clear("E1","PWA",1001)


def test_no_broker_order_mutation_in_emergency_code():
    from pathlib import Path
    for f in (
        "src/cybernetics/control/emergency.py",
        "src/cybernetics/control/emergency_repository.py",
    ):
        src=Path(f).read_text()
        for token in ("/v2/orders","place_order","submit_order","cancel_order","replace_order"):
            assert token not in src


def test_emergency_action_is_not_a_live_authorization_action():
    assert EmergencyAction.TRIP is not None
    assert EmergencyAction.RESTORE_FOR_RECOVERY is not EmergencyAction.TRIP
