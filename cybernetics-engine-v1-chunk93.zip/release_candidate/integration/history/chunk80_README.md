# Cybernetics Trading Engine — Chunk 80

## Emergency Stop → Exit All / Flatten Safety Path

This chunk establishes a separate emergency exit path.

### Normal entry path
ENTRY -> Risk -> PreTrade -> Entry Execution

### Emergency flatten path
EMERGENCY ACTIVE
    -> read open positions
    -> create one deterministic exit intent per position
    -> emergency exit executor
    -> broker-exit adapter (later composition)

The emergency path deliberately does NOT reuse the normal entry/new-trade gate.

Safety properties:
- only active emergencies can create flatten plans
- broker availability is required
- one emergency request is idempotent
- one position gets at most one deterministic exit intent for an emergency
- exit side is the inverse of the open position side
- quantity is copied from the current open position; no new sizing is performed
- UNKNOWN broker submission remains UNKNOWN and requires reconciliation
- the planner/executor do not themselves create live authorization
- no entry order endpoint exists in this chunk

This is a safety boundary; actual Dhan Exit-All/order submission integration is
a later composition step after the control/reconciliation layers are unified.
