# Cybernetics Trading Engine — Chunk 61

## Fill → Position Manager Integration

Validated fills are now the mutation input for Position Manager.

Supported:
- FLAT → LONG / SHORT
- same-side average price updates
- realized P&L on closes
- explicit long↔short reversal handling
- duplicate fill-ID protection
- fee tracking
- mark-to-market unrealized P&L
- total P&L = realized + unrealized - fees

No broker calls are made here. The production source of fills should be the
validated broker/order-ledger pipeline, followed by reconciliation against
broker positions.
