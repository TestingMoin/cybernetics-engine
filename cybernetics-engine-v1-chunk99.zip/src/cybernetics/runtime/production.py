from __future__ import annotations

from dataclasses import dataclass

from cybernetics.config.settings import DeploymentConfig, TradingMode

from .application import RuntimeApplication, RuntimeConfig
from .dependencies import RuntimeDependencyBundle
from .state import ControlState, EmergencyState, EngineMode


@dataclass
class RuntimeDependencyState:
    """Runtime dependency-health values supplied by real adapters later.

    Defaults are deliberately unsafe.  A production composition must explicitly
    report readiness from each dependency instead of assuming availability.
    """

    engine_running: bool = False
    control_state: ControlState = ControlState.STOP_NEW_TRADES
    emergency_state: EmergencyState = EmergencyState.CLEAR
    persistence_ready: bool = False
    recovery_clear: bool = False
    orders_reconciled: bool = False
    positions_reconciled: bool = False
    market_data_ready: bool = False
    scanner_health_ready: bool = False
    watchdog_healthy: bool = False
    broker_available: bool = False
    live_authorization_valid: bool = False


class ProductionRuntimeSignals:
    """Canonical signal adapter for the runtime composition root.

    This object contains no broker I/O.  Concrete adapters update the supplied
    state after their own health/recovery checks.  LIVE authorization is kept as
    a separate runtime signal from engine state and control state.
    """

    def __init__(self, state: RuntimeDependencyState, config: DeploymentConfig):
        self.state = state
        self.config = config

    def engine_mode(self) -> EngineMode:
        return EngineMode.RUNNING if self.state.engine_running else EngineMode.STOPPED

    def control_state(self) -> ControlState:
        return self.state.control_state

    def emergency_state(self) -> EmergencyState:
        return self.state.emergency_state

    def persistence_ready(self) -> bool:
        return self.state.persistence_ready

    def recovery_clear(self) -> bool:
        return self.state.recovery_clear

    def orders_reconciled(self) -> bool:
        return self.state.orders_reconciled

    def positions_reconciled(self) -> bool:
        return self.state.positions_reconciled

    def market_data_ready(self) -> bool:
        return self.state.market_data_ready

    def scanner_health_ready(self) -> bool:
        return self.state.scanner_health_ready

    def watchdog_healthy(self) -> bool:
        return self.state.watchdog_healthy

    def broker_available(self) -> bool:
        return self.state.broker_available

    def live_authorization_valid(self) -> bool:
        return (
            self.config.trading_mode is TradingMode.LIVE
            and self.config.live_authorization_configured
            and self.state.live_authorization_valid
        )


def build_production_runtime(
    config: DeploymentConfig,
    *,
    dependency_state: RuntimeDependencyState | None = None,
    dependencies: RuntimeDependencyBundle | None = None,
) -> RuntimeApplication:
    """Build the single canonical runtime application from injected state.

    The function composes state only; it does not create network connections,
    submit orders, authorize live trading, or mutate persistent storage.
    """
    config.validate_filesystem()
    state = dependency_state or RuntimeDependencyState()
    if dependencies is not None:
        dependencies.ensure_structurally_wired()
        state = dependencies.as_dependency_state(base_state=state)
    signals = ProductionRuntimeSignals(state, config)
    return RuntimeApplication(
        config=RuntimeConfig(
            service_name=config.service_name,
            poll_interval_seconds=config.runtime_poll_seconds,
        ),
        signals=signals,
    )
