from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import json
from typing import Any, Mapping, Protocol


class LedgerState(str, Enum):
    CLAIMED = "CLAIMED"
    COMPLETED = "COMPLETED"
    RECOVERY_REQUIRED = "RECOVERY_REQUIRED"


class OutboxState(str, Enum):
    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


@dataclass(frozen=True)
class FillLedgerRecord:
    fill_id: str
    order_id: str
    trade_id: str
    state: LedgerState
    error: str | None = None


@dataclass(frozen=True)
class FillOutboxRecord:
    event_id: str
    fill_id: str
    order_id: str
    trade_id: str
    payload: Mapping[str, Any]
    state: OutboxState = OutboxState.PENDING
    attempts: int = 0
    last_error: str | None = None


class Tx(Protocol):
    def fetchone(self, sql: str, params: tuple[Any, ...] = ()) -> Any: ...
    def fetchall(self, sql: str, params: tuple[Any, ...] = ()) -> list[Any]: ...
    def execute(self, sql: str, params: tuple[Any, ...] = ()) -> Any: ...


class FillPersistenceRepository:
    """PostgreSQL repository for the durable fill ledger and fill outbox."""

    def __init__(self, tx: Tx):
        self.tx = tx

    def claim_fill(self, record: FillLedgerRecord) -> bool:
        row = self.tx.fetchone(
            """
            INSERT INTO fill_ledger(fill_id, order_id, trade_id, state, error)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (fill_id) DO NOTHING
            RETURNING fill_id
            """,
            (
                record.fill_id, record.order_id, record.trade_id,
                record.state.value, record.error,
            ),
        )
        return row is not None

    def get_fill(self, fill_id: str) -> FillLedgerRecord | None:
        row = self.tx.fetchone(
            """
            SELECT fill_id, order_id, trade_id, state, error
            FROM fill_ledger WHERE fill_id = %s
            """,
            (fill_id,),
        )
        if row is None:
            return None
        return FillLedgerRecord(
            fill_id=row[0], order_id=row[1], trade_id=row[2],
            state=LedgerState(row[3]), error=row[4],
        )

    def complete_fill(self, fill_id: str) -> bool:
        result = self.tx.execute(
            """
            UPDATE fill_ledger
            SET state = %s, error = NULL, completed_at = CURRENT_TIMESTAMP
            WHERE fill_id = %s AND state = %s
            """,
            (LedgerState.COMPLETED.value, fill_id, LedgerState.CLAIMED.value),
        )
        return _rowcount(result) == 1

    def mark_recovery_required(self, fill_id: str, error: str) -> bool:
        result = self.tx.execute(
            """
            UPDATE fill_ledger
            SET state = %s, error = %s
            WHERE fill_id = %s
              AND state IN (%s, %s)
            """,
            (
                LedgerState.RECOVERY_REQUIRED.value,
                error, fill_id,
                LedgerState.CLAIMED.value,
                LedgerState.RECOVERY_REQUIRED.value,
            ),
        )
        return _rowcount(result) == 1

    def enqueue_outbox(self, record: FillOutboxRecord) -> bool:
        row = self.tx.fetchone(
            """
            INSERT INTO fill_outbox(
                event_id, fill_id, order_id, trade_id, payload_json,
                state, attempts, last_error
            )
            VALUES (%s, %s, %s, %s, %s::jsonb, %s, %s, %s)
            ON CONFLICT (fill_id) DO NOTHING
            RETURNING event_id
            """,
            (
                record.event_id, record.fill_id, record.order_id,
                record.trade_id,
                json.dumps(dict(record.payload), sort_keys=True),
                record.state.value, record.attempts, record.last_error,
            ),
        )
        return row is not None


def _rowcount(result: Any) -> int:
    return int(getattr(result, "rowcount", result))
