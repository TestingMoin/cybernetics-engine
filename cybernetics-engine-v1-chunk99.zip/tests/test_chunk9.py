from cybernetics.intelligence.iceberg import DepthLevel, MarketObservation, IcebergDetector
from cybernetics.intelligence.scanner import build_example_scanners

def obs():
    return MarketObservation(
        ts=1.0, exchange="NSE", scanner_group="NSE-INDEX",
        asset="INDEX", instrument="NIFTY", underlying="NIFTY",
        price=100.0, volume=2500,
        depth_bid=(DepthLevel(99.9, 1000), DepthLevel(99.8, 300)),
        depth_ask=(DepthLevel(100.1, 400),),
    )

def test_detector_can_flag_observable_absorption():
    d=IcebergDetector()
    e=d.detect(obs(), prior_traded_volumes=[900,1000,1100], repeated_replenishment=.9,
               price_stability_score=.9, trade_cluster_score=.8, oi_confirmation=.7,
               regime="TREND_UP")
    assert e is not None
    assert "relative_volume_anomaly" in e.evidence
    assert e.direction in {"BUY","SELL"}

def test_hidden_order_claim_is_not_present():
    assert "hidden_order" not in IcebergDetector.detect.__doc__.lower()

def test_low_evidence_is_rejected():
    d=IcebergDetector()
    e=d.detect(obs(), prior_traded_volumes=[1200,1300,1400],
               repeated_replenishment=.1, price_stability_score=.1,
               trade_cluster_score=.1)
    assert e is None

def test_scanner_isolation():
    s=build_example_scanners()
    assert s["ICE-NIFTY"].config.assets == ("NIFTY",)
    assert s["ICE-BANKNIFTY"].config.assets == ("BANKNIFTY",)
    assert s["ICE-NIFTY"].config.assets != s["ICE-BANKNIFTY"].config.assets

def test_event_never_contains_execution_method():
    e=IcebergDetector().detect(obs(), prior_traded_volumes=[900,1000,1100],
               repeated_replenishment=.9, price_stability_score=.9,
               trade_cluster_score=.8)
    assert e is not None
    assert not hasattr(e, "place_order")
