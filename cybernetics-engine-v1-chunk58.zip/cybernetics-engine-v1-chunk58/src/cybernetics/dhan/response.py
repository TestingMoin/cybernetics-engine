from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Any, Mapping, Optional

class DhanOrderStatus(str, Enum):
    TRANSIT="TRANSIT"
    PENDING="PENDING"
    PART_TRADED="PART_TRADED"
    TRADED="TRADED"
    REJECTED="REJECTED"
    CANCELLED="CANCELLED"
    EXPIRED="EXPIRED"
    CLOSED="CLOSED"
    TRIGGERED="TRIGGERED"
    UNKNOWN="UNKNOWN"

@dataclass(frozen=True)
class DhanOrderResponse:
    order_id:str
    correlation_id:Optional[str]
    status:DhanOrderStatus
    transaction_type:Optional[str]=None
    exchange_segment:Optional[str]=None
    security_id:Optional[str]=None
    quantity:Optional[int]=None
    filled_quantity:int=0
    remaining_quantity:Optional[int]=None
    average_traded_price:Optional[float]=None
    raw:dict[str,Any]|None=None

class DhanResponseNormalizer:
    """
    Normalizes Dhan order responses into one broker-neutral response model.

    Dhan's V2 docs expose PART_TRADED and execution quantities/average traded
    price in order status responses; status nomenclature also includes
    TRANSIT/PENDING/REJECTED/CANCELLED/TRADED/EXPIRED. Super Order adds
    CLOSED/TRIGGERED. Unknown values are retained as UNKNOWN rather than guessed.
    """
    _MAP={s.value:s for s in DhanOrderStatus}

    def normalize(self,payload:Mapping[str,Any])->DhanOrderResponse:
        if not payload.get("orderId"):
            raise ValueError("dhan_response_order_id_required")
        raw_status=str(payload.get("orderStatus","UNKNOWN")).upper()
        status=self._MAP.get(raw_status,DhanOrderStatus.UNKNOWN)

        filled=self._first_int(payload,"filledQty","filled_qty","filledQuantity") or 0
        remaining=self._first_int(payload,"remainingQuantity","remaining_quantity")
        avg=self._first_float(payload,"averageTradedPrice","average_traded_price")

        return DhanOrderResponse(
            order_id=str(payload["orderId"]),
            correlation_id=self._optional_str(payload.get("correlationId")),
            status=status,
            transaction_type=self._optional_str(payload.get("transactionType")),
            exchange_segment=self._optional_str(payload.get("exchangeSegment")),
            security_id=self._optional_str(payload.get("securityId")),
            quantity=self._first_int(payload,"quantity"),
            filled_quantity=filled,
            remaining_quantity=remaining,
            average_traded_price=avg,
            raw=dict(payload),
        )

    @staticmethod
    def _optional_str(v):
        return None if v is None else str(v)

    @staticmethod
    def _first_int(d,*keys):
        for k in keys:
            if d.get(k) is not None and d.get(k)!="":
                return int(d[k])
        return None

    @staticmethod
    def _first_float(d,*keys):
        for k in keys:
            if d.get(k) is not None and d.get(k)!="":
                return float(d[k])
        return None
