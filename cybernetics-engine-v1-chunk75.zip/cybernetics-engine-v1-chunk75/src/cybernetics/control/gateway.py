from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import time
from typing import Callable, Protocol

from cybernetics.runtime.control import (
    ControlAction,
    ControlState,
    GuardedController,
    InvalidTransition,
    TransitionPolicy,
)


class CommandName(str, Enum):
    ENGINE_START = "ENGINE_START"
    ENGINE_START_SUCCESS = "ENGINE_START_SUCCESS"
    ENGINE_START_FAILURE = "ENGINE_START_FAILURE"
    STOP_NEW_TRADES = "STOP_NEW_TRADES"
    RESUME_NEW_TRADES = "RESUME_NEW_TRADES"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    BEGIN_RECOVERY = "BEGIN_RECOVERY"
    RECOVERY_COMPLETE = "RECOVERY_COMPLETE"
    ENGINE_SHUTDOWN = "ENGINE_SHUTDOWN"


_COMMAND_MAP = {
    CommandName.ENGINE_START: ControlAction.START,
    CommandName.ENGINE_START_SUCCESS: ControlAction.START_SUCCESS,
    CommandName.ENGINE_START_FAILURE: ControlAction.START_FAILURE,
    CommandName.STOP_NEW_TRADES: ControlAction.STOP_NEW_TRADES,
    CommandName.RESUME_NEW_TRADES: ControlAction.RESUME_NEW_TRADES,
    CommandName.EMERGENCY_STOP: ControlAction.EMERGENCY_STOP,
    CommandName.BEGIN_RECOVERY: ControlAction.BEGIN_RECOVERY,
    CommandName.RECOVERY_COMPLETE: ControlAction.RECOVERY_COMPLETE,
    CommandName.ENGINE_SHUTDOWN: ControlAction.SHUTDOWN,
}


class CommandResult(str, Enum):
    ACCEPTED = "ACCEPTED"
    DUPLICATE = "DUPLICATE"
    REJECTED = "REJECTED"
    STALE = "STALE"


@dataclass(frozen=True)
class ControlCommand:
    command_id: str
    command: CommandName
    issued_at: float
    source: str
    expected_state: ControlState | None = None


@dataclass(frozen=True)
class CommandReceipt:
    command_id: str
    result: CommandResult
    state: ControlState
    reason: str


class CommandIdStore(Protocol):
    def seen(self, command_id: str) -> bool: ...
    def remember(self, command_id: str) -> None: ...


class AuditSink(Protocol):
    def record(
        self,
        *,
        command_id: str,
        command: str,
        source: str,
        result: str,
        state: str,
        reason: str,
        issued_at: float,
    ) -> None: ...


@dataclass(frozen=True)
class GatewayPolicy:
    max_command_age_seconds: float = 30.0
    allowed_sources: frozenset[str] = frozenset({"PWA", "TELEGRAM", "SYSTEM"})
    require_expected_state_for_external_resume: bool = True

    def __post_init__(self):
        if self.max_command_age_seconds <= 0:
            raise ValueError("max_command_age_must_be_positive")


class ControlCommandGateway:
    """
    Single command boundary for external control surfaces.

    Responsibilities:
    - validate identity/source/timestamp
    - reject duplicate and stale commands
    - enforce optional optimistic state matching
    - delegate actual state transitions to the guarded state machine
    - emit an audit event for every accepted/rejected/stale/duplicate command

    It never talks to a broker and never creates live authorization.
    """

    def __init__(
        self,
        controller: GuardedController,
        id_store: CommandIdStore,
        audit: AuditSink,
        *,
        policy: GatewayPolicy | None = None,
        clock: Callable[[], float] = time.time,
    ):
        self.controller = controller
        self.id_store = id_store
        self.audit = audit
        self.policy = policy or GatewayPolicy()
        self.clock = clock

    def _receipt(
        self,
        cmd: ControlCommand,
        result: CommandResult,
        reason: str,
    ) -> CommandReceipt:
        receipt = CommandReceipt(
            command_id=cmd.command_id,
            result=result,
            state=self.controller.machine.state,
            reason=reason,
        )
        self.audit.record(
            command_id=cmd.command_id,
            command=cmd.command.value,
            source=cmd.source,
            result=result.value,
            state=receipt.state.value,
            reason=reason,
            issued_at=cmd.issued_at,
        )
        return receipt

    def handle(
        self,
        cmd: ControlCommand,
        *,
        policy: TransitionPolicy | None = None,
    ) -> CommandReceipt:
        if not cmd.command_id:
            return self._receipt(cmd, CommandResult.REJECTED, "command_id_required")
        if cmd.source not in self.policy.allowed_sources:
            return self._receipt(cmd, CommandResult.REJECTED, "source_not_allowed")

        age = self.clock() - cmd.issued_at
        if age < 0:
            return self._receipt(cmd, CommandResult.REJECTED, "command_from_future")
        if age > self.policy.max_command_age_seconds:
            return self._receipt(cmd, CommandResult.STALE, "command_expired")

        if self.id_store.seen(cmd.command_id):
            return self._receipt(cmd, CommandResult.DUPLICATE, "command_already_seen")

        if (
            cmd.command is CommandName.RESUME_NEW_TRADES
            and cmd.source in {"PWA", "TELEGRAM"}
            and self.policy.require_expected_state_for_external_resume
        ):
            if cmd.expected_state is None:
                return self._receipt(
                    cmd, CommandResult.REJECTED, "expected_state_required_for_resume"
                )

        if cmd.expected_state is not None and cmd.expected_state is not self.controller.machine.state:
            return self._receipt(cmd, CommandResult.REJECTED, "expected_state_mismatch")

        action = _COMMAND_MAP[cmd.command]

        try:
            state = self.controller.apply(action, policy)
        except InvalidTransition as exc:
            return self._receipt(cmd, CommandResult.REJECTED, str(exc))

        self.id_store.remember(cmd.command_id)
        receipt = CommandReceipt(
            command_id=cmd.command_id,
            result=CommandResult.ACCEPTED,
            state=state,
            reason="command_applied",
        )
        self.audit.record(
            command_id=cmd.command_id,
            command=cmd.command.value,
            source=cmd.source,
            result=receipt.result.value,
            state=state.value,
            reason=receipt.reason,
            issued_at=cmd.issued_at,
        )
        return receipt
