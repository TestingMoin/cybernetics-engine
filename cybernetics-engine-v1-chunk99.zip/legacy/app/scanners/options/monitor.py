from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any

from app.options.engine_adapter import OptionsEngineAdapter


@dataclass(frozen=True)
class OptionChainRequest:
    scanner_id: str
    underlying: str
    security_id: int
    underlying_segment: str
    expiry: date


@dataclass
class OptionsSnapshot:
    scanner_id: str
    underlying: str
    security_id: int
    expiry: date
    captured_at: datetime
    underlying_price: float
    report: Any
    data_quality: Any
    metadata: dict[str, Any] = field(default_factory=dict)


class OptionsSignalMonitor:
    """Independent state per underlying/options scanner.

    Multiple monitors may run concurrently, but each instance owns its own
    snapshot and never shares option-chain state with another underlying.
    """

    def __init__(self, request: OptionChainRequest, engine: OptionsEngineAdapter | None = None) -> None:
        self.request = request
        self.engine = engine or OptionsEngineAdapter()
        self.last_snapshot: OptionsSnapshot | None = None

    def analyze_rows(self, rows: list[dict[str, Any]], underlying_price: float, source: str = "") -> OptionsSnapshot:
        chain = self.engine.build_chain(rows, source=source)
        quality = self.engine.audit(chain)
        report = self.engine.analyze(chain, underlying_price, self.request.expiry)
        snapshot = OptionsSnapshot(
            scanner_id=self.request.scanner_id,
            underlying=self.request.underlying,
            security_id=self.request.security_id,
            expiry=self.request.expiry,
            captured_at=datetime.now(timezone.utc),
            underlying_price=underlying_price,
            report=report,
            data_quality=quality,
        )
        self.last_snapshot = snapshot
        return snapshot
