import pytest
from cybernetics.position.manager import FillEvent,PositionManager,PositionSide
def f(i,s,q,p,fee=0): return FillEvent(i,"O1","T1","NIFTY",s,q,p,fee)
def test_flat_long():
    s=PositionManager().apply_fill(f("1","BUY",10,100))
    assert (s.side,s.quantity,s.average_entry_price)==(PositionSide.LONG,10,100)
def test_flat_short():
    s=PositionManager().apply_fill(f("1","SELL",10,100))
    assert (s.side,s.quantity,s.average_entry_price)==(PositionSide.SHORT,10,100)
def test_average_long():
    p=PositionManager();p.apply_fill(f("1","BUY",10,100));s=p.apply_fill(f("2","BUY",10,110))
    assert s.quantity==20 and s.average_entry_price==105
def test_partial_long_close():
    p=PositionManager();p.apply_fill(f("1","BUY",10,100));s=p.apply_fill(f("2","SELL",4,110))
    assert s.quantity==6 and s.realized_pnl==40
def test_full_long_close():
    p=PositionManager();p.apply_fill(f("1","BUY",10,100));s=p.apply_fill(f("2","SELL",10,90))
    assert s.side==PositionSide.FLAT and s.realized_pnl==-100
def test_partial_short_close():
    p=PositionManager();p.apply_fill(f("1","SELL",10,100));s=p.apply_fill(f("2","BUY",4,90))
    assert s.quantity==6 and s.realized_pnl==40
def test_average_short():
    p=PositionManager();p.apply_fill(f("1","SELL",10,100));s=p.apply_fill(f("2","SELL",10,110))
    assert s.quantity==20 and s.average_entry_price==105
def test_long_short_reversal():
    p=PositionManager();p.apply_fill(f("1","BUY",10,100));s=p.apply_fill(f("2","SELL",15,110))
    assert s.side==PositionSide.SHORT and s.quantity==5 and s.realized_pnl==100 and s.average_entry_price==110
def test_short_long_reversal():
    p=PositionManager();p.apply_fill(f("1","SELL",10,100));s=p.apply_fill(f("2","BUY",15,90))
    assert s.side==PositionSide.LONG and s.quantity==5 and s.realized_pnl==100 and s.average_entry_price==90
def test_duplicate_fill_idempotent():
    p=PositionManager();p.apply_fill(f("1","BUY",10,100));a=p.apply_fill(f("2","SELL",4,110));b=p.apply_fill(f("2","SELL",4,110))
    assert a==b
def test_fees():
    p=PositionManager();p.apply_fill(f("1","BUY",10,100,5))
    assert p.snapshot("NIFTY").fees==5 and p.total_pnl("NIFTY")==-5
def test_mtm_long():
    p=PositionManager();p.apply_fill(f("1","BUY",10,100));assert p.mark_to_market("NIFTY",108).unrealized_pnl==80
def test_mtm_short():
    p=PositionManager();p.apply_fill(f("1","SELL",10,100));assert p.mark_to_market("NIFTY",93).unrealized_pnl==70
def test_invalid_fill():
    with pytest.raises(ValueError): f("1","HOLD",1,100)
def test_invalid_mark():
    with pytest.raises(ValueError): PositionManager().mark_to_market("NIFTY",0)
