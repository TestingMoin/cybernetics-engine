from cybernetics.strategy.state import (
    PositionState, StrategyStateBook, PositionAwareDecisionEngine
)

def setup():
    b=StrategyStateBook()
    e=PositionAwareDecisionEngine(b)
    return b,e

def test_flat_allows_long():
    _,e=setup()
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="ENTER_LONG")
    assert not r.blocked and r.final_action=="ENTER_LONG"

def test_flat_allows_short():
    _,e=setup()
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="ENTER_SHORT")
    assert not r.blocked and r.final_action=="ENTER_SHORT"

def test_duplicate_long_entry_blocked():
    b,e=setup(); b.set_position("NIFTY",PositionState.LONG,1,100)
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="ENTER_LONG")
    assert r.blocked and r.final_action=="HOLD"

def test_duplicate_short_entry_blocked():
    b,e=setup(); b.set_position("NIFTY",PositionState.SHORT,1,100)
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="ENTER_SHORT")
    assert r.blocked and r.final_action=="HOLD"

def test_implicit_long_to_short_reversal_blocked():
    b,e=setup(); b.set_position("NIFTY",PositionState.LONG,1,100)
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="ENTER_SHORT")
    assert r.blocked and r.final_action=="NO_ACTION"

def test_implicit_short_to_long_reversal_blocked():
    b,e=setup(); b.set_position("NIFTY",PositionState.SHORT,1,100)
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="ENTER_LONG")
    assert r.blocked and r.final_action=="NO_ACTION"

def test_long_exit_allowed():
    b,e=setup(); b.set_position("NIFTY",PositionState.LONG,2,100)
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="EXIT_LONG")
    assert not r.blocked and r.final_action=="EXIT_LONG"

def test_long_exit_when_flat_blocked():
    _,e=setup()
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="EXIT_LONG")
    assert r.blocked and r.final_action=="NO_ACTION"

def test_position_invariants():
    b,_=setup()
    try:
        b.set_position("NIFTY",PositionState.FLAT,1)
        assert False
    except ValueError as exc:
        assert str(exc)=="flat_position_requires_zero_quantity"

def test_unknown_action_blocked():
    _,e=setup()
    r=e.gate(strategy_id="S",signal_id="X",underlying_key="NIFTY",requested_action="MAGIC")
    assert r.blocked and r.final_action=="NO_ACTION"
