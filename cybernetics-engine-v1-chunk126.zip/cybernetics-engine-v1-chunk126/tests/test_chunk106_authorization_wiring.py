from datetime import datetime, timedelta, timezone

from cybernetics.auth.token_manager import DhanTokenManager, TokenState
from cybernetics.config.settings import DeploymentConfig, TradingMode
from cybernetics.runtime.authorization import LiveAuthorization
from cybernetics.runtime.authorization_wiring import LiveAuthorizationRuntimeWiring


class StubToken:
    def __init__(self, state):
        self._state = state
    def state(self):
        return self._state


def live_config():
    return DeploymentConfig(
        environment="production",
        trading_mode=TradingMode.LIVE,
        live_approval_id="APP-1",
    )


def test_live_auth_requires_valid_token_and_approval():
    auth = LiveAuthorization().approve("APP-1")
    wiring = LiveAuthorizationRuntimeWiring(live_config(), StubToken(TokenState.VALID), auth)
    assert wiring.live_authorization_valid() is True


def test_renew_required_token_blocks_new_live_authorization():
    auth = LiveAuthorization().approve("APP-1")
    wiring = LiveAuthorizationRuntimeWiring(live_config(), StubToken(TokenState.RENEW_REQUIRED), auth)
    snap = wiring.snapshot()
    assert snap.authorized is False
    assert snap.reason == "dhan_token_not_valid"


def test_engine_control_or_emergency_are_not_inputs_to_live_auth():
    auth = LiveAuthorization().approve("APP-1")
    wiring = LiveAuthorizationRuntimeWiring(live_config(), StubToken(TokenState.VALID), auth)
    assert wiring.live_authorization_valid() is True


def test_paper_mode_cannot_produce_live_authorization():
    config = DeploymentConfig(environment="staging", trading_mode=TradingMode.PAPER, live_approval_id="APP-1")
    auth = LiveAuthorization().approve("APP-1")
    wiring = LiveAuthorizationRuntimeWiring(config, StubToken(TokenState.VALID), auth)
    snap = wiring.snapshot()
    assert snap.authorized is False
    assert snap.reason == "live_mode_not_enabled"


def test_unapproved_runtime_cannot_authorize_even_with_valid_token():
    auth = LiveAuthorization()
    wiring = LiveAuthorizationRuntimeWiring(live_config(), StubToken(TokenState.VALID), auth)
    assert wiring.live_authorization_valid() is False
    assert wiring.snapshot().reason == "runtime_authorization_not_approved"


def test_failed_token_probe_fails_closed():
    class Broken:
        def state(self):
            raise RuntimeError("boom")
    auth = LiveAuthorization().approve("APP-1")
    wiring = LiveAuthorizationRuntimeWiring(live_config(), Broken(), auth)
    snap = wiring.snapshot()
    assert snap.authorized is False
    assert snap.reason == "token_state_probe_failed"
