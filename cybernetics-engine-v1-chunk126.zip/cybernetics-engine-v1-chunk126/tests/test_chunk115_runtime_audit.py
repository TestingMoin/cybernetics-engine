from cybernetics.audit.events import AuditEventFactory, InMemoryAuditStore
from cybernetics.audit.runtime import PostgresEngineEventRepository, RuntimeAuditEmitter


class Result:
    rowcount = 1


class FakeTx:
    def __init__(self): self.calls=[]
    def execute(self, sql, params=()): self.calls.append((sql, params)); return Result()
    def __enter__(self): return self
    def __exit__(self, *args): pass


def test_runtime_lifecycle_event_is_emitted():
    store=InMemoryAuditStore(); emitter=RuntimeAuditEmitter(store)
    event=emitter.lifecycle("RUNNING", previous="STARTING")
    assert event.event_type=="RUNTIME_LIFECYCLE"
    assert store.count()==1
    assert event.payload["previous_state"]=="STARTING"


def test_readiness_event_records_trade_gate():
    store=InMemoryAuditStore(); emitter=RuntimeAuditEmitter(store)
    event=emitter.readiness(engine_ready=True, new_trades_allowed=False, reason="critical_dependency_failure")
    assert event.payload["engine_ready"] is True
    assert event.payload["new_trades_allowed"] is False


def test_postgres_engine_event_repository_is_idempotent_boundary():
    tx=FakeTx(); repo=PostgresEngineEventRepository(lambda:tx)
    event=AuditEventFactory().create("RUNTIME_READINESS", "runtime", {"engine_ready":False})
    repo.append(event); repo.append(event)
    assert len(tx.calls)==2
    assert all("ON CONFLICT (event_id) DO NOTHING" in sql for sql,_ in tx.calls)


def test_postgres_engine_event_serializes_payload_and_correlation_separately():
    tx=FakeTx(); repo=PostgresEngineEventRepository(lambda:tx)
    event=AuditEventFactory().create("RUNTIME_READINESS", "runtime", {"engine_ready":False,"correlation_id":"corr-1"})
    repo.append(event)
    params=tx.calls[0][1]
    assert params[5]=="corr-1"
    assert '"engine_ready": false' in params[6]
    assert "correlation_id" not in params[6]


def test_postgres_repository_uses_engine_events_table():
    tx=FakeTx(); repo=PostgresEngineEventRepository(lambda:tx)
    repo.append(AuditEventFactory().create("X","runtime",{}))
    assert "INSERT INTO engine_events" in tx.calls[0][0]


def test_migration_registers_engine_events_audit_boundary():
    from cybernetics.persistence.migration import ADDITIVE_MIGRATIONS
    assert [m.version for m in ADDITIVE_MIGRATIONS] == [2,3]
    assert ADDITIVE_MIGRATIONS[1].name == "engine_events_audit_boundary"
