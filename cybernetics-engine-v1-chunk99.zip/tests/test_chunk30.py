from cybernetics.transport.rate_limiter import RateLimitGovernor, LimitWindow
from cybernetics.transport.rest_client import DhanRestClient, RestResponse, RetryPolicy
from cybernetics.transport.dhan_policies import ORDER_LIMITS, QUOTE_LIMITS

def test_rate_governor_allows_within_capacity():
    clock=[0.0]
    sleeps=[]
    def now(): return clock[0]
    def sleep(x):
        sleeps.append(x)
        clock[0]+=x
    g=RateLimitGovernor([LimitWindow(2,1)],clock=now,sleeper=sleep)
    g.acquire(); g.acquire()
    assert sleeps==[]

def test_rate_governor_waits_before_third_request():
    clock=[0.0]; sleeps=[]
    def now(): return clock[0]
    def sleep(x):
        sleeps.append(x); clock[0]+=x
    g=RateLimitGovernor([LimitWindow(2,1)],clock=now,sleeper=sleep)
    g.acquire(); g.acquire(); g.acquire()
    assert sleeps and clock[0]>=1.0

def test_dhan_order_policy_matches_published_limits():
    assert [(x.capacity,x.seconds) for x in ORDER_LIMITS] == [(10,1),(250,60),(1000,3600),(7000,86400)]
    assert QUOTE_LIMITS[0].capacity==1

def test_retry_safe_retries_server_error():
    calls=[]
    def transport(method,url,headers,json=None,params=None):
        calls.append(1)
        if len(calls)<3:
            return RestResponse(503,{"error":"temporary"}, {})
        return RestResponse(200,{"ok":True},{})
    g=RateLimitGovernor([LimitWindow(100,1)])
    sleeps=[]
    c=DhanRestClient(transport,lambda:{"access-token":"T"},g,
                     RetryPolicy(max_attempts=3,base_delay=0,max_delay=0,jitter=0),
                     sleeper=sleeps.append)
    out=c.request("GET","https://x",retry_safe=True)
    assert out.status_code==200 and len(calls)==3

def test_non_retry_safe_request_fails_once():
    calls=[]
    def transport(method,url,headers,json=None,params=None):
        calls.append(1); raise TimeoutError("timeout")
    g=RateLimitGovernor([LimitWindow(100,1)])
    c=DhanRestClient(transport,lambda:{"access-token":"T"},g,
                     RetryPolicy(max_attempts=3),sleeper=lambda x:None)
    try:
        c.request("POST","https://x",retry_safe=False)
        assert False
    except TimeoutError:
        assert len(calls)==1

def test_token_provider_called_per_attempt():
    calls=[]
    def transport(method,url,headers,json=None,params=None):
        calls.append(headers["access-token"])
        return RestResponse(200,{}, {})
    g=RateLimitGovernor([LimitWindow(100,1)])
    c=DhanRestClient(transport,lambda:{"access-token":"T2"},g)
    c.request("GET","https://x",retry_safe=True)
    assert calls==["T2"]
