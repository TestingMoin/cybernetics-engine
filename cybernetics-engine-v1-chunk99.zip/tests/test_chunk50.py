from datetime import datetime, timezone
from cybernetics.risk.handoff import StrategyRiskHandoff
from cybernetics.risk.evaluator import (
    RiskDecision, RiskLimits, RiskPortfolioState, RiskRequestEvaluator
)

T = datetime(2026,5,1,9,30,tzinfo=timezone.utc)

def request(action="ENTER_LONG", mode="paper", **kw):
    d = dict(
        strategy_id="GOLDEN-NIFTY-SENSEX",
        strategy_version="1.0.0-reproduction-target",
        signal_id="SIG-1", trade_id="TRADE-1", underlying_key="NIFTY",
        timeframe="1m", action=action, timestamp=T,
        entry_reference_price=100.0, stop_reference_price=99.0,
        metadata={"execution_mode": mode}
    )
    d.update(kw)
    return StrategyRiskHandoff().create_request(**d).request

def portfolio(**kw):
    d = dict(realized_pnl_today=0, open_exposure=0, used_margin=0,
             available_margin=100000, emergency_stop=False, live_authorized=False)
    d.update(kw)
    return RiskPortfolioState(**d)

def evaluator(**kw):
    d = dict(max_daily_loss=5000, max_open_exposure=100000,
             max_trade_risk=1000, margin_buffer=0)
    d.update(kw)
    return RiskRequestEvaluator(RiskLimits(**d))

def test_normal_entry_approved():
    r = evaluator().evaluate(request(), portfolio=portfolio(),
                              proposed_quantity=5, contract_multiplier=1)
    assert r.decision == RiskDecision.APPROVED

def test_emergency_stop_blocks_entry():
    r = evaluator().evaluate(request(), portfolio=portfolio(emergency_stop=True),
                              proposed_quantity=1, contract_multiplier=1)
    assert r.reason == "emergency_stop_active"

def test_live_requires_authorization():
    r = evaluator().evaluate(request(mode="live"), portfolio=portfolio(),
                              proposed_quantity=1, contract_multiplier=1)
    assert r.reason == "live_authorization_missing"

def test_live_authorized_can_pass():
    r = evaluator().evaluate(request(mode="live"), portfolio=portfolio(live_authorized=True),
                              proposed_quantity=1, contract_multiplier=1)
    assert r.decision == RiskDecision.APPROVED

def test_invalid_quantity_rejected():
    r = evaluator().evaluate(request(), portfolio=portfolio(),
                              proposed_quantity=0, contract_multiplier=1)
    assert r.reason == "proposed_quantity_invalid"

def test_exposure_limit_rejected():
    r = evaluator(max_open_exposure=100).evaluate(
        request(), portfolio=portfolio(open_exposure=90),
        proposed_quantity=2, contract_multiplier=10
    )
    assert r.reason == "max_open_exposure_exceeded"

def test_trade_risk_limit_rejected():
    r = evaluator(max_trade_risk=5).evaluate(
        request(), portfolio=portfolio(),
        proposed_quantity=10, contract_multiplier=1
    )
    assert r.reason == "max_trade_risk_exceeded"

def test_daily_loss_limit_rejected():
    r = evaluator(max_daily_loss=5000).evaluate(
        request(), portfolio=portfolio(realized_pnl_today=-5000),
        proposed_quantity=1, contract_multiplier=1
    )
    assert r.reason == "daily_loss_limit_reached"

def test_exit_is_allowed_during_loss_limit():
    r = evaluator().evaluate(
        request(action="EXIT_LONG"), portfolio=portfolio(realized_pnl_today=-100000),
        proposed_quantity=1, contract_multiplier=1
    )
    assert r.decision == RiskDecision.APPROVED

def test_missing_entry_price_rejected_for_entry():
    r = evaluator().evaluate(
        request(entry_reference_price=None),
        portfolio=portfolio(), proposed_quantity=1, contract_multiplier=1
    )
    assert r.reason == "entry_price_required"

def test_contract_multiplier_must_be_positive():
    r = evaluator().evaluate(
        request(), portfolio=portfolio(), proposed_quantity=1, contract_multiplier=0
    )
    assert r.reason == "contract_multiplier_invalid"
