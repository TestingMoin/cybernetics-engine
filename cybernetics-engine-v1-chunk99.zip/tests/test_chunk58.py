import pytest
from cybernetics.dhan.response import DhanOrderStatus,DhanResponseNormalizer
from cybernetics.trading.response_binding import BrokerResponseLifecycleBinder,LedgerOrderState

N=DhanResponseNormalizer(); B=BrokerResponseLifecycleBinder()

def resp(status="PENDING",**kw):
    d={"orderId":"OID1","correlationId":"CORR1","orderStatus":status,
       "transactionType":"BUY","exchangeSegment":"NSE_FNO","securityId":"123",
       "quantity":10,"filledQty":0,"remainingQuantity":10,
       "averageTradedPrice":0}
    d.update(kw); return d

def test_pending_normalizes():
    r=N.normalize(resp())
    assert r.status==DhanOrderStatus.PENDING

def test_partial_fill_normalizes_and_preserves_quantities():
    r=N.normalize(resp("PART_TRADED",filledQty=4,remainingQuantity=6,averageTradedPrice=101.25))
    assert r.status==DhanOrderStatus.PART_TRADED
    assert r.filled_quantity==4
    assert r.remaining_quantity==6
    assert r.average_traded_price==101.25

def test_traded_maps_filled():
    e=B.bind(N.normalize(resp("TRADED",filledQty=10,remainingQuantity=0,averageTradedPrice=101)))
    assert e.state==LedgerOrderState.FILLED and e.terminal

def test_rejected_maps_terminal_rejected():
    e=B.bind(N.normalize(resp("REJECTED")))
    assert e.state==LedgerOrderState.REJECTED and e.terminal

def test_cancelled_maps_terminal_cancelled():
    e=B.bind(N.normalize(resp("CANCELLED")))
    assert e.state==LedgerOrderState.CANCELLED and e.terminal

def test_expired_maps_terminal_expired():
    e=B.bind(N.normalize(resp("EXPIRED")))
    assert e.state==LedgerOrderState.EXPIRED and e.terminal

def test_transit_is_not_terminal():
    e=B.bind(N.normalize(resp("TRANSIT")))
    assert e.state==LedgerOrderState.PENDING and not e.terminal

def test_closed_maps_filled():
    e=B.bind(N.normalize(resp("CLOSED")))
    assert e.state==LedgerOrderState.FILLED and e.terminal

def test_triggered_not_treated_as_filled():
    e=B.bind(N.normalize(resp("TRIGGERED")))
    assert e.state==LedgerOrderState.PENDING and not e.terminal

def test_unknown_status_is_safe():
    e=B.bind(N.normalize(resp("FUTURE_STATUS")))
    assert e.state==LedgerOrderState.UNKNOWN and not e.terminal

def test_missing_order_id_rejected():
    with pytest.raises(ValueError,match="dhan_response_order_id_required"):
        N.normalize({"orderStatus":"PENDING"})

def test_negative_fill_rejected():
    r=N.normalize(resp("PART_TRADED",filledQty=-1,remainingQuantity=11))
    with pytest.raises(ValueError,match="filled_quantity_invalid"):
        B.bind(r)

def test_raw_payload_preserved_for_audit():
    p=resp("TRADED",filledQty=10,remainingQuantity=0,averageTradedPrice=101.5)
    r=N.normalize(p)
    assert r.raw["orderId"]=="OID1"
    assert r.raw["averageTradedPrice"]==101.5

def test_correlation_id_preserved():
    r=N.normalize(resp())
    assert r.correlation_id=="CORR1"
