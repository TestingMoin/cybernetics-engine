#!/usr/bin/env bash
set -euo pipefail

ROOT=/opt/cybernetics-engine
SERVICE_DIR=/etc/cybernetics-engine
RELEASE="${1:-}"

if [[ -z "$RELEASE" ]]; then
  echo "usage: install_staging.sh /opt/cybernetics-engine/releases/<release>" >&2
  exit 2
fi
if [[ ! -d "$RELEASE" ]]; then
  echo "release directory not found: $RELEASE" >&2
  exit 2
fi

if ! id cybernetics >/dev/null 2>&1; then
  echo "required system user cybernetics is missing" >&2
  exit 3
fi

sudo install -d -o cybernetics -g cybernetics "$ROOT/current" "$ROOT/logs" "$ROOT/backups" "$ROOT/staging" "$ROOT/secrets"
sudo install -d -o root -g cybernetics -m 0750 "$SERVICE_DIR"
sudo install -m 0644 "$RELEASE/deploy/systemd/cybernetics-engine.service" /etc/systemd/system/cybernetics-engine.service
sudo install -m 0640 -o root -g cybernetics "$RELEASE/deploy/config/cybernetics-engine.env.example" "$SERVICE_DIR/cybernetics-engine.env.example"

sudo rm -rf "$ROOT/current.next"
sudo cp -a "$RELEASE" "$ROOT/current.next"
sudo chown -R cybernetics:cybernetics "$ROOT/current.next"
sudo rm -rf "$ROOT/current"
sudo mv "$ROOT/current.next" "$ROOT/current"

if [[ ! -x "$ROOT/venv/bin/cybernetics-engine" ]]; then
  echo "venv executable not present; create the venv and install the wheel before starting the service" >&2
  exit 4
fi

sudo systemctl daemon-reload
sudo systemctl enable cybernetics-engine
sudo systemctl stop cybernetics-engine || true
sudo -u cybernetics "$ROOT/venv/bin/cybernetics-engine" --self-check
sudo systemctl start cybernetics-engine
sudo systemctl --no-pager --full status cybernetics-engine
