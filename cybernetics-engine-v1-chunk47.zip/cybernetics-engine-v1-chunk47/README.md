# Cybernetics Trading Engine — Chunk 47

## Strategy State & Position-Aware Decision Management

This chunk adds a deterministic position-state boundary after strategy evaluation.

Supported states:
- FLAT
- LONG
- SHORT

The state gate blocks duplicate entries and prevents implicit reversals.

Examples:
- FLAT + ENTER_LONG -> ENTER_LONG
- LONG + ENTER_LONG -> HOLD / blocked
- SHORT + ENTER_LONG -> NO_ACTION / blocked
- LONG + EXIT_LONG -> EXIT_LONG
- FLAT + EXIT_LONG -> NO_ACTION / blocked

Reversal is deliberately not automatic. A future controlled reversal workflow must
explicitly define close-existing-position, risk validation, and new-entry sequencing.

This layer does not execute orders, calculate quantity, bypass Risk, or update broker
state. Durable position truth remains a responsibility of the persistent position /
reconciliation layers.
