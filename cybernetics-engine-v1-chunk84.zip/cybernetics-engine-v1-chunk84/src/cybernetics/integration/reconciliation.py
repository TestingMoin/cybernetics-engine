from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable


class ReconciliationStatus(str, Enum):
    PENDING = "PENDING"
    RESOLVED = "RESOLVED"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class InterfaceFinding:
    interface: str
    evidence: tuple[str, ...]
    blocking: bool


@dataclass(frozen=True)
class ReconciliationReport:
    resolved: tuple[str, ...]
    blocked: tuple[str, ...]
    findings: tuple[InterfaceFinding, ...]
    status: ReconciliationStatus


class InterfaceReconciler:
    """
    Tracks explicit resolution of interface conflicts discovered by Chunk 83.

    It does not declare an interface resolved merely because a newer chunk exists.
    Resolution is an explicit action backed by evidence.
    """

    def __init__(self, required_interfaces: Iterable[str]):
        self.required = tuple(dict.fromkeys(required_interfaces))

    def report(self, resolutions: dict[str, tuple[str, ...]]) -> ReconciliationReport:
        resolved=[]
        blocked=[]
        findings=[]

        for interface in self.required:
            evidence=resolutions.get(interface, ())
            if evidence:
                resolved.append(interface)
                findings.append(
                    InterfaceFinding(interface, tuple(evidence), False)
                )
            else:
                blocked.append(interface)
                findings.append(
                    InterfaceFinding(interface, (), True)
                )

        status=(
            ReconciliationStatus.RESOLVED
            if not blocked
            else ReconciliationStatus.BLOCKED
        )
        return ReconciliationReport(
            tuple(resolved),tuple(blocked),tuple(findings),status
        )


HIGH_IMPACT_INTERFACES = (
    "websocket.subscriptions",
    "signals.lifecycle",
    "strategy.models",
    "execution.instrument",
    "dhan.payload",
)
