# Cybernetics Trading Engine — Chunk 41

## Indicator Registry Integration + Expanded Deterministic Indicator Library

Adds a versioned catalog and reusable individual indicators.

Core: EMA, SMA, WMA, RSI, ATR, Bollinger Bands, ROC, Highest, Lowest.
Advanced: Stochastic %K/%D, MACD, ADX, OBV, VWAP.

The registry stores indicator ID, version, family, tier and computation function.

This remains an individual-indicator layer only. No confluence, strategy combination,
entry/exit logic or broker execution is introduced.
