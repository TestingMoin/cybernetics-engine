import asyncio
from datetime import date

from cybernetics.options import OptionChainCoordinator, OptionChainNormalizer, UnderlyingRef, choose_atm_strike, nearby_strikes


def test_normalization_and_atm():
    u = UnderlyingRef("OPT-NIFTY", "NIFTY", 13, "IDX_I")
    from cybernetics.options.chain_coordinator import ChainRequest
    snap = OptionChainNormalizer.normalize(
        {"data": {"last_price": 22487.0, "oc": {
            "22450.0": {"ce": {"security_id": 1, "last_price": 100}, "pe": {"security_id": 2}},
            "22500.0": {"ce": {"security_id": 3}, "pe": {"security_id": 4}},
        }}},
        ChainRequest(u, date(2026, 9, 10)),
    )
    assert choose_atm_strike(snap) == 22500.0
    assert len(nearby_strikes(snap, 1)) == 2


def test_expiry_and_deduped_fetch():
    calls = []
    async def expiries(u):
        return ["2026-09-10", "2026-09-17"]
    async def chain(u, expiry):
        calls.append((u.symbol, expiry))
        return {"data": {"last_price": 100.0, "oc": {"100": {"ce": {}, "pe": {}}}}}
    async def run():
        c = OptionChainCoordinator(expiries, chain, request_interval_seconds=0.001)
        u = UnderlyingRef("OPT-NIFTY", "NIFTY", 13, "IDX_I")
        a, b = await asyncio.gather(c.get_chain(u), c.get_chain(u))
        assert a.strikes == b.strikes
        assert calls == [("NIFTY", date(2026, 9, 10))]
    asyncio.run(run())


def test_no_expiry():
    async def expiries(u): return []
    async def chain(u, expiry): raise AssertionError("must not be called")
    async def run():
        c = OptionChainCoordinator(expiries, chain)
        u = UnderlyingRef("OPT-NIFTY", "NIFTY", 13, "IDX_I")
        try:
            await c.get_chain(u)
        except LookupError:
            return
        raise AssertionError("expected LookupError")
    asyncio.run(run())
