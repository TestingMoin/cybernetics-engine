from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class IdempotencyRecord:
    client_order_key: str
    broker_order_id: Optional[str]
    status: str

class IdempotencyBackend:
    def get(self,key: str) -> Optional[IdempotencyRecord]:
        raise NotImplementedError
    def put_once(self,record: IdempotencyRecord) -> bool:
        raise NotImplementedError
    def update(self,record: IdempotencyRecord) -> None:
        raise NotImplementedError
