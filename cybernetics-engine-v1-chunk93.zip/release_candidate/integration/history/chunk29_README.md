# Cybernetics Trading Engine — Chunk 29

## Dhan Authentication / Token Lifecycle + Secure Secret Provider

The Dhan V2 authentication boundary now has:

- In-memory access-token lifecycle state.
- Direct TOTP-based access-token generation.
- Active-token renewal support.
- Expiry and refresh-margin detection.
- Central `access-token` header generation.
- Environment-variable secret provider.
- File-based secret provider with strict permissions.
- No credentials, PINs or TOTP values embedded in source.

Current Dhan documentation states individual access tokens are valid for 24 hours,
TOTP can be used for API-only token generation, and token renewal is available for
active tokens generated through Dhan Web. The implementation keeps these rules at
the authentication boundary and does not expose secrets to the strategy layer.

Live execution remains controlled by the separate execution gates.
