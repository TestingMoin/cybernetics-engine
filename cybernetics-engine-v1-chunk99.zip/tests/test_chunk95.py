from pathlib import Path
from cybernetics.persistence.migration import AUTHORITATIVE_MIGRATIONS, load_authoritative_schema, StartupSchemaValidator, PRODUCTION_STARTUP_REQUIRED_TABLES

ROOT = Path(__file__).resolve().parents[1]


def test_authoritative_schema_is_single_project_source():
    sql = load_authoritative_schema()
    assert Path(sql_path := ROOT / 'sql' / 'schema.sql').read_text(encoding='utf-8') == sql
    assert sql_path.exists()


def test_authoritative_schema_contains_order_identity_fields():
    sql = load_authoritative_schema()
    assert 'client_order_key TEXT' in sql
    assert 'broker_order_id TEXT' in sql
    assert 'ux_orders_client_order_key' in sql
    assert 'ux_orders_broker_order_id' in sql
    assert 'CREATE TABLE IF NOT EXISTS order_idempotency' in sql


def test_authoritative_schema_contains_all_durable_control_tables():
    sql = load_authoritative_schema()
    for table in ('schema_version','orders','fill_ledger','fill_outbox','control_command_audit','emergency_control_state'):
        assert f'CREATE TABLE IF NOT EXISTS {table}' in sql


def test_authoritative_migration_is_complete_baseline():
    assert [m.version for m in AUTHORITATIVE_MIGRATIONS] == [1]
    assert AUTHORITATIVE_MIGRATIONS[0].name == 'canonical_schema_baseline'
    assert 'CREATE TABLE IF NOT EXISTS orders' in AUTHORITATIVE_MIGRATIONS[0].sql


def test_startup_requires_order_and_control_persistence():
    validator = StartupSchemaValidator()
    r = validator.validate_production(existing_tables={'schema_version','orders','fill_ledger','fill_outbox'}, migration_version=1)
    assert not r.ready
    assert r.missing_tables == ('control_command_audit','emergency_control_state')


def test_inline_module_ddl_removed():
    paths = [
        ROOT/'src/cybernetics/control/migration.py',
        ROOT/'src/cybernetics/control/emergency_repository.py',
        ROOT/'src/cybernetics/persistence/fill_ledger.py',
        ROOT/'src/cybernetics/persistence/outbox.py',
    ]
    forbidden = ('CREATE TABLE IF NOT EXISTS',)
    for path in paths:
        text = path.read_text(encoding='utf-8')
        assert not any(token in text for token in forbidden)


def test_legacy_persistence_schema_has_no_second_table_definition():
    text = (ROOT/'src/cybernetics/persistence/schema.sql').read_text(encoding='utf-8')
    assert 'CREATE TABLE' not in text.upper()


def test_postgres_idempotency_does_not_insert_partial_orders():
    from cybernetics.persistence.postgres_ledger import PostgresOrderLedger
    assert 'INSERT INTO order_idempotency' in PostgresOrderLedger.UPSERT_SQL
    assert 'INSERT INTO orders' not in PostgresOrderLedger.UPSERT_SQL
    assert 'FROM order_idempotency' in PostgresOrderLedger.SELECT_SQL
    assert 'UPDATE order_idempotency' in PostgresOrderLedger.UPDATE_SQL


def test_production_required_tables_include_idempotency():
    assert 'order_idempotency' in load_authoritative_schema()
    assert 'order_idempotency' not in PRODUCTION_STARTUP_REQUIRED_TABLES  # optional integrity table; schema baseline remains required via schema validation
