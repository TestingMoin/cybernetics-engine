from __future__ import annotations
from pathlib import Path
import os
import stat

class EnvSecretProvider:
    """Reads secrets from process environment; never logs values."""
    def __init__(self, prefix: str = "CTE_"):
        self.prefix = prefix

    def get(self, name: str, required: bool = True) -> str | None:
        value = os.getenv(self.prefix + name)
        if required and not value:
            raise RuntimeError(f"missing_secret:{self.prefix}{name}")
        return value

class FileSecretProvider:
    """
    Reads one secret per file. Production files should be owned by the engine
    account with mode 0600. The provider rejects group/world-readable files.
    """
    def __init__(self, directory: str | Path):
        self.directory = Path(directory)

    def get(self, name: str, required: bool = True) -> str | None:
        path = self.directory / name
        if not path.exists():
            if required:
                raise RuntimeError(f"missing_secret_file:{path}")
            return None

        mode = stat.S_IMODE(path.stat().st_mode)
        if mode & (stat.S_IRWXG | stat.S_IRWXO):
            raise PermissionError(f"insecure_secret_file_mode:{oct(mode)}")

        value = path.read_text(encoding="utf-8").strip()
        if required and not value:
            raise RuntimeError(f"empty_secret_file:{path}")
        return value
