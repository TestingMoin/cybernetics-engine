from __future__ import annotations

import logging
import struct
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable

from app.marketdata.events import DepthLevel, MarketEvent

logger = logging.getLogger(__name__)

# Dhan V2 market-feed packet codes.
CODE_INDEX = 1
CODE_TICKER = 2
CODE_QUOTE = 4
CODE_OI = 5
CODE_PREV_CLOSE = 6
CODE_MARKET_STATUS = 7
CODE_FULL = 8
CODE_DISCONNECT = 50
HEADER_SIZE = 8

# Documented packet sizes. A tolerant parser also accepts shorter variants and
# rejects malformed/truncated packets instead of inventing values.
SIZE_TICKER = 16
SIZE_PREV_CLOSE = 16
SIZE_QUOTE = 50
SIZE_OI = 12
SIZE_FULL = 162
SIZE_DISCONNECT = 14


@dataclass(frozen=True, slots=True)
class PacketHeader:
    feed_code: int
    message_length: int
    exchange_segment: int
    security_id: int


def _u32(buf: bytes, offset: int) -> int:
    return struct.unpack_from("<I", buf, offset)[0]


def _i32(buf: bytes, offset: int) -> int:
    return struct.unpack_from("<i", buf, offset)[0]


def _u16(buf: bytes, offset: int) -> int:
    return struct.unpack_from("<H", buf, offset)[0]


def _i16(buf: bytes, offset: int) -> int:
    return struct.unpack_from("<h", buf, offset)[0]


def _f32(buf: bytes, offset: int) -> float:
    return struct.unpack_from("<f", buf, offset)[0]


def parse_header(data: bytes, offset: int = 0) -> PacketHeader:
    if len(data) - offset < HEADER_SIZE:
        raise ValueError("market packet shorter than 8-byte Dhan response header")
    feed_code = data[offset]
    message_length = _u16(data, offset + 1)
    exchange_segment = data[offset + 3]
    security_id = _u32(data, offset + 4)
    return PacketHeader(feed_code, message_length, exchange_segment, security_id)


def _packet_total_length(header: PacketHeader, remaining: int) -> int:
    """Return bytes belonging to this packet.

    Dhan documents message length as the length of the entire payload packet.
    For defensive compatibility, values smaller than the fixed header are also
    interpreted as payload-only lengths. The caller still bounds-checks the result.
    """
    n = header.message_length
    if n >= HEADER_SIZE:
        return n
    return HEADER_SIZE + n


def _epoch(value: int) -> datetime | None:
    if value <= 0:
        return None
    try:
        return datetime.fromtimestamp(value, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


def _depth_5(buf: bytes, start: int) -> tuple[DepthLevel, ...]:
    levels: list[DepthLevel] = []
    for i in range(5):
        p = start + (i * 20)
        if p + 20 > len(buf):
            break
        bid_qty = _i32(buf, p)
        ask_qty = _i32(buf, p + 4)
        bid_orders = _i16(buf, p + 8)
        ask_orders = _i16(buf, p + 10)
        bid_price = _f32(buf, p + 12)
        ask_price = _f32(buf, p + 16)
        levels.append(DepthLevel("bid", float(bid_price), max(0, bid_qty), max(0, bid_orders)))
        levels.append(DepthLevel("ask", float(ask_price), max(0, ask_qty), max(0, ask_orders)))
    return tuple(levels)


def _parse_single(data: bytes, received_at: datetime | None = None) -> MarketEvent:
    received_at = received_at or datetime.now(timezone.utc)
    h = parse_header(data)
    if len(data) < HEADER_SIZE:
        raise ValueError("truncated market packet")
    sid = str(h.security_id)
    base = dict(
        packet_kind={CODE_INDEX: "index", CODE_TICKER: "ticker", CODE_QUOTE: "quote", CODE_OI: "oi",
                     CODE_PREV_CLOSE: "prev_close", CODE_MARKET_STATUS: "market_status", CODE_FULL: "full",
                     CODE_DISCONNECT: "disconnect"}.get(h.feed_code, "unknown"),
        exchange_segment=h.exchange_segment,
        security_id=sid,
        received_at=received_at,
        raw_length=len(data),
        feed_code=h.feed_code,
    )
    if h.feed_code == CODE_TICKER and len(data) >= SIZE_TICKER:
        return MarketEvent(**base, last_price=float(_f32(data, 8)), trade_time=_epoch(_u32(data, 12)))
    if h.feed_code == CODE_PREV_CLOSE and len(data) >= SIZE_PREV_CLOSE:
        return MarketEvent(**base, prev_close=float(_f32(data, 8)), prev_oi=_i32(data, 12))
    if h.feed_code == CODE_QUOTE and len(data) >= SIZE_QUOTE:
        return MarketEvent(
            **base, last_price=float(_f32(data, 8)), last_quantity=max(0, _i16(data, 12)),
            trade_time=_epoch(_i32(data, 14)), avg_trade_price=float(_f32(data, 18)), volume=max(0, _i32(data, 22)),
            total_sell_quantity=max(0, _i32(data, 26)), total_buy_quantity=max(0, _i32(data, 30)),
            day_open=float(_f32(data, 34)), day_close=float(_f32(data, 38)), day_high=float(_f32(data, 42)),
            day_low=float(_f32(data, 46)),
        )
    if h.feed_code == CODE_OI and len(data) >= SIZE_OI:
        return MarketEvent(**base, open_interest=max(0, _i32(data, 8)))
    if h.feed_code == CODE_FULL and len(data) >= SIZE_FULL:
        return MarketEvent(
            **base, last_price=float(_f32(data, 8)), last_quantity=max(0, _i16(data, 12)),
            trade_time=_epoch(_i32(data, 14)), avg_trade_price=float(_f32(data, 18)), volume=max(0, _i32(data, 22)),
            total_sell_quantity=max(0, _i32(data, 26)), total_buy_quantity=max(0, _i32(data, 30)),
            open_interest=max(0, _i32(data, 34)), highest_oi=max(0, _i32(data, 38)), lowest_oi=max(0, _i32(data, 42)),
            day_open=float(_f32(data, 46)), day_close=float(_f32(data, 50)), day_high=float(_f32(data, 54)), day_low=float(_f32(data, 58)),
            depth=_depth_5(data, 62),
        )
    if h.feed_code == CODE_DISCONNECT and len(data) >= SIZE_DISCONNECT:
        return MarketEvent(**base, error_code=_i16(data, 12))
    return MarketEvent(**base)


def iter_packets(data: bytes) -> Iterable[bytes]:
    """Yield length-delimited Dhan packets from one websocket binary message."""
    offset = 0
    total = len(data)
    while offset < total:
        remaining = total - offset
        if remaining < HEADER_SIZE:
            raise ValueError(f"trailing {remaining} bytes after final market packet")
        header = parse_header(data, offset)
        packet_len = _packet_total_length(header, remaining)
        if packet_len < HEADER_SIZE or packet_len > remaining:
            raise ValueError(
                f"invalid Dhan packet length={packet_len}, remaining={remaining}, code={header.feed_code}"
            )
        yield data[offset:offset + packet_len]
        offset += packet_len


def decode_message(data: bytes, received_at: datetime | None = None) -> list[MarketEvent]:
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("Dhan market message must be bytes-like")
    payload = bytes(data)
    timestamp = received_at or datetime.now(timezone.utc)
    events: list[MarketEvent] = []
    for packet in iter_packets(payload):
        events.append(_parse_single(packet, timestamp))
    return events
