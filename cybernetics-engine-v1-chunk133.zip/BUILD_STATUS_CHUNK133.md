# BUILD STATUS — CHUNK 133

Scope: Dhan V2 read-only broker/internal reconciliation runtime integration.

Implemented:
- Dhan order mapping/reconciliation using correlationId/client_order_key and broker orderId/broker_order_id.
- Quantity, fill quantity, status, symbol/side and average fill price checks.
- Dhan position reconciliation with conservative securityId/exchangeSegment identity protection.
- Durable reconciliation_events audit persistence with fingerprint de-duplication within process lifetime.
- PostgreSQLRuntimeAdapter now delegates reconciliation only when a real broker adapter is injected.
- Canonical main entrypoint injects the existing read-only Dhan adapter into PostgreSQL reconciliation.

Safety:
- No Dhan order placement/cancellation calls added.
- PAPER default unchanged.
- CYBERNETICS_ORDER_SUBMISSION_ENABLED remains false unless explicitly changed by deployment policy.
- Ambiguous or non-verifiable position identity remains blocked.

Important:
- The current PostgreSQL positions table contains only symbol/quantity/avg_price, so non-flat Dhan positions cannot be fully reconciled on stronger exchangeSegment+securityId identity yet.
