# Cybernetics Trading Engine — Chunk 84

## Interface Reconciliation — High-Impact Conflict Gate

Chunk 83 proved that the first physical merge compiles but historical tests
still expose incompatible public interfaces.

This chunk does NOT silently rewrite those modules.

Instead it establishes an explicit reconciliation gate for the five highest
impact interfaces discovered in the merge:

1. `websocket.subscriptions`
2. `signals.lifecycle`
3. `strategy.models`
4. `execution.instrument`
5. `dhan.payload`

Each interface must receive explicit evidence before it is marked RESOLVED.

The compatibility helper validates mapping contracts but deliberately refuses to
guess business semantics.

This prevents "make the tests green" changes that could accidentally alter
trading behavior.

Chunk 84 therefore is a governance/integration safety layer. Actual canonical
API selection and adapter implementation follow only after inspecting the
conflicting module definitions and their callers.

No broker calls and no production database mutation occur.
