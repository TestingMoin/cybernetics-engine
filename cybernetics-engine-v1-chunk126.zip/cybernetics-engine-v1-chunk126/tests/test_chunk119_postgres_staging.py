from __future__ import annotations

from cybernetics.db.staging import (
    ConnectionStatus,
    PostgreSQLConfigError,
    PostgreSQLStagingConfig,
    PostgreSQLStagingProbe,
)


class FakeConnection:
    def __init__(self, fail: bool = False):
        self.fail = fail
        self.closed = False

    def execute(self, query: str):
        assert query == "SELECT 1"
        if self.fail:
            raise RuntimeError("db unavailable")
        return 1

    def close(self):
        self.closed = True


def test_config_from_env_and_redaction():
    config = PostgreSQLStagingConfig.from_env({
        "CYBERNETICS_POSTGRES_DSN": "postgresql://trader:secret@127.0.0.1:5432/cybernetics",
    })
    assert config is not None
    assert "secret" not in config.redacted_dsn
    assert config.redacted_dsn == "postgresql://127.0.0.1:5432/cybernetics"


def test_missing_dsn_is_not_configured():
    assert PostgreSQLStagingConfig.from_env({}) is None


def test_invalid_scheme_rejected():
    try:
        PostgreSQLStagingConfig.from_env({"CYBERNETICS_POSTGRES_DSN": "mysql://host/db"})
    except PostgreSQLConfigError as exc:
        assert str(exc) == "postgres_dsn_scheme_invalid"
    else:
        raise AssertionError("expected PostgreSQLConfigError")


def test_probe_ready_and_closes_connection():
    holder = {}

    def connector(dsn, timeout, application):
        holder["args"] = (dsn, timeout, application)
        conn = FakeConnection()
        holder["conn"] = conn
        return conn

    config = PostgreSQLStagingConfig("postgresql://127.0.0.1/cybernetics")
    probe = PostgreSQLStagingProbe(config, connector)
    assert probe.status() is ConnectionStatus.READY
    assert holder["conn"].closed is True
    assert holder["args"][2] == "cybernetics-engine"


def test_probe_fails_closed_without_connector():
    config = PostgreSQLStagingConfig("postgresql://127.0.0.1/cybernetics")
    probe = PostgreSQLStagingProbe(config)
    assert probe.status() is ConnectionStatus.FAILED
    assert probe.ready() is False


def test_probe_fails_closed_when_database_fails():
    def connector(dsn, timeout, application):
        return FakeConnection(fail=True)

    config = PostgreSQLStagingConfig("postgresql://127.0.0.1/cybernetics")
    assert PostgreSQLStagingProbe(config, connector).status() is ConnectionStatus.FAILED
