import asyncio
from cybernetics.watchdog.health import HealthRegistry, HealthSupervisor, Health

def test_healthy_components_need_no_safe_state():
    r=HealthRegistry()
    r.beat("market_data", now=100)
    r.beat("database", now=100)
    d=HealthSupervisor().evaluate(r, required=("market_data","database"), heartbeat_timeout=10, now=105)
    assert not d.safe_state_required

def test_failed_component_requires_safe_state():
    r=HealthRegistry()
    r.beat("market_data", now=100)
    r.fail("database","connection lost", now=100)
    d=HealthSupervisor().evaluate(r, required=("market_data","database"), heartbeat_timeout=10, now=105)
    assert d.safe_state_required and "database:FAILED" in d.reasons

def test_stale_heartbeat_requires_safe_state():
    r=HealthRegistry()
    r.beat("market_data", now=100)
    d=HealthSupervisor().evaluate(r, required=("market_data",), heartbeat_timeout=10, now=111)
    assert d.safe_state_required

def test_missing_heartbeat_is_failure_condition():
    r=HealthRegistry()
    d=HealthSupervisor().evaluate(r, required=("dhan","database"), heartbeat_timeout=10, now=100)
    assert d.safe_state_required

def test_async_heartbeat_updates_registry():
    async def run():
        r=HealthRegistry(); stop=asyncio.Event()
        loop=asyncio.create_task(__import__("cybernetics.watchdog.heartbeat",fromlist=["HeartbeatLoop"]).HeartbeatLoop(r).run(stop))
        await asyncio.sleep(0.01)
        stop.set()
        await loop
        return r.get("engine").health
    assert asyncio.run(run()) == Health.HEALTHY
