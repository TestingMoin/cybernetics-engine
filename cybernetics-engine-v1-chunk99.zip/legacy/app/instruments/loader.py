from __future__ import annotations

import csv
import io
from dataclasses import dataclass
from pathlib import Path

import httpx

COMPACT_URL = "https://images.dhan.co/api-data/api-scrip-master.csv"
DETAILED_URL = "https://images.dhan.co/api-data/api-scrip-master-detailed.csv"


@dataclass(frozen=True)
class InstrumentSnapshot:
    source: str
    path: Path
    rows: int
    columns: tuple[str, ...]


async def download_master(path: str | Path, *, detailed: bool = True, timeout: float = 60.0) -> InstrumentSnapshot:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    url = DETAILED_URL if detailed else COMPACT_URL
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        response = await client.get(url)
        response.raise_for_status()
    data = response.content
    temp = target.with_suffix(target.suffix + ".tmp")
    temp.write_bytes(data)
    temp.replace(target)
    text = data.decode("utf-8-sig", errors="replace")
    reader = csv.reader(io.StringIO(text))
    header = next(reader, [])
    rows = sum(1 for _ in reader)
    return InstrumentSnapshot(source=url, path=target, rows=rows, columns=tuple(header))
