# Cybernetics Trading Engine — Chunk 64

## Atomic PostgreSQL Fill Ledger Boundary

Chunk 63 used an in-memory fill registry as a reference coordination mechanism.
Chunk 64 replaces that persistence boundary with a PostgreSQL-oriented durable
ledger contract.

Schema:

`fill_ledger(fill_id PRIMARY KEY, order_id, trade_id, state, error, timestamps)`

States:
- CLAIMED
- COMPLETED
- RECOVERY_REQUIRED

Durable flow:

Canonical Fill
→ PostgreSQL claim
→ Order Manager
→ Position Manager
→ Trade Lifecycle
→ PostgreSQL complete

A duplicate `fill_id` is never blindly replayed.

A claimed-but-incomplete or recovery-required fill is routed to recovery rather
than replayed automatically.

Important: independent Order/Position/Lifecycle components are not magically
made one ACID transaction by Python. This chunk makes the fill idempotency and
recovery state durable. A future stronger transactional event-outbox design can
co-locate durable domain events and state mutations in PostgreSQL.

No broker/network call is performed by this chunk.
