# Cybernetics Trading Engine — Chunk 87

## Strategy Models Interface Reconciliation

Canonical framework models:
`cybernetics.strategy.models`

Specialized Golden reproduction models:
`cybernetics.strategy.golden_models`

Validation includes:
- StrategyContext construction
- StrategyDecision invariants
- StrategyEngine compatibility
- qualified-signal bridge compatibility
- GoldenContext/GoldenDecision preservation
- Golden strategy evaluation
- position/risk handoff compatibility

No broker order execution.
