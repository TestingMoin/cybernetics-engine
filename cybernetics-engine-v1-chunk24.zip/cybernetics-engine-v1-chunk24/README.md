# Cybernetics Trading Engine — Chunk 24

## Execution Coordinator + Order/Risk Pipeline

Connects the deterministic execution gates to the broker-neutral multi-broker router.

Path:
Strategy Decision -> Risk -> Pre-Trade -> Reconciliation -> Broker Availability
-> Execution Coordinator -> Multi-Broker Router -> Adapter.

Safety:
- Engine state and live authorization are independent.
- Emergency stop blocks before broker routing.
- Risk/pre-trade/reconciliation are mandatory.
- Disabled broker routes cannot execute.
- No direct Dhan order I/O is included.
