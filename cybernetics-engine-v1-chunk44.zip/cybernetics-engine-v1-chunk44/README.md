# Cybernetics Trading Engine — Chunk 44

## Signal Event Qualification + Signal Lifecycle + Expiry / Invalidation

This chunk adds deterministic lifecycle control after signal creation and before
strategy evaluation.

### Lifecycle

OBSERVED -> ACTIVE

Terminal states:
- INVALIDATED
- EXPIRED
- SUPERSEDED

A terminal signal cannot silently return to ACTIVE.

### Invalidation

Signals can be invalidated for explicit reasons such as:
- opposite signal;
- market state invalid;
- stale data;
- manual intervention.

### Supersession

A newer signal can supersede an older signal. The old record retains the exact
new signal ID for audit tracing.

### Qualification

A signal can only qualify when:
- lifecycle is OBSERVED or ACTIVE;
- scanner health is acceptable;
- market data is ready;
- strength meets the configured minimum.

This is still a signal-quality layer. It does not create orders or call a broker.
