# Cybernetics Trading Engine — Chunk 8

Indicator Registry + deterministic technical analytics + baseline Market Regime engine.

## Included
- EMA, RSI, ATR, Bollinger Bands, ROC
- Configuration-driven indicator registry
- Per-call analytics state
- Deterministic baseline regime classifier
- No strategy/order/execution coupling
- Short-history safe behavior

## Safety
This chunk has no broker-order functionality and cannot enable live trading.
Indicator definitions can be classified by tier (`A`, `B`, `C`) and versioned.
The registry is deliberately separate from strategy selection.
