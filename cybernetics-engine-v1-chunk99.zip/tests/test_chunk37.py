from cybernetics.universe.governance import (
    UniverseGovernance, GovernanceRecord, UniverseStatus, InstrumentEligibility
)
from cybernetics.universe.scanner_groups import ScannerGroup, ScannerGroupRegistry

def record():
    return GovernanceRecord(
        security_id="NIFTY-OPT-1",
        exchange_segment="NSE_FNO",
        symbol="NIFTY26SEP25000CE",
        instrument_type="OPTION",
    )

def group(enabled=True):
    return ScannerGroup(
        group_id="ICE-NIFTY",
        scanner_name="NIFTY",
        asset_types=("INDEX","OPTION"),
        timeframes=("1m","5m"),
        enabled=enabled,
        options_required=True,
    )

def test_discovery_starts_not_eligible():
    g=UniverseGovernance()
    d=g.discover(record())
    assert d.status==UniverseStatus.DISCOVERED
    assert d.eligibility==InstrumentEligibility.NOT_ELIGIBLE

def test_cannot_activate_before_validation_and_approval():
    g=UniverseGovernance();g.discover(record())
    assert g.activate("NIFTY-OPT-1").status==UniverseStatus.DISCOVERED
    g.validate("NIFTY-OPT-1",scanner_group_id="ICE-NIFTY",
               options_available=True,lot_size=65,tick_size=0.05)
    assert g.activate("NIFTY-OPT-1").status==UniverseStatus.VALIDATED

def test_full_governance_path_reaches_production():
    g=UniverseGovernance();g.discover(record())
    g.validate("NIFTY-OPT-1",scanner_group_id="ICE-NIFTY",
               options_available=True,lot_size=65,tick_size=0.05)
    g.approve("NIFTY-OPT-1")
    registry=ScannerGroupRegistry([group(True)])
    d=g.activate("NIFTY-OPT-1",scanner_registry=registry)
    assert d.status==UniverseStatus.ACTIVE
    assert d.eligibility==InstrumentEligibility.PRODUCTION

def test_disabled_scanner_group_blocks_activation():
    g=UniverseGovernance();g.discover(record())
    g.validate("NIFTY-OPT-1",scanner_group_id="ICE-NIFTY",
               options_available=True,lot_size=65,tick_size=0.05)
    g.approve("NIFTY-OPT-1")
    d=g.activate("NIFTY-OPT-1",scanner_registry=ScannerGroupRegistry([group(False)]))
    assert d.eligibility==InstrumentEligibility.RESEARCH
    assert "disabled" in d.reason

def test_invalid_lot_size_never_becomes_eligible():
    g=UniverseGovernance();g.discover(record())
    d=g.validate("NIFTY-OPT-1",scanner_group_id="ICE-NIFTY",
                 options_available=True,lot_size=0,tick_size=0.05)
    assert d.status==UniverseStatus.WARNING
    assert g.production_eligible("NIFTY-OPT-1") is False

def test_warning_blocks_production():
    g=UniverseGovernance();g.discover(record())
    g.warning("NIFTY-OPT-1")
    assert g.production_eligible("NIFTY-OPT-1") is False

def test_no_new_trades_blocks_production():
    g=UniverseGovernance();g.discover(record())
    g.validate("NIFTY-OPT-1",scanner_group_id="ICE-NIFTY",
               options_available=True,lot_size=65,tick_size=0.05)
    g.approve("NIFTY-OPT-1")
    g.block_new_trades("NIFTY-OPT-1")
    assert g.get("NIFTY-OPT-1").status==UniverseStatus.NO_NEW_TRADES
    assert not g.production_eligible("NIFTY-OPT-1")

def test_retirement_is_terminal_for_eligibility():
    g=UniverseGovernance();g.discover(record())
    g.retire("NIFTY-OPT-1")
    assert g.get("NIFTY-OPT-1").eligibility==InstrumentEligibility.NOT_ELIGIBLE

def test_scanner_registry_rejects_duplicates():
    r=ScannerGroupRegistry()
    r.register(group())
    try:
        r.register(group())
        assert False
    except ValueError as e:
        assert "duplicate_scanner_group" in str(e)
