import pytest
from cybernetics.execution.intent import (
    ExecutionAction, OrderType, ExecutionIntentBuilder
)

B = ExecutionIntentBuilder()

BASE = dict(
    approved=True,
    trade_id="TRADE-1",
    strategy_id="GOLDEN-NIFTY-SENSEX",
    strategy_version="1.0.0-reproduction-target",
    signal_id="SIG-1",
    underlying_key="NIFTY",
    action="BUY",
    quantity=10,
)

def test_approved_market_intent_builds():
    r = B.build(**BASE)
    assert r.action == ExecutionAction.BUY
    assert r.order_type == OrderType.MARKET
    assert r.quantity == 10

def test_approved_limit_intent_builds():
    r = B.build(**BASE, order_type="LIMIT", limit_price=101.5)
    assert r.order_type == OrderType.LIMIT
    assert r.limit_price == 101.5

def test_pretrade_approval_is_mandatory():
    with pytest.raises(PermissionError, match="pretrade_approval_required"):
        B.build(**{**BASE, "approved": False})

def test_zero_quantity_rejected():
    with pytest.raises(ValueError, match="execution_quantity_must_be_positive"):
        B.build(**{**BASE, "quantity": 0})

def test_limit_requires_price():
    with pytest.raises(ValueError, match="limit_price_required_for_limit_order"):
        B.build(**BASE, order_type="LIMIT")

def test_market_cannot_have_limit_price():
    with pytest.raises(ValueError, match="market_order_cannot_have_limit_price"):
        B.build(**BASE, order_type="MARKET", limit_price=100)

def test_invalid_action_rejected():
    with pytest.raises(ValueError, match="unsupported_execution_action"):
        B.build(**{**BASE, "action": "HOLD"})

def test_invalid_order_type_rejected():
    with pytest.raises(ValueError, match="unsupported_order_type"):
        B.build(**{**BASE, "order_type": "STOP_LIMIT_X"})

def test_intent_id_is_deterministic():
    a = B.build(**BASE)
    b = B.build(**BASE)
    assert a.intent_id == b.intent_id

def test_strategy_version_survives():
    data = dict(BASE); data["strategy_version"] = "2.5.0"
    r = B.build(**data)
    assert r.strategy_version == "2.5.0"

def test_broker_specific_fields_are_absent():
    r = B.build(**BASE)
    assert not hasattr(r, "security_id")
    assert not hasattr(r, "broker_order_id")
    assert not hasattr(r, "access_token")
    assert not hasattr(r, "api_payload")

def test_metadata_is_preserved():
    r = B.build(**BASE, metadata={"source": "pretrade"})
    assert r.metadata["source"] == "pretrade"
