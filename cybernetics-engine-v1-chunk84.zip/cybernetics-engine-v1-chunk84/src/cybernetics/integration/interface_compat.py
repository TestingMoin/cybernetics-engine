from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


class InterfaceCompatibilityError(TypeError):
    pass


@dataclass(frozen=True)
class CompatibilityDecision:
    interface: str
    canonical: str
    legacy: str
    action: str


DECISIONS = (
    CompatibilityDecision(
        "websocket.subscriptions",
        "SubscriptionManagerV2",
        "SubscriptionManager",
        "adapter_pending_until_runtime_validation",
    ),
    CompatibilityDecision(
        "signals.lifecycle",
        "LifecycleV2",
        "InvalidationReason-era API",
        "adapter_pending_until_runtime_validation",
    ),
    CompatibilityDecision(
        "strategy.models",
        "StrategyDecisionV2",
        "StrategyContext-era API",
        "adapter_pending_until_runtime_validation",
    ),
    CompatibilityDecision(
        "execution.instrument",
        "InstrumentBindingV2",
        "InstrumentSelectionRequest-era API",
        "adapter_pending_until_runtime_validation",
    ),
    CompatibilityDecision(
        "dhan.payload",
        "DhanPayloadV2",
        "DhanOrderPayloadMapper-era API",
        "adapter_pending_until_runtime_validation",
    ),
)


def normalize_public_mapping(value: Any, *, required: tuple[str, ...]) -> Mapping[str, Any]:
    """
    Small, deterministic boundary helper.

    The helper accepts mapping-like objects only and validates required fields.
    It intentionally does not translate business semantics without an explicit
    adapter for that interface.
    """
    if not isinstance(value, Mapping):
        raise InterfaceCompatibilityError("mapping_required")
    missing = [key for key in required if key not in value]
    if missing:
        raise InterfaceCompatibilityError(
            f"required_fields_missing:{','.join(missing)}"
        )
    return value


def is_conflict_resolved(interface: str, resolved: set[str]) -> bool:
    return interface in resolved
