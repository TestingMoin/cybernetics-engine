# Cybernetics Trading Engine — Chunk 94

## Canonical Runtime Entrypoint & Composition Root

### Scope
Chunk 94 addresses ARC-001 from Chunk 93: the unified source now has a canonical executable process entrypoint and a fail-closed runtime application wrapper.

### Implemented
- `python -m cybernetics` canonical process entrypoint.
- `cybernetics-engine` console-script entrypoint in `pyproject.toml`.
- `runtime.application.RuntimeApplication` lifecycle: CREATED → STARTING → RUNNING → STOPPING → STOPPED / FAILED.
- Runtime signal handler for SIGINT/SIGTERM.
- `--self-check` and `--once` safe operational modes.
- Fail-closed bootstrap dependency source; no Dhan connection, live authorization, order submission, or production DB mutation.
- Runtime composition remains dependency-injected so later production wiring does not bypass existing gates.
- Package identity updated to `cybernetics-trading-engine` `1.0.0-rc1`.

### Validation
- `python -m compileall -q src tests`: PASS
- `pytest -q`: 793 / 793 PASS
- `python -m cybernetics --self-check`: PASS; `new_trades_allowed=false`
- `python -m cybernetics --once`: PASS; lifecycle started/stopped safely; `new_trades_allowed=false`

### Safety
Chunk 94 is not a production deployment. It does not connect to Dhan, enable live trading, submit broker orders, or migrate a production database.

### Remaining Chunk 93 blockers
- ARC-002: PostgreSQL orders schema contradiction
- ARC-003: authoritative PostgreSQL migration chain
- ARC-004: competing namespace ownership
- ARC-005: single authoritative Dhan submission boundary
- ARC-007: production dependency declaration
- ARC-008: dynamic internal imports
