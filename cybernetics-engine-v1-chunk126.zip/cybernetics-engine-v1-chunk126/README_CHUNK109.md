# Chunk 109 — Runtime Worker Loop & Supervisory Cycle

Adds a canonical `run_cycle()` supervisory boundary to the production runtime application and changes the long-running loop to refresh readiness on each cycle before sleeping.

Safety properties:
- lifecycle remains separate from trading readiness;
- each cycle is side-effect-free at the application layer;
- no order submission, broker I/O, control transition, or persistence mutation is introduced;
- exceptions mark the application FAILED and still execute stop cleanup;
- default startup remains fail-closed.
