# Cybernetics Trading Engine — Chunk 27

## UNKNOWN-Order Reconciliation + Safe Retry Resolver

This chunk handles the most dangerous order failure mode:

submission request -> network timeout -> broker result unknown.

The resolver queries the broker and binds an outcome only on an exact
`client_order_key` match.

### Outcomes

- Exact accepted/open/partial/filled match -> bind the broker order and resolve as ACCEPTED (new retry remains blocked).
- Exact rejected/cancelled/expired match -> resolve as rejected and permit a future submission.
- No exact match -> remain UNKNOWN and block retry.
- Multiple exact matches -> AMBIGUOUS and block retry.
- Fuzzy symbol/side/quantity matching -> deliberately forbidden.

This prevents a timeout followed by a blind retry from silently producing two live orders.

Live Dhan I/O is not implemented in this chunk.
