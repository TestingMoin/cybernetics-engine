from datetime import date
from cybernetics.dhan.payload import DhanOrderPayloadMapper, DhanOrderPayload
from cybernetics.execution.intent import ExecutionIntent, ExecutionAction, OrderType
from cybernetics.execution.binding import BoundExecutionInstruction

def bound(action=ExecutionAction.BUY, order_type=OrderType.MARKET, limit=None):
    return BoundExecutionInstruction(
        intent_id="INTENT-123", trade_id="TRADE-1",
        strategy_id="STRAT-1", strategy_version="1.0",
        signal_id="SIG-1", exchange_segment="NSE_FNO",
        security_id="12345", symbol="NIFTY",
        action=action, order_type=order_type, quantity=50,
        lot_size=50, tick_size=0.05, contract_multiplier=1.0,
        limit_price=limit, product_type="INTRADAY", validity="DAY",
    )

def test_payload_is_serializable():
    p=DhanOrderPayload("CLIENT","CORR","BUY","NSE_FNO","INTRADAY","MARKET","DAY","123",50)
    d=p.as_dict()
    assert d["securityId"]=="123" and d["quantity"]==50

def test_mapper_market_order():
    p=DhanOrderPayloadMapper().map(bound(),dhan_client_id="CLIENT")
    assert p.transactionType=="BUY" and p.orderType=="MARKET"
    assert p.correlationId.startswith("CTE-")
    assert len(p.correlationId)<=30

def test_mapper_limit_order_requires_positive_price():
    p=DhanOrderPayloadMapper().map(
        bound(order_type=OrderType.LIMIT,limit=100.5),
        dhan_client_id="CLIENT",
        correlation_id="CORR-1"
    )
    assert p.orderType=="LIMIT" and p.price==100.5

def test_missing_client_id_blocked():
    try: DhanOrderPayloadMapper().map(bound(),dhan_client_id="")
    except ValueError as e: assert str(e)=="dhan_client_id_required"

def test_invalid_segment_blocked():
    i=bound()
    bad=BoundExecutionInstruction(
        intent_id=i.intent_id, trade_id=i.trade_id, strategy_id=i.strategy_id,
        strategy_version=i.strategy_version, signal_id=i.signal_id,
        exchange_segment="BAD", security_id=i.security_id, symbol=i.symbol,
        action=i.action, order_type=i.order_type, quantity=i.quantity,
        lot_size=i.lot_size, tick_size=i.tick_size,
        contract_multiplier=i.contract_multiplier, limit_price=i.limit_price,
        product_type=i.product_type, validity=i.validity)
    try: DhanOrderPayloadMapper().map(bad,dhan_client_id="C")
    except ValueError as e: assert str(e)=="unsupported_dhan_exchange_segment"

def test_invalid_correlation_blocked():
    try: DhanOrderPayloadMapper().map(bound(),dhan_client_id="C",correlation_id="x"*31)
    except ValueError as e: assert str(e)=="dhan_correlation_id_too_long"

def test_invalid_correlation_character_blocked():
    try: DhanOrderPayloadMapper().map(bound(),dhan_client_id="C",correlation_id="BAD/ID")
    except ValueError as e: assert str(e)=="dhan_correlation_id_invalid"

def test_negative_disclosed_quantity_blocked():
    try: DhanOrderPayloadMapper().map(bound(),dhan_client_id="C",disclosed_quantity=-1)
    except ValueError as e: assert str(e)=="invalid_disclosed_quantity"

def test_stop_order_not_silently_accepted():
    # Chunk 56 deliberately supports MARKET/LIMIT only at this mapper boundary.
    i=bound()
    class UnsupportedOrderType:
        value="STOP_LOSS"
    bad=BoundExecutionInstruction(
        intent_id=i.intent_id, trade_id=i.trade_id, strategy_id=i.strategy_id,
        strategy_version=i.strategy_version, signal_id=i.signal_id,
        exchange_segment=i.exchange_segment, security_id=i.security_id, symbol=i.symbol,
        action=i.action, order_type=UnsupportedOrderType(), quantity=i.quantity,
        lot_size=i.lot_size, tick_size=i.tick_size,
        contract_multiplier=i.contract_multiplier, limit_price=None,
        product_type=i.product_type, validity=i.validity)
    try: DhanOrderPayloadMapper().map(bad,dhan_client_id="C")
    except ValueError as e: assert str(e)=="unsupported_dhan_order_type"

def test_no_access_token_in_payload_surface():
    import inspect
    src=inspect.getsource(DhanOrderPayloadMapper.map)
    assert "access_token" not in src
    assert "api_secret" not in src
