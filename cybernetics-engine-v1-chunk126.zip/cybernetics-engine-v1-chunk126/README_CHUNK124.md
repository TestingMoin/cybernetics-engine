# Chunk 124 — Hostinger Remote Staging Transfer Guard

Adds an operator-side remote transfer wrapper for the first real Hostinger staging move. It verifies the local release checksum, transfers only the release archive + checksum, verifies the checksum again on the VPS, extracts to a staging-only directory, and refuses to continue when the VPS environment is not explicitly `staging` + `paper` + `order_submission=false`.

It does not upload credentials, does not authorize live trading, does not submit Dhan orders, and does not automatically activate the release.
