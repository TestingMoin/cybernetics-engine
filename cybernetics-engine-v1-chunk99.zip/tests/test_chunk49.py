from datetime import datetime, timezone
from cybernetics.risk.handoff import RiskAction, StrategyRiskHandoff
from cybernetics.strategy.risk_adapter import StrategyDecisionInput, StrategyToRiskAdapter

T = datetime(2026, 5, 1, 9, 30, tzinfo=timezone.utc)


def make(action="ENTER_LONG", **kw):
    d = dict(
        strategy_id="GOLDEN-NIFTY-SENSEX",
        strategy_version="1.0.0-reproduction-target",
        signal_id="SIG-1",
        trade_id="TRADE-1",
        underlying_key="NIFTY",
        timeframe="1m",
        action=action,
        timestamp=T,
        entry_reference_price=100.0,
        stop_reference_price=99.0,
        target_reference_price=102.0,
        metadata={"source": "strategy"},
    )
    d.update(kw)
    return StrategyDecisionInput(**d)


def test_long_entry_creates_risk_request():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make())
    assert r.accepted
    assert r.reason == "risk_request_created"
    assert r.request.action == RiskAction.ENTER_LONG


def test_short_entry_creates_risk_request():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make(action="ENTER_SHORT"))
    assert r.accepted
    assert r.request.action == RiskAction.ENTER_SHORT


def test_long_exit_creates_risk_request():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make(action="EXIT_LONG"))
    assert r.accepted
    assert r.request.action == RiskAction.EXIT_LONG


def test_hold_does_not_create_executable_request():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make(action="HOLD"))
    assert not r.accepted
    assert r.reason == "non_executable_strategy_action"


def test_no_action_does_not_create_executable_request():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make(action="NO_ACTION"))
    assert not r.accepted


def test_unknown_action_is_rejected():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make(action="MAGIC"))
    assert not r.accepted
    assert r.reason == "unsupported_risk_action"


def test_invalid_price_is_rejected():
    try:
        StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(
            make(entry_reference_price=0)
        )
        assert False
    except ValueError as exc:
        assert str(exc) == "entry_reference_price_must_be_positive"


def test_request_identity_is_deterministic():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make())
    assert r.request.request_id == (
        "GOLDEN-NIFTY-SENSEX:TRADE-1:SIG-1:ENTER_LONG"
    )


def test_strategy_version_survives_handoff():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(
        make(strategy_version="2.4.1")
    )
    assert r.request.strategy_version == "2.4.1"


def test_risk_request_has_no_final_quantity():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make())
    assert not hasattr(r.request, "quantity")
    assert not hasattr(r.request, "lot_size")
    assert not hasattr(r.request, "broker_order_id")


def test_reference_prices_are_data_not_sizing():
    r = StrategyToRiskAdapter(StrategyRiskHandoff()).adapt(make())
    assert r.request.entry_reference_price == 100.0
    assert r.request.stop_reference_price == 99.0
    assert r.request.target_reference_price == 102.0
    assert "source" in r.request.metadata
