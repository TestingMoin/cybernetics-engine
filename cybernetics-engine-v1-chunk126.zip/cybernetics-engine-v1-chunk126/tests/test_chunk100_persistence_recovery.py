from cybernetics.config.settings import DeploymentConfig
from cybernetics.recovery.startup import (
    Readiness,
    StartupRecoveryDependencies,
)
from cybernetics.runtime.persistence_recovery import build_persistence_recovery_wiring
from cybernetics.runtime.production import RuntimeDependencyState, build_production_runtime
from cybernetics.runtime.state import ControlState


class Deps:
    def __init__(self, *, persistence=True, unresolved=(), orders=True, positions=True):
        self.persistence = persistence
        self.unresolved = tuple(unresolved)
        self.orders = orders
        self.positions = positions

    def validate_persistence(self):
        return self.persistence

    def find_unresolved_recovery_cases(self):
        return self.unresolved

    def reconcile_orders(self):
        return self.orders

    def reconcile_positions(self):
        return self.positions


def make_bridge(deps):
    return build_persistence_recovery_wiring(
        existing_tables=lambda: {
            "schema_version", "orders", "fill_ledger", "fill_outbox",
            "control_command_audit", "emergency_control_state",
        },
        migration_version=lambda: 1,
        startup_dependencies=deps,
    )


def test_persistence_health_uses_canonical_production_table_set():
    bridge = make_bridge(Deps())
    assert bridge.persistence_ready() is True


def test_startup_recovery_must_reconcile_before_runtime_is_ready():
    bridge = make_bridge(Deps(orders=False))
    report = bridge.startup_report()
    assert report.readiness is Readiness.BLOCKED
    assert report.stage.value == "BLOCKED"
    assert bridge.orders_reconciled() is False


def test_unresolved_recovery_blocks_all_reconciliation_readiness():
    bridge = make_bridge(Deps(unresolved=("REC-1",)))
    state = bridge.runtime_readiness()
    assert state == {
        "persistence_ready": True,
        "recovery_clear": False,
        "orders_reconciled": False,
        "positions_reconciled": False,
    }


def test_bridge_can_drive_canonical_runtime_state_without_live_authorization():
    bridge = make_bridge(Deps())
    config = DeploymentConfig.from_env({"CYBERNETICS_TRADING_MODE": "paper"})
    state = RuntimeDependencyState(
        engine_running=True,
        control_state=ControlState.RUNNING,
        market_data_ready=True,
        scanner_health_ready=True,
        watchdog_healthy=True,
        broker_available=True,
    )
    app = build_production_runtime(config, dependency_state=state, persistence_recovery=bridge)
    snap = app.snapshot()
    assert snap.readiness.engine_ready is True
    assert snap.readiness.new_trades_allowed is False
    assert "live_authorization_invalid" in snap.readiness.reasons


def test_missing_production_table_blocks_persistence_and_engine_readiness():
    bridge = build_persistence_recovery_wiring(
        existing_tables=lambda: {"schema_version", "orders"},
        migration_version=lambda: 1,
        startup_dependencies=Deps(),
    )
    assert bridge.persistence_ready() is False
    config = DeploymentConfig.from_env({"CYBERNETICS_TRADING_MODE": "paper"})
    state = RuntimeDependencyState(
        engine_running=True,
        control_state=ControlState.RUNNING,
        market_data_ready=True,
        scanner_health_ready=True,
        watchdog_healthy=True,
        broker_available=True,
    )
    app = build_production_runtime(config, dependency_state=state, persistence_recovery=bridge)
    assert app.snapshot().readiness.engine_ready is False
