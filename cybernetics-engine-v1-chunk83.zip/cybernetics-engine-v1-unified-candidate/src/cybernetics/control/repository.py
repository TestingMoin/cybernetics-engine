from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Any, Protocol

class CommandRecordState(str, Enum):
    ACCEPTED="ACCEPTED"
    DUPLICATE="DUPLICATE"
    REJECTED="REJECTED"
    STALE="STALE"

@dataclass(frozen=True)
class CommandAuditRecord:
    command_id:str
    command:str
    source:str
    result:CommandRecordState
    state:str
    reason:str
    issued_at:float

class Tx(Protocol):
    def fetchone(self, sql:str, params:tuple[Any,...]=()): ...
    def execute(self, sql:str, params:tuple[Any,...]=()): ...

class ControlCommandRepository:
    def __init__(self, tx): self.tx=tx
    def ensure_command_record(self, record):
        return self.tx.fetchone(
            """INSERT INTO control_command_audit(
               command_id,command,source,result,state,reason,issued_at)
               VALUES (%s,%s,%s,%s,%s,%s,TO_TIMESTAMP(%s))
               ON CONFLICT (command_id) DO NOTHING
               RETURNING command_id""",
            (record.command_id,record.command,record.source,record.result.value,
             record.state,record.reason,record.issued_at)
        ) is not None
    def record_result(self, record):
        result=self.tx.execute(
            """UPDATE control_command_audit
               SET command=%s,source=%s,result=%s,state=%s,reason=%s,
                   issued_at=TO_TIMESTAMP(%s)
               WHERE command_id=%s""",
            (record.command,record.source,record.result.value,record.state,
             record.reason,record.issued_at,record.command_id)
        )
        return int(getattr(result,"rowcount",result))==1
