# Cybernetics Trading Engine — Chunk 37

## Universe Governance + Scanner Group Assignment + Contract Eligibility

This chunk introduces explicit governance between the instrument master and production scanners.

### Governance flow

DISCOVERED -> VALIDATED -> APPROVED -> ACTIVE/PRODUCTION

Problematic or disappearing instruments move to:
WARNING -> NO_NEW_TRADES -> RETIRED

### Scanner groups

Scanner groups are logical isolated instances, not separate codebases. One reusable scanner
engine can run groups such as ICE-NIFTY, ICE-BANKNIFTY, ICE-SENSEX, MCX groups, and stock
groups with independent configuration/state.

An instrument cannot become production-eligible until:
1. It is discovered.
2. Instrument metadata validates.
3. A scanner group is assigned.
4. Human/system governance approves it.
5. The assigned scanner group is enabled.

This prevents newly discovered symbols or contracts from silently entering live trading.

The implementation intentionally does not hardcode the full project universe; the project-wide
universe definition remains the source-of-truth and will be loaded into this governance layer.
