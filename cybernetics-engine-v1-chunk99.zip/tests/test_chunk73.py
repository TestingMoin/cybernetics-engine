from cybernetics.runtime.state import (
    RuntimeInputs, EngineMode, ControlState, evaluate_runtime
)
from cybernetics.runtime.composition import RuntimeStateComposer


def good(**overrides):
    x=dict(
        engine_mode=EngineMode.RUNNING,
        control_state=ControlState.RUNNING,
        persistence_ready=True,
        recovery_clear=True,
        orders_reconciled=True,
        positions_reconciled=True,
        market_data_ready=True,
        scanner_health_ready=True,
        watchdog_healthy=True,
        live_authorization_valid=True,
        broker_available=True,
    )
    x.update(overrides)
    return RuntimeInputs(**x)


def test_all_healthy_allows_new_trades():
    r=evaluate_runtime(good())
    assert r.engine_ready
    assert r.new_trades_allowed
    assert r.reasons == ()


def test_engine_stopped_blocks_engine_and_new_trades():
    r=evaluate_runtime(good(engine_mode=EngineMode.STOPPED))
    assert not r.engine_ready
    assert not r.new_trades_allowed
    assert "engine_not_running" in r.reasons


def test_emergency_stop_keeps_engine_health_separate():
    r=evaluate_runtime(good(control_state=ControlState.EMERGENCY_STOP))
    assert r.engine_ready
    assert not r.new_trades_allowed
    assert "emergency_stop_active" in r.reasons


def test_stop_new_trades_keeps_engine_ready():
    r=evaluate_runtime(good(control_state=ControlState.STOP_NEW_TRADES))
    assert r.engine_ready
    assert not r.new_trades_allowed
    assert "stop_new_trades" in r.reasons


def test_live_auth_only_controls_new_trades():
    r=evaluate_runtime(good(live_authorization_valid=False))
    assert r.engine_ready
    assert not r.new_trades_allowed
    assert "live_authorization_invalid" in r.reasons


def test_persistence_failure_blocks_engine():
    r=evaluate_runtime(good(persistence_ready=False))
    assert not r.engine_ready
    assert not r.new_trades_allowed


def test_recovery_failure_blocks_engine():
    r=evaluate_runtime(good(recovery_clear=False))
    assert not r.engine_ready


def test_order_reconciliation_failure_blocks_engine():
    r=evaluate_runtime(good(orders_reconciled=False))
    assert not r.engine_ready


def test_position_reconciliation_failure_blocks_engine():
    r=evaluate_runtime(good(positions_reconciled=False))
    assert not r.engine_ready


def test_market_data_failure_blocks_engine():
    r=evaluate_runtime(good(market_data_ready=False))
    assert not r.engine_ready


def test_scanner_failure_blocks_engine():
    r=evaluate_runtime(good(scanner_health_ready=False))
    assert not r.engine_ready


def test_watchdog_failure_blocks_engine():
    r=evaluate_runtime(good(watchdog_healthy=False))
    assert not r.engine_ready


def test_broker_failure_blocks_engine():
    r=evaluate_runtime(good(broker_available=False))
    assert not r.engine_ready


class Signals:
    def engine_mode(self): return EngineMode.RUNNING
    def control_state(self): return ControlState.RUNNING
    def persistence_ready(self): return True
    def recovery_clear(self): return True
    def orders_reconciled(self): return True
    def positions_reconciled(self): return True
    def market_data_ready(self): return True
    def scanner_health_ready(self): return True
    def watchdog_healthy(self): return True
    def live_authorization_valid(self): return False
    def broker_available(self): return True


def test_composer_builds_snapshot_from_subsystems():
    s=RuntimeStateComposer(Signals()).snapshot()
    assert s.readiness.engine_ready
    assert not s.readiness.new_trades_allowed
    assert not s.inputs.live_authorization_valid


def test_composer_reads_each_signal_once():
    class Counting(Signals):
        def __init__(self): self.counts={}
        def _r(self,n,v):
            self.counts[n]=self.counts.get(n,0)+1
            return v
        def engine_mode(self): return self._r("engine",EngineMode.RUNNING)
        def control_state(self): return self._r("control",ControlState.RUNNING)
        def persistence_ready(self): return self._r("persistence",True)
        def recovery_clear(self): return self._r("recovery",True)
        def orders_reconciled(self): return self._r("orders",True)
        def positions_reconciled(self): return self._r("positions",True)
        def market_data_ready(self): return self._r("market",True)
        def scanner_health_ready(self): return self._r("scanner",True)
        def watchdog_healthy(self): return self._r("watchdog",True)
        def live_authorization_valid(self): return self._r("auth",True)
        def broker_available(self): return self._r("broker",True)
    c=Counting()
    snap=RuntimeStateComposer(c).snapshot()
    assert snap.readiness.new_trades_allowed
    assert all(v==1 for v in c.counts.values())


def test_runtime_inputs_are_immutable():
    r=evaluate_runtime(good())
    assert r.engine_ready is True
    assert isinstance(r.reasons, tuple)


def test_no_mutation_or_broker_submission_in_composition_source():
    from pathlib import Path
    src=Path("src/cybernetics/runtime/composition.py").read_text()
    for token in ("place_order","submit_order","cancel_order","replace_order","/v2/orders"):
        assert token not in src
