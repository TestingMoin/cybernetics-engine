from datetime import date
from cybernetics.execution.instrument import (
    InstrumentType, OptionType, InstrumentEligibility,
    TradeInstrument, InstrumentSelectionRequest, InstrumentSelector,
)

EL=InstrumentEligibility(True,True,True,True)

def inst(**kw):
    d=dict(exchange_segment="NSE_FNO",security_id="123",symbol="NIFTY",
           instrument_type=InstrumentType.INDEX,eligibility=EL)
    d.update(kw)
    return TradeInstrument(**d)

def test_canonical_contract_exposes_selector():
    assert InstrumentSelector is not None
    assert InstrumentSelectionRequest is not None

def test_identity_required():
    try: TradeInstrument("", "1", "NIFTY", InstrumentType.INDEX)
    except ValueError as e: assert str(e)=="instrument_identity_required"

def test_option_metadata_required():
    try: inst(symbol="NIFTY", instrument_type=InstrumentType.OPTION)
    except ValueError as e: assert str(e)=="option_expiry_required"

def test_option_requires_strike_and_type():
    try: inst(instrument_type=InstrumentType.OPTION, expiry=date(2026,9,24))
    except ValueError as e: assert str(e)=="option_strike_required"

def test_production_eligibility_is_enforced():
    candidate=inst(eligibility=InstrumentEligibility(True,True,True,False))
    req=InstrumentSelectionRequest("NSE_FNO","NIFTY",InstrumentType.INDEX)
    try: InstrumentSelector().select(req,[candidate])
    except LookupError as e: assert str(e)=="no_production_eligible_instrument_match"

def test_exact_selection():
    candidate=inst()
    req=InstrumentSelectionRequest("NSE_FNO","NIFTY",InstrumentType.INDEX)
    assert InstrumentSelector().select(req,[candidate]) is candidate

def test_ambiguous_selection_rejected():
    a=inst(security_id="1")
    b=inst(security_id="2")
    req=InstrumentSelectionRequest("NSE_FNO","NIFTY",InstrumentType.INDEX)
    try: InstrumentSelector().select(req,[a,b])
    except LookupError as e: assert str(e)=="ambiguous_instrument_selection"

def test_option_selection_metadata():
    a=inst(instrument_type=InstrumentType.OPTION, symbol="NIFTY",
           security_id="11", expiry=date(2026,9,24), strike=25000,
           option_type=OptionType.CE, lot_size=65)
    req=InstrumentSelectionRequest("NSE_FNO","NIFTY",InstrumentType.OPTION,
                                   expiry=date(2026,9,24),strike=25000,
                                   option_type=OptionType.CE,lot_size=65)
    assert InstrumentSelector().select(req,[a]) is a

def test_no_security_id_invention():
    candidates=[]
    req=InstrumentSelectionRequest("NSE_FNO","NIFTY",InstrumentType.INDEX)
    try: InstrumentSelector().select(req,candidates)
    except LookupError as e: assert "no_production_eligible" in str(e)
