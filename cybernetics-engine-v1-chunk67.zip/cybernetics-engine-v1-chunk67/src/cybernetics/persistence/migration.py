from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Sequence


STARTUP_REQUIRED_TABLES = (
    "fill_ledger",
    "fill_outbox",
)


class SQLExecutor(Protocol):
    def execute(self, sql: str) -> None: ...


@dataclass(frozen=True)
class SchemaVersion:
    version: int
    name: str


@dataclass(frozen=True)
class Migration:
    version: int
    name: str
    sql: str


class MigrationRunner:
    """
    Deterministic migration boundary.

    PostgreSQL transaction ownership is deliberately delegated to the supplied
    executor/connection wrapper. In production, each migration should execute
    atomically and schema_version should be updated in the same transaction.
    """

    def __init__(self, migrations: Sequence[Migration]):
        versions = [m.version for m in migrations]
        if len(versions) != len(set(versions)):
            raise ValueError("duplicate_migration_version")
        if versions != sorted(versions):
            raise ValueError("migrations_must_be_sorted")
        self.migrations = tuple(migrations)

    def pending(self, current_version: int) -> tuple[Migration, ...]:
        return tuple(m for m in self.migrations if m.version > current_version)

    def apply(self, executor: SQLExecutor, current_version: int) -> SchemaVersion:
        pending = self.pending(current_version)
        version = current_version
        name = "baseline"

        for migration in pending:
            executor.execute(migration.sql)
            version = migration.version
            name = migration.name

        return SchemaVersion(version, name)


SCHEMA_VERSION_DDL = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

FILL_LEDGER_DDL = """
CREATE TABLE IF NOT EXISTS fill_ledger (
    fill_id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    trade_id TEXT NOT NULL,
    state TEXT NOT NULL CHECK (
        state IN ('CLAIMED','COMPLETED','RECOVERY_REQUIRED')
    ),
    error TEXT NULL,
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ NULL
);

CREATE INDEX IF NOT EXISTS idx_fill_ledger_order_id
    ON fill_ledger(order_id);

CREATE INDEX IF NOT EXISTS idx_fill_ledger_trade_id
    ON fill_ledger(trade_id);
"""

FILL_OUTBOX_DDL = """
CREATE TABLE IF NOT EXISTS fill_outbox (
    event_id TEXT PRIMARY KEY,
    fill_id TEXT NOT NULL,
    order_id TEXT NOT NULL,
    trade_id TEXT NOT NULL,
    payload_json JSONB NOT NULL,
    state TEXT NOT NULL CHECK (
        state IN ('PENDING','PROCESSING','COMPLETED','FAILED')
    ),
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_fill_outbox_fill_id
    ON fill_outbox(fill_id);

CREATE INDEX IF NOT EXISTS idx_fill_outbox_state
    ON fill_outbox(state);
"""

MIGRATIONS = (
    Migration(1, "schema_version", SCHEMA_VERSION_DDL),
    Migration(2, "fill_ledger", FILL_LEDGER_DDL),
    Migration(3, "fill_outbox", FILL_OUTBOX_DDL),
)


@dataclass(frozen=True)
class StartupValidation:
    ready: bool
    missing_tables: tuple[str, ...]
    migration_version: int
    reason: str


class StartupSchemaValidator:
    def validate(
        self,
        *,
        existing_tables: set[str],
        migration_version: int,
    ) -> StartupValidation:
        missing = tuple(
            t for t in STARTUP_REQUIRED_TABLES if t not in existing_tables
        )
        if missing:
            return StartupValidation(
                False, missing, migration_version,
                "required_persistence_tables_missing"
            )
        return StartupValidation(
            True, (), migration_version, "persistence_schema_ready"
        )
