from cybernetics.risk.risk import AccountRisk, InstrumentRisk, RiskEngine
from cybernetics.risk.sizing import SizingRequest, size_by_stop_risk
from cybernetics.risk.pretrade import PreTradeContext, PreTradeGate

def account():
    return AccountRisk(100000,100000,0,0,3000,1000000,3)

def order(qty=10):
    return InstrumentRisk("NIFTY",qty,10,100,99,"BUY",1000,100)

def test_risk_accepts_valid_lot():
    d=RiskEngine().evaluate(account(),order(10))
    assert d.approved and d.allowed_quantity==10

def test_risk_rejects_bad_lot_alignment():
    d=RiskEngine().evaluate(account(),order(11))
    assert not d.approved and "quantity_not_lot_aligned" in d.reasons

def test_daily_loss_blocks():
    a=AccountRisk(100000,100000,-3000,0,3000,1000000,3)
    d=RiskEngine().evaluate(a,order())
    assert not d.approved

def test_sizing_never_forces_one_lot():
    r=SizingRequest(1000,.01,100,99,10,50,100,10)
    assert size_by_stop_risk(r)==0

def test_pretrade_requires_all_gates():
    g=PreTradeGate()
    c=PreTradeContext(True,False,False,False,True,True,True)
    d=g.evaluate(c)
    assert not d.allowed and "live_not_authorized" in d.reasons
