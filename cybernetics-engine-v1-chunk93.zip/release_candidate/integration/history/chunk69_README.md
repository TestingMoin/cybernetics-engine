# Cybernetics Trading Engine — Chunk 69

## Unified Fill Pipeline → PostgreSQL

This chunk connects the Unified Fill Processing concept from Chunk 66 to the
durable PostgreSQL ledger/outbox boundary created in Chunks 67–68.

### Durable sequence

1. Validate canonical fill.
2. Start caller-owned PostgreSQL transaction.
3. Claim `fill_ledger` by unique `fill_id`.
4. Detect duplicate/completed/recovery states.
5. Apply Order Manager handler.
6. Apply Position Manager handler.
7. Apply Trade Lifecycle handler.
8. Enqueue exactly one durable outbox event by `fill_id`.
9. Mark ledger `COMPLETED`.

Any domain-processing or persistence-finalization failure on the processing path
marks the fill `RECOVERY_REQUIRED`. A transaction/connection failure is also
treated as `RECOVERY_REQUIRED`; the processor does not perform blind retries.

This is an integration boundary, not a claim of distributed exactly-once
execution. Production deployment still requires the real PostgreSQL connection,
transaction configuration, recovery worker, and reconciliation flow.
No broker API calls occur in this chunk.
