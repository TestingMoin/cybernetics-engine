from cybernetics.runtime.application import ApplicationLifecycle, RuntimeApplication, RuntimeConfig


def test_start_evaluates_readiness_but_process_can_run_fail_closed():
    app = RuntimeApplication()
    snap = app.start()
    assert app.lifecycle is ApplicationLifecycle.RUNNING
    assert app.last_snapshot is snap
    assert snap.readiness.new_trades_allowed is False
    app.stop()
    assert app.lifecycle is ApplicationLifecycle.STOPPED


def test_refresh_snapshot_requires_active_lifecycle():
    app = RuntimeApplication()
    try:
        app.refresh_snapshot()
        assert False
    except RuntimeError as exc:
        assert str(exc) == "application_not_running_or_starting"


def test_refresh_snapshot_updates_cached_snapshot():
    app = RuntimeApplication()
    app.start()
    first = app.last_snapshot
    second = app.refresh_snapshot()
    assert second is app.last_snapshot
    assert second is not None
    assert first is not None
    app.stop()


def test_start_hook_failure_marks_failed():
    def fail():
        raise RuntimeError("boom")

    app = RuntimeApplication(on_start=fail)
    try:
        app.start()
        assert False
    except RuntimeError as exc:
        assert str(exc) == "boom"
    assert app.lifecycle is ApplicationLifecycle.FAILED
