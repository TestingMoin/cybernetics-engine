from datetime import datetime,timedelta,timezone
from cybernetics.recovery.gap_detector import GapDetector
from cybernetics.recovery.coordinator import RecoveryCoordinator,RecoveryState
from cybernetics.recovery.pipeline import GapRecoveryPipeline

def ts(minutes):
    return datetime(2026,1,1,9,15,tzinfo=timezone.utc)+timedelta(minutes=minutes)

def test_detects_single_missing_bar():
    d=GapDetector()
    gaps=d.detect("1",[ts(0),ts(1),ts(3),ts(4)],timedelta(minutes=1))
    assert len(gaps)==1
    assert gaps[0].missing_bars==1
    assert gaps[0].start==ts(2)

def test_no_gap_when_timestamps_are_contiguous():
    d=GapDetector()
    assert d.detect("1",[ts(0),ts(1),ts(2)],timedelta(minutes=1))==[]

def test_duplicate_input_timestamps_do_not_create_false_gaps():
    d=GapDetector()
    assert d.detect("1",[ts(0),ts(1),ts(1),ts(2)],timedelta(minutes=1))==[]

def test_coordinator_deduplicates_recovery_rows():
    gap=GapRecoveryPipeline
    from cybernetics.recovery.gap_detector import DataGap
    g=DataGap("1",ts(2),ts(2),timedelta(minutes=1),1)
    rows=[{"timestamp":ts(2),"close":100},{"timestamp":ts(2),"close":101}]
    merged=[]
    c=RecoveryCoordinator(
        fetch=lambda _:rows,
        merge=lambda x:(len(x),1),
        verify=lambda _:True
    )
    r=c.recover(g)
    assert r.state==RecoveryState.VERIFIED
    assert r.recovered_count==1 and r.duplicate_count==1

def test_recovery_marks_failed_if_gap_remains():
    from cybernetics.recovery.gap_detector import DataGap
    g=DataGap("1",ts(2),ts(2),timedelta(minutes=1),1)
    c=RecoveryCoordinator(lambda _:[{"timestamp":ts(2)}],lambda x:(1,0),lambda _:False)
    r=c.recover(g)
    assert r.state==RecoveryState.FAILED
    assert "gap_remains" in r.message

def test_permission_error_blocks_recovery():
    from cybernetics.recovery.gap_detector import DataGap
    g=DataGap("1",ts(2),ts(2),timedelta(minutes=1),1)
    c=RecoveryCoordinator(lambda _:(_ for _ in ()).throw(PermissionError("forbidden")),
                          lambda x:(0,0),lambda _:False)
    r=c.recover(g)
    assert r.state==RecoveryState.BLOCKED

def test_pipeline_ready_when_no_gaps():
    p=GapRecoveryPipeline(
        GapDetector(),
        RecoveryCoordinator(lambda _ :[],lambda x:(0,0),lambda _:True)
    )
    report=p.run("1",[ts(0),ts(1),ts(2)],timedelta(minutes=1))
    assert report.ready is True and report.gaps==()

def test_pipeline_ready_after_verified_recovery():
    p=GapRecoveryPipeline(
        GapDetector(),
        RecoveryCoordinator(
            lambda g:[{"timestamp":g.start}],
            lambda rows:(len(rows),0),
            lambda g:True
        )
    )
    report=p.run("1",[ts(0),ts(2)],timedelta(minutes=1))
    assert report.ready is True
    assert report.results[0].state==RecoveryState.VERIFIED

def test_pipeline_not_ready_if_any_gap_fails():
    p=GapRecoveryPipeline(
        GapDetector(),
        RecoveryCoordinator(
            lambda g:[{"timestamp":g.start}],
            lambda rows:(len(rows),0),
            lambda g:False
        )
    )
    report=p.run("1",[ts(0),ts(2)],timedelta(minutes=1))
    assert report.ready is False
