from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class Instrument(Base):
    __tablename__ = "instruments"
    __table_args__ = (UniqueConstraint("source", "security_id", name="uq_instrument_source_security"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source: Mapped[str] = mapped_column(String(32), default="dhan", nullable=False)
    security_id: Mapped[str] = mapped_column(String(64), nullable=False)
    exchange: Mapped[Optional[str]] = mapped_column(String(16))
    segment: Mapped[Optional[str]] = mapped_column(String(32))
    instrument: Mapped[Optional[str]] = mapped_column(String(32))
    underlying_symbol: Mapped[Optional[str]] = mapped_column(String(128))
    trading_symbol: Mapped[Optional[str]] = mapped_column(String(128))
    display_name: Mapped[Optional[str]] = mapped_column(String(256))
    lot_size: Mapped[Optional[str]] = mapped_column(String(64))
    expiry_date: Mapped[Optional[str]] = mapped_column(String(32))
    strike_price: Mapped[Optional[str]] = mapped_column(String(64))
    option_type: Mapped[Optional[str]] = mapped_column(String(8))
    tick_size: Mapped[Optional[str]] = mapped_column(String(64))
    raw_json: Mapped[Optional[str]] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
