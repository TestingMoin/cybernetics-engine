import pytest

from cybernetics.runtime.control_wiring import ControlRuntimeWiring, ControlRuntimeWiringError
from cybernetics.runtime.production import RuntimeDependencyState
from cybernetics.runtime.state import ControlState, EmergencyState
from cybernetics.runtime.production import ProductionRuntimeSignals


def test_control_wiring_projects_clear_running_state():
    w = ControlRuntimeWiring(control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR)
    assert w.safe_for_new_trades() is True
    assert w.snapshot().control_state is ControlState.RUNNING


def test_stop_new_trades_blocks_without_emergency():
    w = ControlRuntimeWiring(control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR)
    assert w.safe_for_new_trades() is False


def test_emergency_is_independent_blocker():
    w = ControlRuntimeWiring(control_state=ControlState.RUNNING, emergency_state=EmergencyState.ACTIVE)
    snap = w.snapshot()
    assert snap.emergency_state is EmergencyState.ACTIVE
    assert w.safe_for_new_trades() is False


def test_callable_probes_are_resolved_each_snapshot():
    state = {"control": ControlState.RUNNING, "emergency": EmergencyState.CLEAR}
    w = ControlRuntimeWiring(
        control_state=lambda: state["control"],
        emergency_state=lambda: state["emergency"],
    )
    assert w.safe_for_new_trades() is True
    state["control"] = ControlState.STOP_NEW_TRADES
    assert w.safe_for_new_trades() is False


def test_invalid_probe_fails_closed():
    w = ControlRuntimeWiring(control_state="UNKNOWN", emergency_state=EmergencyState.CLEAR)
    with pytest.raises(ControlRuntimeWiringError):
        w.snapshot()

def test_production_runtime_accepts_control_wiring(tmp_path, monkeypatch):
    from cybernetics.config.settings import DeploymentConfig, TradingMode
    from cybernetics.runtime.production import build_production_runtime

    monkeypatch.setenv("CYBERNETICS_CONFIG_DIR", str(tmp_path))
    cfg = DeploymentConfig(trading_mode=TradingMode.PAPER)
    state = RuntimeDependencyState()
    app = build_production_runtime(
        cfg,
        dependency_state=state,
        control_runtime=ControlRuntimeWiring(
            control_state=ControlState.STOP_NEW_TRADES,
            emergency_state=EmergencyState.CLEAR,
        ),
    )
    snap = app.snapshot()
    assert snap.inputs.control_state is ControlState.STOP_NEW_TRADES
    assert "stop_new_trades" in snap.readiness.reasons
