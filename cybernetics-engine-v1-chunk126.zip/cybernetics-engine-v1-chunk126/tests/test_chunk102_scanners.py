from cybernetics.runtime.scanners import ScannerRuntimeWiring, build_scanner_runtime_wiring
from cybernetics.scanners.models import ScannerRuntimeKey, ScannerState
from cybernetics.scanners.registry import ScannerRuntimeRegistry


def key(name="ICE-NIFTY"):
    return ScannerRuntimeKey(name, "NIFTY", "5m")


def test_empty_registry_fails_closed():
    wiring = build_scanner_runtime_wiring(registry=ScannerRuntimeRegistry())
    assert wiring.scanner_health_ready() is False


def test_running_runtime_is_ready():
    registry = ScannerRuntimeRegistry()
    registry.create(key())
    registry.start(key())
    assert ScannerRuntimeWiring(registry).scanner_health_ready() is True


def test_degraded_runtime_blocks_readiness():
    registry = ScannerRuntimeRegistry()
    registry.create(key())
    registry.start(key())
    registry.degrade(key(), "stale")
    assert ScannerRuntimeWiring(registry).scanner_health_ready() is False


def test_mixed_runtime_states_fail_closed():
    registry = ScannerRuntimeRegistry()
    k1, k2 = key("ICE-NIFTY"), key("ICE-BANKNIFTY")
    registry.create(k1)
    registry.create(k2)
    registry.start(k1)
    assert ScannerRuntimeWiring(registry).scanner_health_ready() is False


def test_custom_readiness_probe_is_supported_and_exceptions_fail_closed():
    registry = ScannerRuntimeRegistry()
    assert ScannerRuntimeWiring(registry, readiness=lambda _: True).scanner_health_ready() is True
    assert ScannerRuntimeWiring(registry, readiness=lambda _: 1 / 0).scanner_health_ready() is False


def test_wiring_is_side_effect_free_and_registry_state_is_observable():
    registry = ScannerRuntimeRegistry()
    k = key()
    registry.create(k)
    registry.start(k)
    before = registry.get(k).event_count
    wiring = build_scanner_runtime_wiring(registry=registry)
    assert wiring.scanner_health_ready() is True
    assert registry.get(k).event_count == before
