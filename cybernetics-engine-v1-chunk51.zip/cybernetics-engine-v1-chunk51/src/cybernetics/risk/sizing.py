from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from math import floor, isfinite
from typing import Optional


class SizingDecision(str, Enum):
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


@dataclass(frozen=True)
class SizingRequest:
    entry_price: float
    stop_price: float
    risk_budget: float
    lot_size: int
    contract_multiplier: float = 1.0
    max_quantity: Optional[int] = None
    max_notional: Optional[float] = None
    available_margin: Optional[float] = None
    margin_per_unit: Optional[float] = None

    def __post_init__(self):
        if not isfinite(self.entry_price) or self.entry_price <= 0:
            raise ValueError("entry_price_must_be_positive")
        if not isfinite(self.stop_price) or self.stop_price <= 0:
            raise ValueError("stop_price_must_be_positive")
        if not isfinite(self.risk_budget) or self.risk_budget <= 0:
            raise ValueError("risk_budget_must_be_positive")
        if self.lot_size <= 0:
            raise ValueError("lot_size_must_be_positive")
        if not isfinite(self.contract_multiplier) or self.contract_multiplier <= 0:
            raise ValueError("contract_multiplier_must_be_positive")
        if self.max_quantity is not None and self.max_quantity < 0:
            raise ValueError("max_quantity_must_be_non_negative")
        if self.max_notional is not None and (not isfinite(self.max_notional) or self.max_notional <= 0):
            raise ValueError("max_notional_must_be_positive")
        if self.available_margin is not None and (not isfinite(self.available_margin) or self.available_margin < 0):
            raise ValueError("available_margin_must_be_non_negative")
        if self.margin_per_unit is not None and (not isfinite(self.margin_per_unit) or self.margin_per_unit <= 0):
            raise ValueError("margin_per_unit_must_be_positive")


@dataclass(frozen=True)
class SizingResult:
    decision: SizingDecision
    reason: str
    quantity: int = 0
    lots: int = 0
    risk_per_unit: float = 0.0
    trade_risk: float = 0.0
    notional: float = 0.0
    estimated_margin: float = 0.0


class PositionSizingEngine:
    """
    Deterministic risk-based position sizing.

    Formula:
      risk_per_unit = abs(entry - stop) * contract_multiplier
      raw_quantity = floor(risk_budget / risk_per_unit)
      quantity = floor(raw_quantity / lot_size) * lot_size

    Quantity is never forced to one lot. If the calculated risk cannot support
    a full lot, the result is rejected.
    """

    def size(self, request: SizingRequest) -> SizingResult:
        stop_distance = abs(request.entry_price - request.stop_price)

        if stop_distance <= 0:
            return SizingResult(
                SizingDecision.REJECTED, "entry_and_stop_must_differ"
            )

        risk_per_unit = stop_distance * request.contract_multiplier
        if risk_per_unit <= 0 or not isfinite(risk_per_unit):
            return SizingResult(
                SizingDecision.REJECTED, "risk_per_unit_invalid"
            )

        raw_quantity = floor(request.risk_budget / risk_per_unit)

        if raw_quantity < request.lot_size:
            return SizingResult(
                SizingDecision.REJECTED,
                "risk_budget_below_one_full_lot_risk",
                risk_per_unit=risk_per_unit,
            )

        quantity = (raw_quantity // request.lot_size) * request.lot_size

        if request.max_quantity is not None:
            quantity = min(quantity, (request.max_quantity // request.lot_size) * request.lot_size)

        if quantity <= 0:
            return SizingResult(
                SizingDecision.REJECTED,
                "lot_aligned_quantity_zero",
                risk_per_unit=risk_per_unit,
            )

        notional = quantity * request.entry_price * request.contract_multiplier
        trade_risk = quantity * risk_per_unit

        if request.max_notional is not None and notional > request.max_notional:
            capped = floor(request.max_notional / (request.entry_price * request.contract_multiplier))
            capped = (capped // request.lot_size) * request.lot_size
            if capped <= 0:
                return SizingResult(
                    SizingDecision.REJECTED,
                    "max_notional_below_one_full_lot",
                    risk_per_unit=risk_per_unit,
                )
            quantity = min(quantity, capped)
            if quantity <= 0:
                return SizingResult(
                    SizingDecision.REJECTED,
                    "notional_cap_produces_zero_quantity",
                    risk_per_unit=risk_per_unit,
                )
            notional = quantity * request.entry_price * request.contract_multiplier
            trade_risk = quantity * risk_per_unit

        estimated_margin = 0.0
        if request.margin_per_unit is not None:
            estimated_margin = quantity * request.margin_per_unit
            if request.available_margin is not None and estimated_margin > request.available_margin:
                capped = floor(request.available_margin / request.margin_per_unit)
                capped = (capped // request.lot_size) * request.lot_size
                if capped <= 0:
                    return SizingResult(
                        SizingDecision.REJECTED,
                        "available_margin_below_one_full_lot",
                        risk_per_unit=risk_per_unit,
                    )
                quantity = min(quantity, capped)
                notional = quantity * request.entry_price * request.contract_multiplier
                trade_risk = quantity * risk_per_unit
                estimated_margin = quantity * request.margin_per_unit

        lots = quantity // request.lot_size

        return SizingResult(
            SizingDecision.APPROVED,
            "risk_sized_quantity_created",
            quantity=quantity,
            lots=lots,
            risk_per_unit=risk_per_unit,
            trade_risk=trade_risk,
            notional=notional,
            estimated_margin=estimated_margin,
        )
