import pytest
from cybernetics.reconcile.position import (
    BrokerPosition,InternalPosition,PositionReconciler,
    PositionReconciliationStatus,ReconciliationTradingGate
)

R=PositionReconciler(price_tolerance=0.01)

def i(side="LONG",qty=10,avg=100):
    return InternalPosition("NSE_FNO","123","NIFTY",side,qty,avg)
def b(qty=10,avg=100,pos="LONG"):
    return BrokerPosition("NSE_FNO","123","NIFTY",pos,qty,avg)

def test_consistent():
    r=R.reconcile(i(),b())
    assert r.status==PositionReconciliationStatus.CONSISTENT
    assert r.quantity_match and r.side_match and r.average_price_match

def test_quantity_mismatch_blocks():
    r=R.reconcile(i(qty=10),b(qty=5))
    assert r.status==PositionReconciliationStatus.MISMATCH
    assert not r.quantity_match

def test_side_mismatch_blocks():
    r=R.reconcile(i(side="LONG"),b(qty=-10,pos="SHORT"))
    assert r.status==PositionReconciliationStatus.MISMATCH
    assert not r.side_match

def test_average_price_tolerance():
    assert R.reconcile(i(avg=100),b(avg=100.009)).status==PositionReconciliationStatus.CONSISTENT
    assert R.reconcile(i(avg=100),b(avg=100.02)).status==PositionReconciliationStatus.MISMATCH

def test_broker_only_position():
    r=R.reconcile(None,b())
    assert r.status==PositionReconciliationStatus.BROKER_ONLY
    assert r.broker_quantity==10

def test_internal_only_position():
    r=R.reconcile(i(),None)
    assert r.status==PositionReconciliationStatus.INTERNAL_ONLY
    assert r.internal_quantity==10

def test_identity_mismatch():
    r=R.reconcile(i(),BrokerPosition("NSE_FNO","999","NIFTY","LONG",10,100))
    assert r.status==PositionReconciliationStatus.MISMATCH

def test_missing_both_invalid():
    assert R.reconcile(None,None).status==PositionReconciliationStatus.INVALID

def test_gate_allows_only_consistent():
    g=ReconciliationTradingGate()
    good=R.reconcile(i(),b())
    bad=R.reconcile(i(),b(qty=9))
    assert g.can_open_new_trade(good)
    assert not g.can_open_new_trade(bad)

def test_negative_broker_qty_uses_absolute_quantity():
    r=R.reconcile(i(side="SHORT"),b(qty=-10,pos="SHORT"))
    assert r.quantity_match and r.side_match

def test_zero_flat_position():
    r=R.reconcile(i(side="FLAT",qty=0,avg=None),b(qty=0,avg=None,pos="CLOSED"))
    assert r.status==PositionReconciliationStatus.CONSISTENT

def test_invalid_tolerance():
    with pytest.raises(ValueError,match="price_tolerance_must_be_non_negative"):
        PositionReconciler(-1)

def test_none_average_is_not_equal_to_real_price():
    r=R.reconcile(i(avg=100),b(avg=None))
    assert r.status==PositionReconciliationStatus.MISMATCH
    assert not r.average_price_match
