# Cybernetics Trading Engine — Chunk 36

## Runtime Instrument / Universe Master + Contract Identity + Lifecycle

This chunk introduces the runtime identity layer that prevents strategies from inventing
symbols, expiries, strikes, lot sizes or security IDs.

### Instrument identity

Every instrument is keyed by:
`(exchange_segment, security_id)`

The record can also carry:
- symbol/trading symbol
- instrument type
- underlying security ID/symbol
- expiry
- option type
- strike
- lot size
- tick size

### Lifecycle

New or newly discovered instruments start as `UNVERIFIED`.

Lifecycle controls:
`UNVERIFIED -> ACTIVE`
`ACTIVE -> WARNING -> NO_NEW_TRADES -> RETIRED`

The current implementation keeps removed instruments out of the active registry while
retaining a lifecycle warning for governance. Production persistence/approval workflows
will connect to the existing audit DB.

### Contract resolver

Futures and options are selected strictly from the loaded instrument master.
No symbols or Security IDs are fabricated.

Current Dhan V2 instrument documentation exposes the instrument master CSVs and fields
including exchange/segment, instrument, underlying security ID/symbol, trading symbol,
lot size and derivative attributes. Dhan also publishes exchange-segment enums such as
NSE_FNO, BSE_FNO and MCX_COMM.
