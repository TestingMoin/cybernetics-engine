import pytest
from cybernetics.persistence.migration import (
    Migration, MigrationRunner, SchemaVersion,
    StartupSchemaValidator, MIGRATIONS, STARTUP_REQUIRED_TABLES
)

class Executor:
    def __init__(self): self.sql=[]
    def execute(self,sql): self.sql.append(sql)

def test_migrations_are_ordered():
    assert [m.version for m in MIGRATIONS] == [1,2,3]

def test_duplicate_versions_rejected():
    with pytest.raises(ValueError,match="duplicate_migration_version"):
        MigrationRunner((Migration(1,"a",""),Migration(1,"b","")))

def test_unsorted_versions_rejected():
    with pytest.raises(ValueError,match="migrations_must_be_sorted"):
        MigrationRunner((Migration(2,"b",""),Migration(1,"a","")))

def test_pending_migrations():
    r=MigrationRunner(MIGRATIONS)
    p=r.pending(1)
    assert [m.version for m in p]==[2,3]

def test_apply_executes_only_pending():
    e=Executor()
    v=MigrationRunner(MIGRATIONS).apply(e,1)
    assert len(e.sql)==2
    assert v==SchemaVersion(3,"fill_outbox")

def test_apply_at_latest_is_noop():
    e=Executor()
    v=MigrationRunner(MIGRATIONS).apply(e,3)
    assert e.sql==[]
    assert v.version==3

def test_schema_version_ddl_exists():
    assert "CREATE TABLE IF NOT EXISTS schema_version" in MIGRATIONS[0].sql

def test_fill_ledger_has_primary_key():
    assert "fill_id TEXT PRIMARY KEY" in MIGRATIONS[1].sql

def test_outbox_has_unique_fill_constraint():
    assert "uq_fill_outbox_fill_id" in MIGRATIONS[2].sql

def test_required_tables_are_explicit():
    assert STARTUP_REQUIRED_TABLES==("fill_ledger","fill_outbox")

def test_startup_validation_ready():
    r=StartupSchemaValidator().validate(
        existing_tables={"schema_version","fill_ledger","fill_outbox"},
        migration_version=3
    )
    assert r.ready and r.missing_tables==()

def test_startup_validation_missing_table():
    r=StartupSchemaValidator().validate(
        existing_tables={"schema_version","fill_ledger"},
        migration_version=2
    )
    assert not r.ready
    assert r.missing_tables==("fill_outbox",)

def test_startup_validation_missing_both():
    r=StartupSchemaValidator().validate(
        existing_tables=set(), migration_version=0
    )
    assert r.missing_tables==("fill_ledger","fill_outbox")

def test_runner_preserves_migration_sql():
    e=Executor()
    MigrationRunner(MIGRATIONS).apply(e,0)
    assert "fill_ledger" in e.sql[1]
    assert "fill_outbox" in e.sql[2]
