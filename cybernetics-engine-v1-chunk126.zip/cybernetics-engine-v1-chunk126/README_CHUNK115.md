# Chunk 115 — Runtime Audit/Event Integration

Adds a canonical runtime audit event boundary over the existing `engine_events` PostgreSQL table.

Implemented:
- `PostgresEngineEventRepository` with idempotent `event_id` writes.
- `RuntimeAuditEmitter` for lifecycle and readiness events.
- Optional `RuntimeApplication.audit` integration.
- Readiness events are emitted only when the readiness/trading gate changes, preventing per-cycle audit spam.
- Additive migration metadata v3 formalizes `engine_events` as the canonical runtime audit stream without creating a second table.
- No broker I/O, order submission, live authorization, or production DB connection is created automatically.
