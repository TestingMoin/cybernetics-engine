from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from threading import RLock
from typing import Any, Callable, Optional

class TokenState(str, Enum):
    MISSING="MISSING"
    VALID="VALID"
    RENEW_REQUIRED="RENEW_REQUIRED"
    EXPIRED="EXPIRED"

@dataclass(frozen=True)
class TokenRecord:
    access_token: str
    expires_at: datetime
    issued_at: datetime

class DhanTokenManager:
    """
    Central Dhan token lifecycle.

    The manager keeps tokens in memory only. Credentials/TOTP/PIN are supplied
    through callbacks or secret providers and are never embedded in source.
    """
    GENERATE_URL="https://auth.dhan.co/app/generateAccessToken"
    RENEW_URL="https://api.dhan.co/v2/RenewToken"

    def __init__(
        self,
        dhan_client_id: str,
        transport: Callable[..., Any],
        now: Optional[Callable[[], datetime]] = None,
        refresh_margin: timedelta = timedelta(minutes=5),
    ):
        if not dhan_client_id:
            raise ValueError("dhan_client_id_required")
        if refresh_margin.total_seconds() < 0:
            raise ValueError("refresh_margin_must_be_non_negative")
        self._client_id=dhan_client_id
        self._transport=transport
        self._now=now or (lambda: datetime.now(timezone.utc))
        self._refresh_margin=refresh_margin
        self._record: Optional[TokenRecord]=None
        self._lock=RLock()

    @property
    def record(self) -> Optional[TokenRecord]:
        with self._lock:
            return self._record

    def set_token(self, access_token: str, expires_at: datetime,
                  issued_at: Optional[datetime]=None) -> TokenRecord:
        if not access_token:
            raise ValueError("access_token_required")
        if expires_at.tzinfo is None:
            raise ValueError("expires_at_must_be_timezone_aware")
        issued=issued_at or self._now()
        if issued.tzinfo is None:
            raise ValueError("issued_at_must_be_timezone_aware")
        record=TokenRecord(access_token, expires_at, issued)
        with self._lock:
            self._record=record
        return record

    def state(self) -> TokenState:
        with self._lock:
            if self._record is None:
                return TokenState.MISSING
            now=self._now()
            if now >= self._record.expires_at:
                return TokenState.EXPIRED
            if now + self._refresh_margin >= self._record.expires_at:
                return TokenState.RENEW_REQUIRED
            return TokenState.VALID

    def authorization_header(self) -> dict[str,str]:
        with self._lock:
            if self.state() == TokenState.EXPIRED:
                raise RuntimeError("access_token_expired")
            if self._record is None:
                raise RuntimeError("access_token_missing")
            return {"access-token": self._record.access_token}

    def generate_with_totp(self, pin: str, totp: str) -> TokenRecord:
        if not pin or not totp:
            raise ValueError("pin_and_totp_required")
        response=self._transport(
            "POST", self.GENERATE_URL,
            params={
                "dhanClientId": self._client_id,
                "pin": pin,
                "totp": totp,
            },
            headers={"Accept":"application/json"},
        )
        return self._accept_generated(response)

    def renew(self) -> TokenRecord:
        with self._lock:
            if self._record is None:
                raise RuntimeError("no_active_token_to_renew")
            if self._now() >= self._record.expires_at:
                raise RuntimeError("token_already_expired")
            current=self._record.access_token

        response=self._transport(
            "POST", self.RENEW_URL,
            headers={
                "Accept":"application/json",
                "access-token": current,
                "dhanClientId": self._client_id,
            },
        )
        return self._accept_generated(response)

    def _accept_generated(self, response: Any) -> TokenRecord:
        if not isinstance(response, dict):
            raise RuntimeError("invalid_auth_response")

        token=response.get("accessToken")
        expiry=response.get("expiryTime")
        if not token or not expiry:
            error=response.get("errorMessage") or response.get("message") or "token_generation_failed"
            raise RuntimeError(str(error))

        expires=self._parse_timestamp(str(expiry))
        return self.set_token(str(token), expires)

    @staticmethod
    def _parse_timestamp(value: str) -> datetime:
        # Dhan returns ISO-like timestamps; accept Z and explicit offsets.
        text=value.strip()
        if text.endswith("Z"):
            text=text[:-1] + "+00:00"
        dt=datetime.fromisoformat(text)
        if dt.tzinfo is None:
            # Dhan documents expiryTime as IST; normalize to +05:30.
            from datetime import timezone as _timezone, timedelta as _timedelta
            dt=dt.replace(tzinfo=_timezone(_timedelta(hours=5, minutes=30)))
        return dt
