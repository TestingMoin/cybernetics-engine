# Cybernetics Trading Engine

Canonical unified release-candidate source for the Cybernetics Trading Engine.

## Canonical entrypoint

The production process entrypoint is now:

```bash
python -m cybernetics --self-check
python -m cybernetics --once
python -m cybernetics
```

The same entrypoint is exposed as the `cybernetics-engine` console script when the package is installed.

**Safety:** the bootstrap composition is fail-closed. It does not connect to Dhan, enable live trading, submit orders, mutate production state, or bypass existing control/risk gates. Real persistence, market-data, broker, recovery, and control dependencies must be injected by the later production composition work.

## Validation

Chunk 94 establishes the canonical executable lifecycle and composition boundary. It is not a production deployment and does not authorize live trading.
