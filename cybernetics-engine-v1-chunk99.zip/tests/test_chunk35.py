from datetime import datetime, timezone, timedelta
from cybernetics.state.store import Candle, CanonicalMarketStateStore
from cybernetics.state.merge_policy import merge_recovered_candles
from cybernetics.state.reconcile import StateReconciler, StateStatus

T=datetime(2026,1,1,9,15,tzinfo=timezone.utc)
def c(ts=T, close=100, source="LIVE"):
    return Candle("1",ts,99,101,98,close,1000,source)

def test_insert_then_duplicate_is_idempotent():
    s=CanonicalMarketStateStore()
    assert s.upsert(c())=="INSERTED"
    assert s.upsert(c())=="DUPLICATE"
    assert s.get("1",T)==c()

def test_conflicting_value_is_not_overwritten():
    s=CanonicalMarketStateStore()
    s.upsert(c(close=100))
    assert s.upsert(c(close=101,source="REST"))=="CONFLICT"
    assert s.get("1",T).close==100
    assert len(s.conflicts("1"))==1

def test_merge_report_not_ready_on_conflict():
    s=CanonicalMarketStateStore()
    s.upsert(c())
    r=merge_recovered_candles(s,[c(close=101,source="REST")])
    assert r.conflicts==1 and r.ready is False

def test_recent_is_timestamp_ordered():
    s=CanonicalMarketStateStore()
    s.merge([
        Candle("1",T+timedelta(minutes=2),99,103,98,102,1000,"LIVE"),
        c(T,100),
        Candle("1",T+timedelta(minutes=1),99,102,98,101,1000,"LIVE"),
    ])
    assert [x.close for x in s.recent("1",3)]==[100,101,102]

def test_reconcile_consistent():
    s=CanonicalMarketStateStore()
    r=StateReconciler(s).reconcile("1",[c(T,100)],[c(T,100,source="REST")])
    assert r.status==StateStatus.CONSISTENT

def test_reconcile_rest_ahead_detects_missing_live():
    s=CanonicalMarketStateStore()
    r=StateReconciler(s).reconcile("1",
        [c(T,100)],[c(T,100,"REST"),c(T+timedelta(minutes=1),101,"REST")])
    assert r.status==StateStatus.REST_AHEAD
    assert r.missing_live==1

def test_reconcile_live_ahead_detects_extra_live():
    s=CanonicalMarketStateStore()
    r=StateReconciler(s).reconcile("1",
        [c(T,100),c(T+timedelta(minutes=1),101)],
        [c(T,100,"REST")])
    assert r.status==StateStatus.LIVE_AHEAD
    assert r.missing_rest==1

def test_reconcile_conflict_detects_value_difference():
    s=CanonicalMarketStateStore()
    r=StateReconciler(s).reconcile("1",
        [c(T,100)],[c(T,101,"REST")])
    assert r.status==StateStatus.CONFLICT
    assert r.conflicts==1

def test_invalid_negative_price_rejected():
    try:
        Candle("1",T,-1,1,0,1)
        assert False
    except ValueError as e:
        assert str(e)=="negative_candle_price"
