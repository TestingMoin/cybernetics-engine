from cybernetics.control.gateway import (
    ControlCommandGateway, ControlCommand, CommandName, CommandResult
)
from cybernetics.control.postgres_gateway import PostgresControlCommandGateway
from cybernetics.control.repository import (
    ControlCommandRepository, CommandAuditRecord, CommandRecordState
)
from cybernetics.runtime.control import (
    ControlState, ControlStateMachine, GuardedController, TransitionPolicy
)

NOW=1000.0

class Result:
    def __init__(self,rowcount=1): self.rowcount=rowcount

class Tx:
    def __init__(self, existing=None, insert_return=("NEW",), rowcount=1):
        self.existing=existing
        self.insert_return=insert_return
        self.rowcount=rowcount
        self.calls=[]
    def __enter__(self): return self
    def __exit__(self,*args): return False
    def fetchone(self,sql,params=()):
        self.calls.append(("fetchone",sql,params))
        if "SELECT command_id, result, state, reason" in sql:
            return self.existing
        if "INSERT INTO control_command_audit" in sql:
            return self.insert_return
        return None
    def execute(self,sql,params=()):
        self.calls.append(("execute",sql,params))
        return Result(self.rowcount)

class ConnFactory:
    def __init__(self,tx): self.tx=tx
    def __call__(self): return self.tx

class Ids:
    def __init__(self): self.ids=set()
    def seen(self,c): return c in self.ids
    def remember(self,c): self.ids.add(c)

class Audit:
    def __init__(self): self.events=[]
    def record(self,**e): self.events.append(e)

def gw(state=ControlState.RUNNING):
    m=ControlStateMachine(state)
    return ControlCommandGateway(
        GuardedController(m),Ids(),Audit(),clock=lambda:NOW
    )

def c(name=CommandName.STOP_NEW_TRADES,cid="C1",source="PWA",
      expected=None,issued=NOW):
    return ControlCommand(cid,name,issued,source,expected)

def record(cid="C1",result=CommandRecordState.ACCEPTED):
    return CommandAuditRecord(
        cid,"STOP_NEW_TRADES","PWA",result,"STOP_NEW_TRADES",
        "command_applied",NOW
    )

def test_valid_command_passes_through():
    g=gw()
    r=g.handle(c())
    assert r.result is CommandResult.ACCEPTED
    assert r.state is ControlState.STOP_NEW_TRADES

def test_stale_protection_preserved():
    assert gw().handle(c(issued=NOW-31)).result is CommandResult.STALE

def test_duplicate_protection_preserved():
    g=gw()
    assert g.handle(c()).result is CommandResult.ACCEPTED
    assert g.handle(c(cid="C1")).result is CommandResult.DUPLICATE

def test_resume_still_requires_expected_state():
    g=gw(ControlState.STOP_NEW_TRADES)
    r=g.handle(c(CommandName.RESUME_NEW_TRADES,"R1"))
    assert r.result is CommandResult.REJECTED

def test_resume_still_requires_independent_policy():
    g=gw(ControlState.STOP_NEW_TRADES)
    r=g.handle(
        c(CommandName.RESUME_NEW_TRADES,"R2",expected=ControlState.STOP_NEW_TRADES),
        policy=TransitionPolicy(False,True)
    )
    assert r.result is CommandResult.REJECTED

def test_durable_wrapper_persists_accepted_command():
    tx=Tx(existing=None,insert_return=("C1",))
    wrapper=PostgresControlCommandGateway(gw(),ConnFactory(tx))
    r=wrapper.handle(c())
    assert r.result is CommandResult.ACCEPTED
    assert any("INSERT INTO control_command_audit" in x[1] for x in tx.calls)

def test_durable_wrapper_persists_stale_result():
    tx=Tx(existing=None,insert_return=("C1",))
    wrapper=PostgresControlCommandGateway(gw(),ConnFactory(tx))
    r=wrapper.handle(c(issued=NOW-100))
    assert r.result is CommandResult.STALE

def test_durable_status_missing():
    wrapper=PostgresControlCommandGateway(
        gw(),ConnFactory(Tx(existing=None))
    )
    s=wrapper.durable_status("MISSING")
    assert not s.persisted and s.result=="NOT_FOUND"

def test_durable_status_found():
    tx=Tx(existing=("C1","ACCEPTED","STOP_NEW_TRADES","command_applied"))
    s=PostgresControlCommandGateway(gw(),ConnFactory(tx)).durable_status("C1")
    assert s.persisted and s.result=="ACCEPTED"
    assert s.state=="STOP_NEW_TRADES"

def test_postgres_repository_first_writer_wins():
    tx=Tx(existing=None,insert_return=("C1",))
    assert ControlCommandRepository(tx).ensure_command_record(record())
    assert "ON CONFLICT (command_id) DO NOTHING" in tx.calls[-1][1]

def test_postgres_repository_duplicate_is_false():
    tx=Tx(existing=None,insert_return=None)
    assert not ControlCommandRepository(tx).ensure_command_record(record())

def test_gateway_source_restriction_preserved():
    assert gw().handle(c(source="UNKNOWN")).result is CommandResult.REJECTED

def test_gateway_expected_state_protection_preserved():
    assert gw().handle(c(expected=ControlState.STOP_NEW_TRADES)).result is CommandResult.REJECTED

def test_emergency_stop_remains_fast_path():
    r=gw().handle(c(CommandName.EMERGENCY_STOP,"E1"))
    assert r.result is CommandResult.ACCEPTED
    assert r.state is ControlState.EMERGENCY_STOP

def test_emergency_stop_does_not_authorize_live_trading():
    g=gw()
    r=g.handle(c(CommandName.EMERGENCY_STOP,"E2"))
    assert r.state is ControlState.EMERGENCY_STOP

def test_system_source_supported():
    assert gw().handle(c(source="SYSTEM")).result is CommandResult.ACCEPTED

def test_telegram_source_supported():
    assert gw().handle(c(source="TELEGRAM",cid="T2")).result is CommandResult.ACCEPTED

def test_wrapper_does_not_submit_orders():
    from pathlib import Path
    src=Path("src/cybernetics/control/postgres_gateway.py").read_text()
    for token in ("/v2/orders","place_order","submit_order","cancel_order","replace_order"):
        assert token not in src

def test_wrapper_does_not_create_live_authorization():
    from pathlib import Path
    src=Path("src/cybernetics/control/postgres_gateway.py").read_text()
    assert "approve(" not in src

def test_wrapper_uses_caller_owned_transaction():
    tx=Tx()
    factory=ConnFactory(tx)
    wrapper=PostgresControlCommandGateway(gw(),factory)
    wrapper.handle(c())
    assert factory.tx is tx

def test_persistence_result_maps_from_gateway_receipt():
    tx=Tx(existing=None,insert_return=("C1",))
    wrapper=PostgresControlCommandGateway(gw(),ConnFactory(tx))
    r=wrapper.handle(c())
    assert r.reason=="command_applied"

def test_durable_duplicate_is_blocked_before_state_machine():
    tx=Tx(existing=("C1","ACCEPTED","STOP_NEW_TRADES","command_applied"))
    g=gw()
    wrapper=PostgresControlCommandGateway(g,ConnFactory(tx))
    r=wrapper.handle(c())
    assert r.result is CommandResult.ACCEPTED
    assert r.state is ControlState.STOP_NEW_TRADES
    # Gateway state stays RUNNING because durable replay was handled before it ran.
    assert g.controller.machine.state is ControlState.RUNNING

def test_repository_sql_is_parameterized():
    tx=Tx(existing=None,insert_return=("C1",))
    ControlCommandRepository(tx).ensure_command_record(record())
    params=tx.calls[-1][2]
    assert "STOP_NEW_TRADES" in params and "PWA" in params
