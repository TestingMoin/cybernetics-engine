# Cybernetics Trading Engine — Chunk 45

## Strategy Decision Engine Integration

This chunk connects qualified signals to the deterministic strategy framework.

### Flow

Signal lifecycle/qualification -> StrategyContext -> Versioned StrategyDefinition
-> StrategyDecision.

### Important separation

A `StrategyDecision` is not an order.

It does not contain broker order IDs, quantities, prices, or execution commands.
The next layers must still perform quality/confluence, risk sizing, pre-trade validation,
instrument selection and execution.

A minimal direction-mapping strategy is included only as an integration/test fixture.
It is not a production trading strategy and does not introduce indicator combinations.

The existing Golden Strategy reproduction work remains subject to the prior rule:
exact reproduction against the Pine source must be validated before enhancement or production use.
