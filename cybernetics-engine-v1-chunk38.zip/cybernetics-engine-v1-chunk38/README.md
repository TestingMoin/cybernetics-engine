# Cybernetics Trading Engine — Chunk 38

## Scanner Runtime Registry + Per-Underlying Isolated State

This chunk turns the logical scanner-group architecture into isolated runtime instances.

### Isolation key

`scanner_id + underlying_key + timeframe`

Examples:
- ICE-NIFTY + NIFTY + 1m
- ICE-NIFTY + BANKNIFTY + 1m
- ICE-NIFTY + NIFTY + 5m

These are separate state containers even when they share the same reusable scanner code.

### Why this matters

Indicator state, rolling windows, absorption evidence, gap context, signal counters and other
mutable scanner state must never leak between NIFTY, BANKNIFTY, SENSEX, MCX contracts or stocks.

A degraded/failed scanner is prevented from processing market events until explicitly returned
to a runnable state.

This chunk does not create trades and does not select instruments; it provides the runtime
isolation layer for the scanner ecosystem.
