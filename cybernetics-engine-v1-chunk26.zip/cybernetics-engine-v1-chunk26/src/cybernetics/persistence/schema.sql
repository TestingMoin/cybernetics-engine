-- Durable client-side identity for order submission.
-- The project-wide DB schema from the earlier persistence milestone owns
-- the broader orders table; this migration adds the uniqueness guarantee
-- required by the idempotency layer.

ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS client_order_key TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS ux_orders_client_order_key
    ON orders(client_order_key)
    WHERE client_order_key IS NOT NULL;
