from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def test_remote_deploy_uses_dynamic_remote_tag():
    s=(ROOT/'deploy/scripts/remote_deploy_staging.sh').read_text()
    assert 'REMOTE_TAG="${REMOTE_TAG:-chunk126}"' in s
    assert 'staging/${REMOTE_TAG}' in s

def test_remote_deploy_uses_batchmode_timeout():
    s=(ROOT/'deploy/scripts/remote_deploy_staging.sh').read_text()
    assert 'BatchMode=yes' in s and 'ConnectTimeout=10' in s

def test_execute_requires_explicit_confirmation():
    s=(ROOT/'deploy/scripts/execute_staging_install.sh').read_text()
    assert 'INSTALL_STAGING_ONLY' in s
    assert 'CYBERNETICS_STAGING_CONFIRM' in s

def test_execute_enforces_paper_mode():
    s=(ROOT/'deploy/scripts/execute_staging_install.sh').read_text()
    assert 'CYBERNETICS_TRADING_MODE=paper' in s
    assert 'CYBERNETICS_ORDER_SUBMISSION_ENABLED=false' in s
