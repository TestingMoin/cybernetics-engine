from __future__ import annotations

from .interface import BrokerAdapter, OrderRequest, OrderResult


class DhanV2BrokerAdapter:
    """Broker boundary. No strategy is allowed to call the Dhan SDK directly."""

    def __init__(self, client_id: str, access_token: str) -> None:
        self.client_id = client_id
        self.access_token = access_token

    async def health(self) -> bool:
        return bool(self.client_id and self.access_token)

    async def place_order(self, request: OrderRequest) -> OrderResult:
        raise NotImplementedError("Dhan order transport is enabled only after adapter integration tests pass")

    async def cancel_order(self, order_id: str) -> OrderResult:
        raise NotImplementedError("Dhan order transport not wired in foundation build")

    async def get_orders(self) -> list[dict]:
        raise NotImplementedError

    async def get_positions(self) -> list[dict]:
        raise NotImplementedError
