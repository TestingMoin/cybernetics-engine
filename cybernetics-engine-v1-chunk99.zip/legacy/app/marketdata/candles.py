from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from app.marketdata.normalize import NormalizedTick

IST = ZoneInfo("Asia/Kolkata")


@dataclass(frozen=True, slots=True)
class Candle:
    exchange_segment: int
    security_id: str
    timeframe: str
    start: datetime
    end: datetime
    open: float
    high: float
    low: float
    close: float
    volume: int
    volume_delta: int
    trades: int
    closed: bool = True


def _floor(dt: datetime, minutes: int) -> datetime:
    local = dt.astimezone(IST)
    minute = (local.minute // minutes) * minutes
    floored = local.replace(minute=minute, second=0, microsecond=0)
    return floored.astimezone(timezone.utc)


class CandleBuilder:
    """Deterministic OHLCV aggregation from normalized event/tick prices.

    Cumulative Dhan volume is converted into non-negative interval volume.
    A counter reset starts a new baseline; volume is never fabricated.
    """

    def __init__(self, timeframes: tuple[str, ...] = ("1m", "5m", "15m", "30m", "1h")) -> None:
        self.timeframes = timeframes
        self._current: dict[tuple[int, str, str], Candle] = {}
        self._last_volume: dict[tuple[int, str, str], int] = {}

    @staticmethod
    def _minutes(tf: str) -> int:
        unit = tf[-1].lower()
        n = int(tf[:-1])
        if unit == "m":
            return n
        if unit == "h":
            return n * 60
        raise ValueError(f"unsupported timeframe: {tf}")

    def update(self, tick: NormalizedTick) -> list[Candle]:
        if tick.price is None or tick.quality.value == "reject":
            return []
        emitted: list[Candle] = []
        for tf in self.timeframes:
            key = (tick.exchange_segment, tick.security_id, tf)
            minutes = self._minutes(tf)
            start = _floor(tick.trade_at or tick.observed_at, minutes)
            end = start + timedelta(minutes=minutes)
            previous = self._current.get(key)
            if previous is not None and previous.start != start:
                emitted.append(previous)
                previous = None

            last_volume = self._last_volume.get(key)
            if tick.cumulative_volume is None:
                delta = 0
            elif last_volume is None:
                delta = 0  # establish baseline; prior-session cumulative volume is not our interval volume
            elif tick.cumulative_volume >= last_volume:
                delta = tick.cumulative_volume - last_volume
            else:
                delta = 0  # feed/counter reset; do not manufacture volume
            if tick.cumulative_volume is not None:
                self._last_volume[key] = tick.cumulative_volume

            if previous is None:
                candle = Candle(tick.exchange_segment, tick.security_id, tf, start, end, tick.price, tick.price,
                                tick.price, tick.price, delta, delta, 1, closed=False)
            else:
                candle = Candle(previous.exchange_segment, previous.security_id, previous.timeframe, previous.start,
                                previous.end, previous.open, max(previous.high, tick.price), min(previous.low, tick.price),
                                tick.price, previous.volume + delta, previous.volume_delta + delta, previous.trades + 1,
                                closed=False)
            self._current[key] = candle
        return emitted

    def flush(self, at: datetime | None = None) -> list[Candle]:
        now = (at or datetime.now(timezone.utc)).astimezone(timezone.utc)
        emitted: list[Candle] = []
        for key, candle in list(self._current.items()):
            if now >= candle.end:
                emitted.append(Candle(**{**candle.__dict__, "closed": True}) if hasattr(candle, "__dict__") else Candle(
                    candle.exchange_segment, candle.security_id, candle.timeframe, candle.start, candle.end,
                    candle.open, candle.high, candle.low, candle.close, candle.volume, candle.volume_delta, candle.trades, True
                ))
                del self._current[key]
        return emitted
