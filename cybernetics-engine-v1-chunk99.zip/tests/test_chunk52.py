from cybernetics.pretrade.gate import (
    ComprehensivePreTradeGate, GateDecision, PreTradeContext
)

G = ComprehensivePreTradeGate()

def ctx(**kw):
    d = dict(
        engine_running=True,
        emergency_stop=False,
        live_authorized=False,
        reconciliation_ok=True,
        market_data_ready=True,
        scanner_healthy=True,
        signal_qualified=True,
        strategy_decision_valid=True,
        position_state_valid=True,
        risk_approved=True,
        sizing_approved=True,
        quantity=10,
        lot_size=10,
        execution_mode="paper",
        action="ENTER_LONG",
        broker_available=True,
        max_daily_loss_reached=False,
        max_exposure_reached=False,
    )
    d.update(kw)
    return PreTradeContext(**d)

def test_normal_paper_entry_approved():
    r=G.evaluate(ctx())
    assert r.decision==GateDecision.APPROVED

def test_engine_off_blocks():
    r=G.evaluate(ctx(engine_running=False))
    assert "engine_not_running" in r.failed_checks

def test_emergency_stop_blocks():
    r=G.evaluate(ctx(emergency_stop=True))
    assert "emergency_stop_active" in r.failed_checks

def test_reconciliation_blocks():
    r=G.evaluate(ctx(reconciliation_ok=False))
    assert "reconciliation_not_ok" in r.failed_checks

def test_unqualified_signal_blocks():
    r=G.evaluate(ctx(signal_qualified=False))
    assert "signal_not_qualified" in r.failed_checks

def test_strategy_decision_invalid_blocks():
    r=G.evaluate(ctx(strategy_decision_valid=False))
    assert "strategy_decision_invalid" in r.failed_checks

def test_risk_or_sizing_failure_blocks_entry():
    assert G.evaluate(ctx(risk_approved=False)).decision==GateDecision.REJECTED
    assert G.evaluate(ctx(sizing_approved=False)).decision==GateDecision.REJECTED

def test_live_requires_independent_authorization():
    r=G.evaluate(ctx(execution_mode="live", live_authorized=False))
    assert "live_authorization_missing" in r.failed_checks
    assert r.decision==GateDecision.REJECTED

def test_lot_alignment_required():
    r=G.evaluate(ctx(quantity=15,lot_size=10))
    assert "quantity_not_lot_aligned" in r.failed_checks

def test_daily_loss_and_exposure_block_entry():
    r=G.evaluate(ctx(max_daily_loss_reached=True, max_exposure_reached=True))
    assert "daily_loss_limit_reached" in r.failed_checks
    assert "max_exposure_reached" in r.failed_checks

def test_exit_safety_path_survives_entry_risk_limits():
    r=G.evaluate(ctx(
        action="EXIT_LONG",
        risk_approved=False,
        sizing_approved=False,
        max_daily_loss_reached=True,
        max_exposure_reached=True,
        quantity=0,
    ))
    assert r.decision==GateDecision.APPROVED

def test_unknown_action_blocked():
    r=G.evaluate(ctx(action="MAGIC"))
    assert r.decision==GateDecision.REJECTED
    assert "non_executable_action" in r.failed_checks

def test_broker_unavailable_blocks():
    r=G.evaluate(ctx(broker_available=False))
    assert r.decision==GateDecision.REJECTED
    assert "broker_unavailable" in r.failed_checks
