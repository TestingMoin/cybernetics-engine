# Cybernetics Trading Engine — Chunk 51

## Deterministic Position Sizing Engine

This chunk implements the first deterministic risk-based sizing boundary.

Core formula:

`risk_per_unit = abs(entry - stop) × contract_multiplier`

`raw_quantity = floor(risk_budget / risk_per_unit)`

`quantity = floor(raw_quantity / lot_size) × lot_size`

Important safety behavior:
- no forced minimum lot
- zero/negative price protection
- entry == stop is rejected
- quantity is lot-aligned
- optional max-quantity cap
- optional max-notional cap
- optional margin-capacity cap
- if a full lot cannot be supported by the risk budget, the request is rejected

This module calculates quantity only. It does not submit orders, call Dhan,
or bypass Pre-Trade / Execution gates.
