from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import AsyncIterator, Iterable

import websockets

from app.auth.dhan_auth import DhanTokenManager

logger = logging.getLogger(__name__)
MARKET_WS_URL = "wss://api-feed.dhan.co"
ORDER_WS_URL = "wss://api-order-update.dhan.co"


@dataclass(frozen=True)
class SubscriptionInstrument:
    exchange_segment: str
    security_id: str


class DhanMarketWebSocket:
    """Reconnectable Dhan v2 market-feed transport.

    Dhan responses are binary packets. This chunk deliberately exposes raw bytes;
    protocol decoding will be implemented in the market-data normalization chunk.
    """

    def __init__(self, client_id: str, token_manager: DhanTokenManager, *, max_reconnect_seconds: float = 30.0) -> None:
        self.client_id = client_id
        self.token_manager = token_manager
        self.max_reconnect_seconds = max_reconnect_seconds
        self._stop = asyncio.Event()
        self._ws = None

    @staticmethod
    def _chunks(items: list[SubscriptionInstrument], size: int = 100) -> Iterable[list[SubscriptionInstrument]]:
        for i in range(0, len(items), size):
            yield items[i:i + size]

    async def _connect(self):
        token = await self.token_manager.get_valid_token()
        uri = f"{MARKET_WS_URL}?version=2&token={token}&clientId={self.client_id}&authType=2"
        return await websockets.connect(uri, ping_interval=20, ping_timeout=20, close_timeout=5, max_size=None)

    @staticmethod
    def _subscribe_message(instruments: list[SubscriptionInstrument]) -> str:
        return json.dumps({
            "RequestCode": 15,
            "InstrumentCount": len(instruments),
            "InstrumentList": [
                {"ExchangeSegment": i.exchange_segment, "SecurityId": str(i.security_id)}
                for i in instruments
            ],
        })

    async def stream(self, instruments: list[SubscriptionInstrument]) -> AsyncIterator[bytes]:
        if not instruments:
            return
        backoff = 1.0
        while not self._stop.is_set():
            try:
                self._ws = await self._connect()
                for chunk in self._chunks(instruments, 100):
                    await self._ws.send(self._subscribe_message(chunk))
                backoff = 1.0
                async for message in self._ws:
                    if isinstance(message, bytes):
                        yield message
                    else:
                        logger.debug("Ignoring unexpected text market-feed packet")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                if self._stop.is_set():
                    break
                logger.warning("Dhan market WebSocket disconnected: %s; retrying", type(exc).__name__)
                await asyncio.sleep(backoff)
                backoff = min(self.max_reconnect_seconds, backoff * 2)
            finally:
                if self._ws is not None:
                    try:
                        await self._ws.close()
                    except Exception:
                        pass
                    self._ws = None

    async def stop(self) -> None:
        self._stop.set()
        if self._ws is not None:
            await self._ws.close()


class DhanOrderUpdateWebSocket:
    """Reconnectable real-time order-update transport for an individual account."""

    def __init__(self, client_id: str, token_manager: DhanTokenManager, *, max_reconnect_seconds: float = 30.0) -> None:
        self.client_id = client_id
        self.token_manager = token_manager
        self.max_reconnect_seconds = max_reconnect_seconds
        self._stop = asyncio.Event()
        self._ws = None

    async def _connect(self):
        token = await self.token_manager.get_valid_token()
        ws = await websockets.connect(ORDER_WS_URL, ping_interval=20, ping_timeout=20, close_timeout=5, max_size=None)
        await ws.send(json.dumps({
            "LoginReq": {"MsgCode": 42, "ClientId": self.client_id, "Token": token},
            "UserType": "SELF",
        }))
        return ws

    async def stream(self) -> AsyncIterator[dict]:
        backoff = 1.0
        while not self._stop.is_set():
            try:
                self._ws = await self._connect()
                backoff = 1.0
                async for message in self._ws:
                    if isinstance(message, str):
                        try:
                            yield json.loads(message)
                        except json.JSONDecodeError:
                            logger.warning("Ignoring malformed Dhan order-update message")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                if self._stop.is_set():
                    break
                logger.warning("Dhan order-update WebSocket disconnected: %s; retrying", type(exc).__name__)
                await asyncio.sleep(backoff)
                backoff = min(self.max_reconnect_seconds, backoff * 2)
            finally:
                if self._ws is not None:
                    try:
                        await self._ws.close()
                    except Exception:
                        pass
                    self._ws = None

    async def stop(self) -> None:
        self._stop.set()
        if self._ws is not None:
            await self._ws.close()
