from __future__ import annotations
import json, os, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'src'))
from cybernetics.runtime.application import RuntimeApplication, RuntimeConfig

def main() -> None:
    os.environ.setdefault('CYBERNETICS_ENV', 'staging')
    app = RuntimeApplication(config=RuntimeConfig(poll_interval_seconds=0.001))
    t0=time.perf_counter(); app.start(); startup=time.perf_counter()-t0
    for _ in range(1000): app.run_cycle()
    n=100_000; t0=time.perf_counter()
    for _ in range(n): app.run_cycle()
    cycles=time.perf_counter()-t0
    app.stop()
    print(json.dumps({
        'startup_seconds': startup,
        'run_cycles': n,
        'cycle_mean_microseconds': cycles/n*1e6,
        'cycle_throughput_per_second': n/cycles,
        'metrics': app.metrics.snapshot().__dict__,
    }, sort_keys=True))

if __name__ == '__main__': main()
