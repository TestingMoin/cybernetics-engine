# Chunk 111 — Runtime Dependency Failure Handling

Built from verified Chunk 110.

## Purpose

Convert runtime dependency loss from a passive `engine_ready = false` observation into an explicit safe-state action.

## Safety behavior

When the runtime is currently `RUNNING` and any critical dependency is unhealthy (`persistence`, `recovery`, `market_data`, `scanners`, `watchdog`, or `broker`), the handler requests `STOP_NEW_TRADES`.

The emergency latch remains independent and authoritative. An already-active emergency state is not rewritten or cleared, and the dependency handler does not submit exit/flatten orders. Open-position exit ownership remains with the separate exit/emergency path.

Non-running/non-trading control states are not redundantly transitioned.

## Validation

- compileall: PASS
- pytest: 892 / 892 PASS
- Dhan orders: none
- production DB mutation: none
- VPS deployment: none
- live trading: disabled
