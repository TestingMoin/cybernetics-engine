# Chunk 114 — Persistent Control/Recovery Audit Integration

Adds a durable, append-only PostgreSQL audit boundary for control/recovery observations and explicit resume decisions.

## Safety
- Control/recovery decisions remain owned by the authoritative runtime state machine.
- Persistence is audit-only and cannot grant live authorization.
- Audit writes use `ON CONFLICT (event_id) DO NOTHING` for event-id idempotency.
- Additive schema migration is separate from the immutable canonical baseline.
- No broker order submission, production DB connection, or live authorization is performed by this chunk.

## Validation
- compileall: PASS
- pytest: 916 passed
- ZIP integrity: PASS
