from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Protocol


@dataclass(frozen=True)
class OrderRequest:
    symbol: str
    exchange_segment: str
    side: str
    quantity: int
    order_type: str
    price: Decimal | None = None
    correlation_id: str = ""


@dataclass(frozen=True)
class OrderResult:
    accepted: bool
    broker_order_id: str | None
    status: str
    message: str = ""


class BrokerAdapter(Protocol):
    async def health(self) -> bool: ...
    async def place_order(self, request: OrderRequest) -> OrderResult: ...
    async def cancel_order(self, order_id: str) -> OrderResult: ...
    async def get_orders(self) -> list[dict]: ...
    async def get_positions(self) -> list[dict]: ...
