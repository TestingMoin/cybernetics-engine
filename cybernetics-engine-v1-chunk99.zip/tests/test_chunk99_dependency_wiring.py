import pytest

from cybernetics.config.settings import DeploymentConfig
from cybernetics.runtime.dependencies import (
    DependencyWiringError,
    REQUIRED_RUNTIME_DEPENDENCIES,
    RuntimeDependencyBundle,
)
from cybernetics.runtime.production import RuntimeDependencyState, build_production_runtime
from cybernetics.runtime.state import ControlState


class Ready:
    def __init__(self, value=True):
        self.value = value


def probes(default=True):
    return {name: (lambda obj, _default=default: bool(obj.value)) for name in REQUIRED_RUNTIME_DEPENDENCIES}


def bundle(default=True):
    r = probes(default)
    return RuntimeDependencyBundle.from_components(
        persistence=Ready(default), recovery=Ready(default), market_data=Ready(default),
        scanners=Ready(default), watchdog=Ready(default), control=Ready(default), broker=Ready(default),
        readiness=r,
    )


def test_bundle_requires_all_probes():
    with pytest.raises(DependencyWiringError, match="missing_readiness_probes"):
        RuntimeDependencyBundle.from_components(
            persistence=object(), recovery=object(), market_data=object(),
            scanners=object(), watchdog=object(), control=object(), broker=object(), readiness={},
        )


def test_bundle_requires_non_null_components():
    r = probes()
    with pytest.raises(DependencyWiringError, match="missing_runtime_dependencies"):
        RuntimeDependencyBundle.from_components(
            persistence=None, recovery=object(), market_data=object(),
            scanners=object(), watchdog=object(), control=object(), broker=object(), readiness=r,
        )


def test_dependency_readiness_projects_into_runtime_state():
    state = RuntimeDependencyState(
        engine_running=True,
        control_state=ControlState.RUNNING,
        recovery_clear=True,
        orders_reconciled=True,
        positions_reconciled=True,
        live_authorization_valid=False,
    )
    app = build_production_runtime(DeploymentConfig(), dependency_state=state, dependencies=bundle(True))
    snap = app.snapshot()
    assert snap.readiness.engine_ready is True
    assert snap.readiness.new_trades_allowed is False
    assert "live_authorization_invalid" in snap.readiness.reasons


def test_one_unready_dependency_blocks_engine_readiness():
    r = probes(True)
    r["market_data"] = lambda obj: False
    deps = RuntimeDependencyBundle.from_components(
        persistence=Ready(), recovery=Ready(), market_data=Ready(),
        scanners=Ready(), watchdog=Ready(), control=Ready(), broker=Ready(), readiness=r,
    )
    state = RuntimeDependencyState(
        engine_running=True,
        control_state=ControlState.RUNNING,
        recovery_clear=True,
        orders_reconciled=True,
        positions_reconciled=True,
    )
    app = build_production_runtime(DeploymentConfig(), dependency_state=state, dependencies=deps)
    snap = app.snapshot()
    assert snap.readiness.engine_ready is False
    assert "market_data_not_ready" in snap.readiness.reasons


def test_dependency_probe_exception_is_audit_finding():
    r = probes(True)
    def bad(_):
        raise RuntimeError("boom")
    r["broker"] = bad
    deps = RuntimeDependencyBundle.from_components(
        persistence=Ready(), recovery=Ready(), market_data=Ready(),
        scanners=Ready(), watchdog=Ready(), control=Ready(), broker=Ready(), readiness=r,
    )
    findings = deps.audit()
    assert "broker:readiness_probe_error:RuntimeError" in findings
