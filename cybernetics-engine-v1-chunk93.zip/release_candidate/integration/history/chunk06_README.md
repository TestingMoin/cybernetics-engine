# Cybernetics Trading Engine — Chunk 6

Option-chain request coordinator, expiry resolver, TTL cache, in-flight deduplication, response normalization, and ATM/nearby strike selection.

## Safety
This chunk is read-only analytics/data infrastructure. It contains no order-placement logic and does not enable live trading.

## Dhan mapping
The coordinator is designed around Dhan V2's `/optionchain/expirylist` and `/optionchain` endpoints. Dhan documents a one-unique-request-per-3-seconds limit for Option Chain requests. The coordinator therefore deduplicates identical requests and gates each logical request key.

## Scope
- Active-expiry discovery and caching
- Nearest-expiry resolution
- Per-underlying/expiry request keys
- Short TTL chain cache
- Concurrent duplicate request collapse
- Conservative normalization (no fabricated values)
- ATM and nearby strike selection

## Not included yet
- Live strategy signals
- Broker order placement
- Position/risk decisions
- Automatic contract ranking
- Iceberg scoring
