from datetime import datetime,timedelta,timezone
from cybernetics.feed_supervisor.sharder import FeedSharder
from cybernetics.feed_supervisor.health import FeedHealthMonitor,FeedHealthState
from cybernetics.feed_supervisor.supervisor import FeedSupervisor
from cybernetics.websocket.subscriptions import Instrument,SubscriptionMode

def inst(n):
    return [Instrument("NSE_FNO",str(i)) for i in range(n)]

def test_5100_instruments_split_into_two_shards():
    shards=FeedSharder().shard(inst(5100))
    assert len(shards)==2
    assert [len(x.instruments) for x in shards]==[2550,2550]

def test_capacity_above_25000_is_rejected():
    try:
        FeedSharder().shard(inst(25001))
        assert False
    except ValueError as e:
        assert str(e)=="universe_exceeds_feed_capacity"

def test_assignment_is_deterministic():
    s=FeedSharder(max_connections=3,per_connection_limit=4)
    a=s.shard(inst(9))
    b=s.shard(inst(9))
    assert a==b

def test_shard_diff_identifies_added_removed():
    s=FeedSharder(max_connections=2,per_connection_limit=10)
    old=s.shard(inst(3))
    new=s.shard(inst(4))
    d=s.diff(old,new)
    assert Instrument("NSE_FNO","3") in d["added"]

def test_stale_feed_is_detected():
    m=FeedHealthMonitor(stale_after=timedelta(seconds=10))
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    m.connected(1,t)
    m.received(1,t)
    states=m.evaluate(t+timedelta(seconds=11))
    assert states[1]==FeedHealthState.STALE

def test_disconnect_is_unhealthy():
    m=FeedHealthMonitor()
    m.connected(1)
    m.disconnected(1,"socket_closed")
    assert 1 in m.unhealthy()

def test_message_recovery_returns_healthy():
    m=FeedHealthMonitor()
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    m.connected(1,t)
    m.received(1,t)
    assert m.evaluate(t+timedelta(seconds=1))[1]==FeedHealthState.HEALTHY

def test_supervisor_blocks_when_shard_not_healthy():
    s=FeedSupervisor(FeedSharder(max_connections=2,per_connection_limit=10))
    s.assign(inst(12),SubscriptionMode.FULL)
    assert s.safe_for_market_state() is False
    for shard in s.assignment.shards:
        t=datetime.now(timezone.utc)
        s.health.connected(shard.shard_id,t)
        s.health.received(shard.shard_id,t)
    assert s.safe_for_market_state() is True

def test_supervisor_generation_increments_on_universe_change():
    s=FeedSupervisor()
    a=s.assign(inst(2))
    b=s.assign(inst(3))
    assert b.generation==a.generation+1
