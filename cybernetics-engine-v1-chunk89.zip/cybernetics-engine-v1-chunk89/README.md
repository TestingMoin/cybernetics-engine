# Cybernetics Trading Engine — Chunk 89

## Dhan Payload Interface Reconciliation

Canonical module:
`cybernetics.dhan.payload`

Canonical source:
Chunk 56.

The mapper is a serialization/validation boundary only. It does not submit
orders and does not accept access tokens.

Validation includes Dhan field constraints, correlation handling, order type,
quantity and transaction validation.
