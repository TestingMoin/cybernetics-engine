# Cybernetics Trading Engine — Chunk 16

Auditable Order Lifecycle + Append-Only Ledger.

States:
NEW -> PENDING -> PARTIAL -> FILLED
                     -> CANCEL_REQUESTED -> CANCELLED
                     -> REJECTED
                     -> EXPIRED

Replacement orders carry a parent_order_id for traceability.
No broker API is called; live trading remains OFF.
