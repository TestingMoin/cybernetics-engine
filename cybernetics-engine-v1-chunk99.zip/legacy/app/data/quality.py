from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from statistics import median

from app.marketdata.normalize import NormalizedTick


@dataclass(frozen=True, slots=True)
class QualityResult:
    accepted: bool
    score: float
    reasons: tuple[str, ...]


class MarketDataQualityEngine:
    """Conservative quality gate. It never fills missing values by inference."""

    def __init__(self, max_tick_age_seconds: float = 5.0, future_tolerance_seconds: float = 10.0) -> None:
        self.max_tick_age_seconds = max_tick_age_seconds
        self.future_tolerance_seconds = future_tolerance_seconds
        self._latencies: list[float] = []

    def assess(self, tick: NormalizedTick, now: datetime | None = None) -> QualityResult:
        now = now or datetime.now(timezone.utc)
        reasons: list[str] = list(tick.quality_reasons)
        observed_age = max(0.0, (now - tick.observed_at).total_seconds())
        if observed_age > self.max_tick_age_seconds:
            reasons.append("stale_observation")
        if tick.trade_at is not None:
            delta = (tick.trade_at - now).total_seconds()
            if delta > self.future_tolerance_seconds:
                reasons.append("trade_time_future")
            self._latencies.append(abs(delta))
            if len(self._latencies) > 200:
                self._latencies.pop(0)
        if tick.price is None:
            reasons.append("missing_price")
        if tick.best_bid is not None and tick.best_bid <= 0:
            reasons.append("invalid_bid")
        if tick.best_ask is not None and tick.best_ask <= 0:
            reasons.append("invalid_ask")
        if tick.best_bid is not None and tick.best_ask is not None and tick.best_bid > tick.best_ask:
            reasons.append("crossed_book")

        unique = tuple(dict.fromkeys(reasons))
        hard_reject = {"non_positive_price", "invalid_day_range", "crossed_best_bid_ask", "trade_timestamp_in_future",
                       "crossed_book", "invalid_bid", "invalid_ask", "missing_price"}
        accepted = not bool(hard_reject.intersection(unique))
        score = max(0.0, 1.0 - min(1.0, len(unique) * 0.15))
        return QualityResult(accepted, score, unique)

    def median_timestamp_delta(self) -> float | None:
        return median(self._latencies) if self._latencies else None
