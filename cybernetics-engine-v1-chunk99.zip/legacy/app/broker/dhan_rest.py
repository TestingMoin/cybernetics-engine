from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

from app.auth.dhan_auth import DhanTokenManager
from app.rate_limit.governor import DhanApiClass, RateLimitGovernor

logger = logging.getLogger(__name__)
BASE_URL = "https://api.dhan.co/v2"


class DhanApiError(RuntimeError):
    pass


class DhanRestClient:
    """Async Dhan V2 REST transport. Read-only by default; order writes are deliberately excluded in Chunk 3."""

    def __init__(
        self,
        client_id: str,
        token_manager: DhanTokenManager | None = None,
        access_token: str = "",
        *,
        governor: RateLimitGovernor | None = None,
        base_url: str = BASE_URL,
        timeout_seconds: float = 15.0,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        if not client_id:
            raise ValueError("Dhan client_id is required")
        if not token_manager and not access_token:
            raise ValueError("Provide token_manager or access_token")
        self.client_id = client_id
        self._token_manager = token_manager
        self._static_token = access_token
        self._governor = governor or RateLimitGovernor()
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout_seconds
        self._http = http_client
        self._owns_http = http_client is None

    async def __aenter__(self) -> "DhanRestClient":
        if self._http is None:
            self._http = httpx.AsyncClient(timeout=self._timeout)
            self._owns_http = True
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._http is not None and self._owns_http:
            await self._http.aclose()
        self._http = None

    async def _token(self) -> str:
        if self._token_manager:
            return await self._token_manager.get_valid_token()
        if not self._static_token:
            raise DhanApiError("No Dhan access token available")
        return self._static_token

    async def _request(
        self,
        method: str,
        path: str,
        *,
        api_class: DhanApiClass,
        json: dict[str, Any] | None = None,
        retry_auth: bool = True,
    ) -> Any:
        await self._governor.acquire(api_class)
        if self._http is None:
            self._http = httpx.AsyncClient(timeout=self._timeout)
            self._owns_http = True
        token = await self._token()
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "access-token": token,
            "client-id": self.client_id,
        }
        try:
            response = await self._http.request(method, f"{self._base_url}{path}", headers=headers, json=json)
        except httpx.HTTPError as exc:
            raise DhanApiError(f"Dhan transport error: {type(exc).__name__}") from exc

        if response.status_code == 401 and retry_auth and self._token_manager:
            # Clear local token and obtain a new one, then retry once.
            await self._token_manager.clear()
            return await self._request(method, path, api_class=api_class, json=json, retry_auth=False)

        if response.is_error:
            detail: str
            try:
                payload = response.json()
                detail = str(payload.get("remarks") or payload.get("message") or payload)
            except ValueError:
                detail = response.text[:500]
            raise DhanApiError(f"Dhan HTTP {response.status_code}: {detail}")

        if not response.content:
            return None
        try:
            return response.json()
        except ValueError as exc:
            raise DhanApiError("Dhan returned non-JSON response") from exc

    async def get_holdings(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/holdings", api_class=DhanApiClass.NON_TRADING)

    async def get_positions(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/positions", api_class=DhanApiClass.NON_TRADING)

    async def get_orders(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/orders", api_class=DhanApiClass.NON_TRADING)

    async def get_trades(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/trades", api_class=DhanApiClass.NON_TRADING)

    async def get_ltp(self, payload: dict[str, list[int]]) -> dict[str, Any]:
        return await self._request("POST", "/marketfeed/ltp", api_class=DhanApiClass.QUOTE, json=payload)

    async def get_ohlc(self, payload: dict[str, list[int]]) -> dict[str, Any]:
        return await self._request("POST", "/marketfeed/ohlc", api_class=DhanApiClass.QUOTE, json=payload)

    async def get_quote(self, payload: dict[str, list[int]]) -> dict[str, Any]:
        return await self._request("POST", "/marketfeed/quote", api_class=DhanApiClass.QUOTE, json=payload)

    async def get_option_chain(self, underlying_scrip: int, underlying_segment: str) -> dict[str, Any]:
        payload = {"UnderlyingScrip": int(underlying_scrip), "UnderlyingSeg": underlying_segment}
        return await self._request("POST", "/optionchain", api_class=DhanApiClass.DATA, json=payload)

    async def get_option_expiry_list(self, underlying_scrip: int, underlying_segment: str) -> dict[str, Any]:
        payload = {"UnderlyingScrip": int(underlying_scrip), "UnderlyingSeg": underlying_segment}
        return await self._request("POST", "/optionchain/expirylist", api_class=DhanApiClass.DATA, json=payload)

    async def get_profile(self) -> dict[str, Any]:
        # Profile endpoint is useful for connectivity validation; path can be changed centrally if Dhan revises it.
        return await self._request("GET", "/profile", api_class=DhanApiClass.NON_TRADING)
