from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Optional
from cybernetics.dhan.response import DhanOrderResponse, DhanOrderStatus

class LedgerOrderState(str,Enum):
    NEW="NEW"; PENDING="PENDING"; PARTIAL="PARTIAL"; FILLED="FILLED"
    REJECTED="REJECTED"; CANCELLED="CANCELLED"; EXPIRED="EXPIRED"; UNKNOWN="UNKNOWN"

@dataclass(frozen=True)
class NormalizedOrderEvent:
    order_id:str
    correlation_id:Optional[str]
    state:LedgerOrderState
    filled_quantity:int
    remaining_quantity:Optional[int]
    average_traded_price:Optional[float]
    terminal:bool
    reason:str

class BrokerResponseLifecycleBinder:
    """
    Maps Dhan status to the engine's normalized order lifecycle.

    It does not mutate a database or Position Manager. Durable application is
    left to the existing Order Manager/Ledger boundaries.
    """
    def bind(self,r:DhanOrderResponse)->NormalizedOrderEvent:
        mapping={
            DhanOrderStatus.TRANSIT:(LedgerOrderState.PENDING,False,"broker_transit"),
            DhanOrderStatus.PENDING:(LedgerOrderState.PENDING,False,"broker_pending"),
            DhanOrderStatus.PART_TRADED:(LedgerOrderState.PARTIAL,False,"broker_partial_fill"),
            DhanOrderStatus.TRADED:(LedgerOrderState.FILLED,True,"broker_filled"),
            DhanOrderStatus.REJECTED:(LedgerOrderState.REJECTED,True,"broker_rejected"),
            DhanOrderStatus.CANCELLED:(LedgerOrderState.CANCELLED,True,"broker_cancelled"),
            DhanOrderStatus.EXPIRED:(LedgerOrderState.EXPIRED,True,"broker_expired"),
            DhanOrderStatus.CLOSED:(LedgerOrderState.FILLED,True,"broker_closed"),
            DhanOrderStatus.TRIGGERED:(LedgerOrderState.PENDING,False,"broker_triggered"),
            DhanOrderStatus.UNKNOWN:(LedgerOrderState.UNKNOWN,False,"broker_status_unknown"),
        }
        state,terminal,reason=mapping[r.status]
        if r.filled_quantity<0:
            raise ValueError("filled_quantity_invalid")
        return NormalizedOrderEvent(r.order_id,r.correlation_id,state,
            r.filled_quantity,r.remaining_quantity,r.average_traded_price,terminal,reason)
