# Cybernetics Trading Engine — Chunk 62

## Broker Position Reconciliation → Position Manager

Dhan's current V2 `GET /positions` returns open positions, including F&O
carry-forward positions, with `securityId`, `exchangeSegment`, `positionType`,
`buyAvg`, `sellAvg`, `costPrice`, `netQty`, realized/unrealized P&L and derivative
contract fields. citeturn420350search0

This chunk adds a broker-vs-internal reconciliation boundary.

The comparison checks:
- instrument identity
- quantity
- long/short/flat side
- average entry / cost basis within an explicit tolerance

Outcomes:
- CONSISTENT
- MISMATCH
- BROKER_ONLY
- INTERNAL_ONLY
- INVALID

Only `CONSISTENT` permits a new trade through the reconciliation trading gate.
Any discrepancy blocks new entries until the existing recovery/reconciliation
workflow resolves it.

This chunk does not overwrite internal state from the broker snapshot, and it
does not place/cancel orders. The broker snapshot is evidence for reconciliation;
the Position Manager remains a separate mutation boundary.
