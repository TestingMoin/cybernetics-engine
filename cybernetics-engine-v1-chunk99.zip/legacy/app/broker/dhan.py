from __future__ import annotations

from typing import Any

from app.auth.dhan_auth import DhanTokenManager
from app.broker.dhan_rest import DhanRestClient
from app.broker.interface import BrokerAdapter, OrderRequest, OrderResult
from app.rate_limit.governor import RateLimitGovernor


class DhanV2BrokerAdapter:
    """Single broker boundary used by the rest of the engine.

    Chunk 3 intentionally implements account/read-data methods only. Live order
    placement is still blocked until execution, risk and reconciliation gates are complete.
    """

    def __init__(
        self,
        client_id: str,
        *,
        token_manager: DhanTokenManager | None = None,
        access_token: str = "",
        governor: RateLimitGovernor | None = None,
        base_url: str = "https://api.dhan.co/v2",
    ) -> None:
        self.client_id = client_id
        self.rest = DhanRestClient(
            client_id,
            token_manager=token_manager,
            access_token=access_token,
            governor=governor,
            base_url=base_url,
        )

    async def health(self) -> bool:
        try:
            payload = await self.rest.get_profile()
            return isinstance(payload, dict)
        except Exception:
            return False

    async def account_snapshot(self) -> dict[str, Any]:
        holdings, positions, orders, trades = await self._parallel(
            self.rest.get_holdings(), self.rest.get_positions(), self.rest.get_orders(), self.rest.get_trades()
        )
        return {"holdings": holdings, "positions": positions, "orders": orders, "trades": trades}

    async def place_order(self, request: OrderRequest) -> OrderResult:
        raise RuntimeError("LIVE order transport is deliberately disabled in Chunk 3")

    async def cancel_order(self, order_id: str) -> OrderResult:
        raise RuntimeError("LIVE order transport is deliberately disabled in Chunk 3")

    async def get_orders(self) -> list[dict]:
        return await self.rest.get_orders()

    async def get_positions(self) -> list[dict]:
        return await self.rest.get_positions()

    async def _parallel(self, *coros):
        import asyncio
        return await asyncio.gather(*coros)

    async def close(self) -> None:
        await self.rest.close()
