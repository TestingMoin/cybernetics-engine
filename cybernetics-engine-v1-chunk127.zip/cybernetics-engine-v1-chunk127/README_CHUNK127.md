# Chunk 127 — Hostinger Staging Deployment + Evidence Capture

Adds an operator-controlled, staging-only remote deployment wrapper. It transfers a release and checksum, verifies the remote checksum, enforces staging/paper/order-disabled configuration, runs the host preflight and installer, verifies systemd and captures evidence, then requires `new_trades_allowed` to remain false.

It requires `CYBERNETICS_STAGING_CONFIRM=INSTALL_STAGING_ONLY` and does not handle Dhan credentials.
