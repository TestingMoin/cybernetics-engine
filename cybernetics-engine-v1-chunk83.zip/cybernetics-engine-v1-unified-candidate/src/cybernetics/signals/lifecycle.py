from enum import Enum
class SignalLifecycleState(str,Enum): OBSERVED="OBSERVED";ACTIVE="ACTIVE";EXPIRED="EXPIRED"
class SignalLifecycleManager:
 def __init__(self,now):self.now=now;self.s=set()
 def register(self,s,**kw):self.s.add(s)
 def evaluate(self,s,at=None):return type("E",(),{"state":SignalLifecycleState.OBSERVED})()
