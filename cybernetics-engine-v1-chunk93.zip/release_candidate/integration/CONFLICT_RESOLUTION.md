# Chunk 83 — Canonical Source Merge Decisions

The candidate repository is the first physical merge of the actual source
directories from Chunks 2–81.

Rules:
- identical files are deduplicated;
- conflicting logical paths are recorded in `MERGE_MANIFEST.json`;
- highest available chunk is the provisional selection;
- early `app/` code remains under `legacy/`;
- historical README/build files remain under `integration/history/`;
- production dependencies are not blindly inherited from the early scaffold;
- secrets are never copied.

This merge is provisional until repository-wide integration testing passes.
