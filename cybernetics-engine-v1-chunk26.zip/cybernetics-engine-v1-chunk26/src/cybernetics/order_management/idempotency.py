from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Protocol

@dataclass(frozen=True)
class IdempotencyRecord:
    client_order_key: str
    broker_order_id: Optional[str]
    status: str

class IdempotencyBackend(Protocol):
    def get(self, key: str) -> Optional[IdempotencyRecord]: ...
    def put_once(self, record: IdempotencyRecord) -> bool: ...
    def update(self, record: IdempotencyRecord) -> None: ...

class IdempotencyStore:
    """Backend-neutral idempotency facade; persistent DB backend can be injected."""
    def __init__(self, backend: IdempotencyBackend):
        self._backend = backend

    def get(self, key: str) -> Optional[IdempotencyRecord]:
        return self._backend.get(key)

    def put_once(self, record: IdempotencyRecord) -> bool:
        return self._backend.put_once(record)

    def update(self, record: IdempotencyRecord) -> None:
        self._backend.update(record)
