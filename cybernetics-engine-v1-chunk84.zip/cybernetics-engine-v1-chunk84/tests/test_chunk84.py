import pytest

from cybernetics.integration.interface_compat import (
    DECISIONS, InterfaceCompatibilityError,
    normalize_public_mapping, is_conflict_resolved
)
from cybernetics.integration.reconciliation import (
    HIGH_IMPACT_INTERFACES, InterfaceReconciler,
    ReconciliationStatus
)


def test_five_high_impact_interfaces_are_registered():
    assert len(HIGH_IMPACT_INTERFACES)==5
    assert {d.interface for d in DECISIONS}==set(HIGH_IMPACT_INTERFACES)


def test_missing_required_mapping_field_is_rejected():
    with pytest.raises(InterfaceCompatibilityError,match="required_fields_missing"):
        normalize_public_mapping({"x":1},required=("x","y"))


def test_non_mapping_is_rejected():
    with pytest.raises(InterfaceCompatibilityError,match="mapping_required"):
        normalize_public_mapping(["x"],required=("x",))


def test_valid_mapping_passes():
    v=normalize_public_mapping({"x":1,"y":2},required=("x","y"))
    assert v["x"]==1


def test_unresolved_interface_is_false():
    assert not is_conflict_resolved("websocket.subscriptions",set())


def test_resolved_interface_is_true():
    assert is_conflict_resolved("websocket.subscriptions",{"websocket.subscriptions"})


def test_reconciler_blocks_with_no_evidence():
    r=InterfaceReconciler(HIGH_IMPACT_INTERFACES).report({})
    assert r.status is ReconciliationStatus.BLOCKED
    assert len(r.blocked)==5


def test_reconciler_resolves_with_evidence_for_all():
    evidence={name:(f"validated:{name}",) for name in HIGH_IMPACT_INTERFACES}
    r=InterfaceReconciler(HIGH_IMPACT_INTERFACES).report(evidence)
    assert r.status is ReconciliationStatus.RESOLVED
    assert r.blocked==()


def test_partial_resolution_remains_blocked():
    evidence={HIGH_IMPACT_INTERFACES[0]:("caller inspection",)}
    r=InterfaceReconciler(HIGH_IMPACT_INTERFACES).report(evidence)
    assert len(r.resolved)==1
    assert len(r.blocked)==4
    assert r.status is ReconciliationStatus.BLOCKED


def test_duplicate_required_interfaces_are_deduplicated():
    names=[HIGH_IMPACT_INTERFACES[0],HIGH_IMPACT_INTERFACES[0]]
    r=InterfaceReconciler(names)
    assert r.required==(HIGH_IMPACT_INTERFACES[0],)


def test_findings_are_blocking_until_evidenced():
    r=InterfaceReconciler(HIGH_IMPACT_INTERFACES).report({})
    assert all(f.blocking for f in r.findings)


def test_findings_include_evidence_after_resolution():
    name=HIGH_IMPACT_INTERFACES[0]
    r=InterfaceReconciler(HIGH_IMPACT_INTERFACES).report(
        {name:("selected canonical signature",)}
    )
    finding=next(f for f in r.findings if f.interface==name)
    assert not finding.blocking
    assert finding.evidence==("selected canonical signature",)


def test_decisions_are_explicitly_non_automatic():
    assert all(
        d.action=="adapter_pending_until_runtime_validation"
        for d in DECISIONS
    )


def test_newer_chunk_is_not_treated_as_automatic_resolution():
    r=InterfaceReconciler(HIGH_IMPACT_INTERFACES).report(
        {HIGH_IMPACT_INTERFACES[0]:("Chunk 81 exists",)}
    )
    assert r.resolved==(HIGH_IMPACT_INTERFACES[0],)
    # Evidence can be recorded, but this package never performs the semantic merge.


def test_no_broker_endpoint():
    from pathlib import Path
    for p in Path("src/cybernetics/integration").glob("*.py"):
        src=p.read_text()
        for token in ("/v2/orders","place_order","submit_order","cancel_order","replace_order"):
            assert token not in src


def test_no_live_authorization():
    from pathlib import Path
    for p in Path("src/cybernetics/integration").glob("*.py"):
        assert "approve_live" not in p.read_text()


def test_reconciliation_report_is_immutable():
    r=InterfaceReconciler(HIGH_IMPACT_INTERFACES).report({})
    assert isinstance(r.blocked,tuple)
