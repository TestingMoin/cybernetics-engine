# Cybernetics Trading Engine — Chunk 73

## Unified Runtime State & Safe Startup Composition

This chunk creates the read-only composition layer that turns existing
subsystem conditions into one deterministic runtime snapshot.

Inputs include:

- engine mode
- control state
- persistence readiness
- recovery status
- order reconciliation
- position reconciliation
- market-data readiness
- scanner health
- watchdog health
- live authorization
- broker availability

Two outputs are kept separate:

1. `engine_ready`
2. `new_trades_allowed`

Emergency stop and STOP_NEW_TRADES prevent new entries without pretending that
the underlying runtime state is otherwise healthy.

The composer does not mutate subsystem state, authorize live trading, or call
broker order endpoints.

This chunk is an integration/composition boundary, not yet the final process
entrypoint or production service wiring.
