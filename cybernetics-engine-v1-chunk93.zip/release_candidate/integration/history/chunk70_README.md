# Cybernetics Trading Engine — Chunk 70

## Durable Outbox Dispatcher & Recovery Worker

This chunk adds the worker boundary for the PostgreSQL `fill_outbox`.

Flow:

PENDING -> PROCESSING -> COMPLETED
                     \-> FAILED

Key controls:
- bounded batch claiming with PostgreSQL `FOR UPDATE SKIP LOCKED`
- attempts incremented at claim time
- configurable maximum attempts
- stale `PROCESSING` recovery back to `PENDING`
- explicit durable FAILED state
- completion confirmation
- completion-unknown classification rather than blind retry
- pending-count visibility

The worker provides at-least-once-style delivery semantics. Handler side effects
must therefore be idempotent.

Important: FAILED is deliberately not silently requeued by this worker. A
separate recovery policy can inspect and requeue failed events after review or
a controlled retry decision.

No broker execution is performed by this chunk.
