# Cybernetics Trading Engine — Chunk 95

## Canonical PostgreSQL Schema + Order Idempotency Boundary

Chunk 95 resolves the persistence blockers identified by the release-candidate architecture audit.

### Implemented
- One authoritative PostgreSQL schema source: `sql/schema.sql`.
- Full durable schema baseline includes orders, order idempotency, fill ledger/outbox, control command audit, and emergency control state.
- `orders` now has the full trade-order fields plus `client_order_key` and `broker_order_id`.
- New `order_idempotency` table owns client-order exactly-once/idempotency records.
- `PostgresOrderLedger` now reads/writes `order_idempotency` rather than creating malformed partial `orders` rows.
- Inline table DDL was removed from runtime modules.
- Canonical migration baseline is exposed through `AUTHORITATIVE_MIGRATIONS`.
- Legacy migration/DDL APIs remain only for backward compatibility and derive compatibility SQL from the canonical schema.

### Regression gate
- 802 / 802 tests pass.
- No strategy/risk direct order HTTP path.
- No inline persistent DDL remains in Python runtime modules.

This is still a release-candidate source artifact. It was not deployed to the Hostinger VPS, did not connect to production PostgreSQL, and did not submit any Dhan order.
