# Chunk 82 — Canonical Merge Rules

## Purpose
This chunk does not overwrite or silently choose between conflicting modules.
It records the evidence needed for the real unified repository merge.

## Merge rules
1. One canonical implementation per logical module path.
2. Duplicate files with identical content may be deduplicated.
3. Duplicate files with conflicting content require explicit resolution.
4. The newest chunk number does not automatically win.
5. Interfaces are resolved by contract and dependency direction, not by file
   timestamp or convenience.
6. Existing golden strategy behavior must not be changed during the merge.
7. Broker-specific code remains behind `DhanV2BrokerAdapter` / execution
   boundaries.
8. No secrets are copied into the unified source tree.
9. No archive is treated as a production deployment artifact until integration
   tests pass.
10. The unified repository becomes the sole canonical source after this merge;
    individual chunk ZIPs remain historical build artifacts.

## Deployment gate
Chunk 82 is an audit/inventory gate only. No VPS deployment occurs here.
