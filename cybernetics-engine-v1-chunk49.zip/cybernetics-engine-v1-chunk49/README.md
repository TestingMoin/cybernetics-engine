# Cybernetics Trading Engine — Chunk 49

## Strategy → Risk / Pre-Trade Handoff

This chunk introduces the formal contract between strategy intent and the Risk
Engine.

Flow:

Strategy Decision
→ StrategyToRiskAdapter
→ StrategyRiskRequest
→ Risk Engine / Pre-Trade Gate (existing downstream layer)
→ Execution (later)

The handoff deliberately does **not** perform:
- position sizing
- margin calculation
- risk-budget allocation
- broker mapping
- order submission
- execution
- live authorization

The strategy may provide reference prices for entry/stop/target when available,
but Risk remains responsible for validating the risk model and calculating the
actual tradable quantity.

`HOLD` and `NO_ACTION` are not executable risk requests.

This is a boundary chunk; it is not yet the final integrated repository.
