from pathlib import Path

ROOT = Path(__file__).parents[1]


def test_installer_refuses_missing_staging_environment():
    text = (ROOT / "deploy/scripts/install_staging.sh").read_text()
    assert 'staging environment file missing' in text
    assert 'CYBERNETICS_TRADING_MODE=paper' in text
    assert 'CYBERNETICS_ORDER_SUBMISSION_ENABLED=false' in text


def test_installer_never_overwrites_environment_file():
    text = (ROOT / "deploy/scripts/install_staging.sh").read_text()
    assert 'never overwrite' in text.lower()
    assert 'systemctl daemon-reload' in text


def test_installer_preserves_rollback_release():
    text = (ROOT / "deploy/scripts/install_staging.sh").read_text()
    assert 'current.previous' in text
    assert 'mv "$CURRENT" "$PREVIOUS"' in text


def test_verifier_checks_paper_safe_environment():
    text = (ROOT / "deploy/scripts/verify_staging.sh").read_text()
    assert 'CYBERNETICS_ENV=staging' in text
    assert 'CYBERNETICS_TRADING_MODE=paper' in text
    assert 'CYBERNETICS_ORDER_SUBMISSION_ENABLED=false' in text
    assert 'new_trades_allowed"] is False' in text
