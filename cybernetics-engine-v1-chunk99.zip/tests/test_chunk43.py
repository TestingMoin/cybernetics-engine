from datetime import datetime, timezone
from cybernetics.signals.registry import SignalRegistry, SignalRecord
from cybernetics.integration.pipeline import MarketToSignalPipeline

class Key:
    def __init__(self):
        self.underlying_key="NIFTY"; self.timeframe="1m"

class Runtime:
    def __init__(self):
        self.state_data={}; self.signal_count=0
    def update(self,**kw):
        self.signal_count += kw.get("signal_delta",0)

class Runtimes:
    def __init__(self,k): self.k=k; self.r=Runtime()
    def get(self,k): return self.r

class Router:
    def __init__(self,k,ok=True): self.k=k; self.ok=ok
    def route(self,event):
        return type("D",(),{"delivered":self.ok,"reason":"event_delivered" if self.ok else "no_route","runtime_key":self.k})()

class Adapter:
    def runtime(self,security_id,timeframe):
        return type("S",(),{})()
    def process(self,state,**kw):
        return type("Snap",(),{"values":{"EMA":kw["close"]},"ready":("EMA",)})()

class Event:
    def __init__(self,payload): 
        self.payload=payload; self.timestamp=datetime(2026,1,1,tzinfo=timezone.utc)

def pipeline(factory=None, ok=True):
    k=Key()
    reg=SignalRegistry()
    return MarketToSignalPipeline(Router(k,ok),Runtimes(k),Adapter(),reg,factory),reg

def test_market_event_reaches_indicator_boundary():
    p,s=pipeline()
    out=p.process(Event({"high":101,"low":99,"close":100,"volume":10}))
    assert out.delivered and out.indicators_processed
    assert out.signal_registered is False

def test_missing_ohlcv_blocks_indicator_processing():
    p,s=pipeline()
    out=p.process(Event({"close":100}))
    assert out.indicators_processed is False
    assert s.list()==[]

def test_signal_factory_registers_signal_only():
    def factory(event,key,values):
        return SignalRecord("SIG1","ICE-NIFTY",key.underlying_key,key.timeframe,
                            event.timestamp,"TEST","BUY",0.9,{"EMA":values["EMA"]})
    p,s=pipeline(factory)
    out=p.process(Event({"high":101,"low":99,"close":100,"volume":10}))
    assert out.signal_registered
    assert s.get("SIG1").direction=="BUY"

def test_no_signal_factory_does_not_create_signal():
    p,s=pipeline()
    out=p.process(Event({"high":101,"low":99,"close":100}))
    assert not out.signal_registered and s.list()==[]

def test_unrouted_event_is_stopped_before_indicator():
    p,s=pipeline(ok=False)
    out=p.process(Event({"high":101,"low":99,"close":100}))
    assert out.delivered is False
    assert s.list()==[]

def test_signal_registry_rejects_duplicate_ids():
    s=SignalRegistry()
    sig=SignalRecord("S1","SC","U","1m",datetime.now(timezone.utc),"X","BUY",0.5)
    s.register(sig)
    try:
        s.register(sig); assert False
    except ValueError as e:
        assert str(e)=="duplicate_signal_id"
