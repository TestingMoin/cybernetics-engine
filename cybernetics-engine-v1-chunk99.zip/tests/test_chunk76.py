from cybernetics.control.repository import (
    CommandAuditRecord, CommandRecordState, ControlCommandRepository
)
from cybernetics.control.migration import CONTROL_MIGRATION
from cybernetics.control.durable_store import PostgresCommandIdStore, PostgresAuditSink


class Result:
    def __init__(self, rowcount=1):
        self.rowcount = rowcount


class FakeTx:
    def __init__(self, fetchones=None, rowcount=1):
        self.fetchones=list(fetchones or [])
        self.rowcount=rowcount
        self.calls=[]
    def fetchone(self, sql, params=()):
        self.calls.append(("fetchone",sql,params))
        return self.fetchones.pop(0) if self.fetchones else None
    def execute(self, sql, params=()):
        self.calls.append(("execute",sql,params))
        return Result(self.rowcount)


def record(cid="C1", result=CommandRecordState.ACCEPTED):
    return CommandAuditRecord(
        command_id=cid,
        command="STOP_NEW_TRADES",
        source="PWA",
        result=result,
        state="STOP_NEW_TRADES",
        reason="command_applied",
        issued_at=1000.0,
    )


def test_migration_version_is_next():
    assert CONTROL_MIGRATION.version == 4
    assert "control_command_audit" in CONTROL_MIGRATION.sql


def test_migration_has_command_primary_key():
    assert "command_id TEXT PRIMARY KEY" in CONTROL_MIGRATION.sql


def test_migration_has_indexes():
    assert "idx_control_command_audit_issued_at" in CONTROL_MIGRATION.sql
    assert "idx_control_command_audit_source" in CONTROL_MIGRATION.sql
    assert "idx_control_command_audit_result" in CONTROL_MIGRATION.sql


def test_ensure_command_first_writer_wins():
    tx=FakeTx(fetchones=[("C1",)])
    assert ControlCommandRepository(tx).ensure_command_record(record())
    assert "ON CONFLICT (command_id) DO NOTHING" in tx.calls[0][1]


def test_ensure_command_duplicate_returns_false():
    tx=FakeTx(fetchones=[None])
    assert not ControlCommandRepository(tx).ensure_command_record(record())


def test_command_seen_true():
    tx=FakeTx(fetchones=[("C1",)])
    assert ControlCommandRepository(tx).command_seen("C1")


def test_command_seen_false():
    tx=FakeTx(fetchones=[None])
    assert not ControlCommandRepository(tx).command_seen("C1")


def test_record_result_updates_existing_command():
    tx=FakeTx(rowcount=1)
    assert ControlCommandRepository(tx).record_result(record())
    assert "WHERE command_id=%s" in tx.calls[0][1]


def test_record_result_failure_is_false():
    tx=FakeTx(rowcount=0)
    assert not ControlCommandRepository(tx).record_result(record())


def test_issued_at_is_parameterized():
    tx=FakeTx(fetchones=[("C1",)])
    ControlCommandRepository(tx).ensure_command_record(record())
    assert 1000.0 in tx.calls[0][2]


def test_source_is_parameterized():
    tx=FakeTx(fetchones=[("C1",)])
    ControlCommandRepository(tx).ensure_command_record(record())
    assert "PWA" in tx.calls[0][2]


def test_durable_store_uses_repository_seen():
    tx=FakeTx(fetchones=[("C1",)])
    repo=ControlCommandRepository(tx)
    store=PostgresCommandIdStore(repo)
    assert store.seen("C1")


def test_durable_store_remember_creates_marker_when_missing():
    tx=FakeTx(fetchones=[("C1",)])
    repo=ControlCommandRepository(tx)
    PostgresCommandIdStore(repo).remember("C1")
    assert "command_id" in tx.calls[0][1]


def test_audit_sink_creates_first_record():
    tx=FakeTx(fetchones=[("C1",)])
    repo=ControlCommandRepository(tx)
    sink=PostgresAuditSink(repo)
    assert sink.record(**{
        "command_id":"C1","command":"STOP_NEW_TRADES","source":"PWA",
        "result":"ACCEPTED","state":"STOP_NEW_TRADES",
        "reason":"command_applied","issued_at":1000.0
    })


def test_audit_sink_updates_duplicate_record():
    tx=FakeTx(fetchones=[None], rowcount=1)
    repo=ControlCommandRepository(tx)
    sink=PostgresAuditSink(repo)
    assert sink.record(**{
        "command_id":"C1","command":"STOP_NEW_TRADES","source":"PWA",
        "result":"ACCEPTED","state":"STOP_NEW_TRADES",
        "reason":"command_applied","issued_at":1000.0
    })
    assert tx.calls[1][0]=="execute"


def test_audit_state_is_restricted_by_enum():
    tx=FakeTx()
    repo=ControlCommandRepository(tx)
    # Invalid enum would be rejected before SQL is built.
    import pytest
    with pytest.raises(ValueError):
        CommandRecordState("INVALID")


def test_no_order_endpoint_in_repository():
    from pathlib import Path
    src=Path("src/cybernetics/control/repository.py").read_text()
    for token in ("/v2/orders","place_order","submit_order","cancel_order","replace_order"):
        assert token not in src


def test_no_live_authorization_creation_in_repository():
    from pathlib import Path
    src=Path("src/cybernetics/control/repository.py").read_text()
    assert "approve(" not in src


def test_durable_command_id_is_database_backed():
    tx=FakeTx(fetchones=[("C1",)])
    repo=ControlCommandRepository(tx)
    store=PostgresCommandIdStore(repo)
    assert store.seen("C1")


def test_duplicate_boundary_is_sql_enforced():
    tx=FakeTx(fetchones=[None])
    repo=ControlCommandRepository(tx)
    repo.ensure_command_record(record())
    assert "PRIMARY KEY" not in tx.calls[0][1]
    assert "ON CONFLICT (command_id) DO NOTHING" in tx.calls[0][1]


def test_audit_keeps_result_and_reason():
    tx=FakeTx(fetchones=[("C1",)])
    repo=ControlCommandRepository(tx)
    PostgresAuditSink(repo).record(**{
        "command_id":"C1","command":"EMERGENCY_STOP","source":"TELEGRAM",
        "result":"ACCEPTED","state":"EMERGENCY_STOP",
        "reason":"command_applied","issued_at":1234
    })
    assert "EMERGENCY_STOP" in tx.calls[0][2]
    assert "command_applied" in tx.calls[0][2]
