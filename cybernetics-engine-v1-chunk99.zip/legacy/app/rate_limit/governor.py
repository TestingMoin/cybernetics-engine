from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from enum import StrEnum


class DhanApiClass(StrEnum):
    ORDER = "order"
    DATA = "data"
    QUOTE = "quote"
    NON_TRADING = "non_trading"


@dataclass(frozen=True)
class RateLimits:
    per_second: float
    per_minute: float | None = None
    per_hour: float | None = None
    per_day: float | None = None


DHAN_LIMITS = {
    DhanApiClass.ORDER: RateLimits(10, 250, 1000, 7000),
    DhanApiClass.DATA: RateLimits(5, None, None, 100000),
    DhanApiClass.QUOTE: RateLimits(1, None, None, None),
    DhanApiClass.NON_TRADING: RateLimits(20, None, None, None),
}


class RateLimitGovernor:
    """Centralized local throttling gate. Production version will add priority/cost buckets and metrics."""

    def __init__(self, limits: dict[DhanApiClass, RateLimits] | None = None) -> None:
        self._limits = limits or DHAN_LIMITS
        self._locks = {kind: asyncio.Lock() for kind in self._limits}
        self._history: dict[DhanApiClass, list[float]] = {kind: [] for kind in self._limits}

    async def acquire(self, kind: DhanApiClass) -> None:
        if kind not in self._limits:
            raise KeyError(f"Unsupported API class: {kind}")
        limits = self._limits[kind]
        async with self._locks[kind]:
            while True:
                now = time.monotonic()
                hist = self._history[kind]
                self._history[kind] = [t for t in hist if now - t < 86400]
                hist = self._history[kind]
                waits: list[float] = []
                windows = ((1, limits.per_second), (60, limits.per_minute), (3600, limits.per_hour), (86400, limits.per_day))
                allowed = True
                for window, cap in windows:
                    if cap is None:
                        continue
                    count = sum(1 for t in hist if now - t < window)
                    if count >= cap:
                        oldest = min(t for t in hist if now - t < window)
                        waits.append(window - (now - oldest))
                        allowed = False
                if allowed:
                    hist.append(now)
                    return
                await asyncio.sleep(max(0.01, min(waits)))
