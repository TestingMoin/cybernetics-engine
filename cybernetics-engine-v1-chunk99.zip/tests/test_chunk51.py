from cybernetics.risk.sizing import (
    SizingRequest, SizingDecision, PositionSizingEngine
)

E = PositionSizingEngine()

def req(**kw):
    d = dict(
        entry_price=100.0,
        stop_price=99.0,
        risk_budget=100.0,
        lot_size=10,
        contract_multiplier=1.0,
    )
    d.update(kw)
    return SizingRequest(**d)

def test_basic_risk_sizing():
    r = E.size(req())
    assert r.decision == SizingDecision.APPROVED
    assert r.quantity == 100
    assert r.lots == 10
    assert r.trade_risk == 100

def test_lot_alignment():
    r = E.size(req(risk_budget=95))
    assert r.quantity == 90
    assert r.quantity % 10 == 0
    assert r.trade_risk == 90

def test_no_forced_minimum_lot():
    r = E.size(req(risk_budget=9))
    assert r.decision == SizingDecision.REJECTED
    assert r.quantity == 0

def test_equal_entry_stop_rejected():
    r = E.size(req(stop_price=100))
    assert r.reason == "entry_and_stop_must_differ"

def test_contract_multiplier_changes_risk():
    r = E.size(req(contract_multiplier=5, risk_budget=100, lot_size=1))
    assert r.quantity == 20
    assert r.risk_per_unit == 5

def test_max_quantity_cap():
    r = E.size(req(max_quantity=35))
    assert r.quantity == 30
    assert r.lots == 3

def test_max_notional_cap_is_lot_aligned():
    r = E.size(req(risk_budget=1000, lot_size=10, max_notional=2500))
    assert r.quantity == 20
    assert r.notional == 2000

def test_margin_cap():
    r = E.size(req(
        risk_budget=1000,
        lot_size=10,
        margin_per_unit=30,
        available_margin=550
    ))
    assert r.quantity == 10
    assert r.estimated_margin == 300

def test_margin_below_one_lot_rejects():
    r = E.size(req(lot_size=10, margin_per_unit=30, available_margin=20))
    assert r.decision == SizingDecision.REJECTED

def test_zero_entry_price_rejected():
    try:
        req(entry_price=0)
        assert False
    except ValueError as exc:
        assert str(exc) == "entry_price_must_be_positive"

def test_negative_stop_price_rejected():
    try:
        req(stop_price=-1)
        assert False
    except ValueError as exc:
        assert str(exc) == "stop_price_must_be_positive"

def test_quantity_is_integer_and_lot_aligned():
    r = E.size(req(risk_budget=123.45, lot_size=25))
    assert isinstance(r.quantity, int)
    assert r.quantity % 25 == 0
