from datetime import date
import pytest

from cybernetics.execution.instrument import (
    InstrumentType, OptionType, TradeInstrument, InstrumentEligibility,
    InstrumentSelectionRequest, InstrumentSelector
)

E = InstrumentEligibility(True, True, True, True, "approved")
S = InstrumentSelector()

def equity(sec="101", eligible=E):
    return TradeInstrument(
        exchange_segment="NSE_EQ",
        security_id=sec,
        symbol="NIFTY",
        instrument_type=InstrumentType.INDEX,
        lot_size=1,
        tick_size=0.05,
        contract_multiplier=1,
        eligibility=eligible,
    )

def option(sec="201", strike=25000, ot=OptionType.CE, eligible=E):
    return TradeInstrument(
        exchange_segment="NSE_FNO",
        security_id=sec,
        symbol="NIFTY",
        instrument_type=InstrumentType.OPTION,
        expiry=date(2026, 9, 24),
        strike=strike,
        option_type=ot,
        lot_size=65,
        tick_size=0.05,
        contract_multiplier=1,
        eligibility=eligible,
    )

def test_exact_index_selection():
    r = S.select(
        InstrumentSelectionRequest("NSE_EQ", "NIFTY", InstrumentType.INDEX),
        [equity()]
    )
    assert r.security_id == "101"

def test_option_selection_by_expiry_strike_type():
    r = S.select(
        InstrumentSelectionRequest(
            "NSE_FNO", "NIFTY", InstrumentType.OPTION,
            expiry=date(2026, 9, 24), strike=25000, option_type=OptionType.CE
        ),
        [option()]
    )
    assert r.security_id == "201"
    assert r.lot_size == 65

def test_ineligible_candidate_rejected():
    bad = InstrumentEligibility(True, False, True, True, "not_approved")
    with pytest.raises(LookupError, match="no_production_eligible_instrument_match"):
        S.select(
            InstrumentSelectionRequest("NSE_FNO", "NIFTY", InstrumentType.OPTION),
            [option(eligible=bad)]
        )

def test_not_active_candidate_rejected():
    bad = InstrumentEligibility(True, True, False, True, "inactive")
    with pytest.raises(LookupError):
        S.select(
            InstrumentSelectionRequest("NSE_FNO", "NIFTY", InstrumentType.OPTION),
            [option(eligible=bad)]
        )

def test_production_eligibility_can_be_disabled_for_research():
    bad = InstrumentEligibility(True, False, False, False, "research_only")
    r = S.select(
        InstrumentSelectionRequest(
            "NSE_FNO", "NIFTY", InstrumentType.OPTION,
            require_production_eligible=False
        ),
        [option(eligible=bad)]
    )
    assert r.security_id == "201"

def test_ambiguous_match_rejected():
    with pytest.raises(LookupError, match="ambiguous_instrument_selection"):
        S.select(
            InstrumentSelectionRequest("NSE_EQ", "NIFTY", InstrumentType.INDEX),
            [equity("101"), equity("102")]
        )

def test_wrong_expiry_rejected():
    with pytest.raises(LookupError):
        S.select(
            InstrumentSelectionRequest(
                "NSE_FNO", "NIFTY", InstrumentType.OPTION,
                expiry=date(2026, 10, 1), strike=25000, option_type=OptionType.CE
            ),
            [option()]
        )

def test_wrong_option_type_rejected():
    with pytest.raises(LookupError):
        S.select(
            InstrumentSelectionRequest(
                "NSE_FNO", "NIFTY", InstrumentType.OPTION,
                expiry=date(2026, 9, 24), strike=25000, option_type=OptionType.PE
            ),
            [option()]
        )

def test_trade_instrument_requires_option_fields():
    with pytest.raises(ValueError, match="option_expiry_required"):
        TradeInstrument(
            "NSE_FNO", "1", "NIFTY", InstrumentType.OPTION,
            lot_size=65, tick_size=0.05, contract_multiplier=1, eligibility=E
        )

def test_invalid_lot_size_rejected():
    with pytest.raises(ValueError, match="lot_size_must_be_positive"):
        TradeInstrument(
            "NSE_EQ", "1", "NIFTY", InstrumentType.INDEX,
            lot_size=0, tick_size=0.05, contract_multiplier=1, eligibility=E
        )

def test_contract_metadata_is_preserved():
    r = S.select(
        InstrumentSelectionRequest(
            "NSE_FNO", "NIFTY", InstrumentType.OPTION,
            expiry=date(2026, 9, 24), strike=25000, option_type=OptionType.CE
        ),
        [option()]
    )
    assert r.tick_size == 0.05
    assert r.contract_multiplier == 1
