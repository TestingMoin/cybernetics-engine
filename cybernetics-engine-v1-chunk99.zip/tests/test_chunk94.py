from __future__ import annotations

import json

from cybernetics.main import main
from cybernetics.runtime.application import (
    ApplicationLifecycle,
    RuntimeApplication,
    RuntimeConfig,
)


def test_fail_closed_bootstrap_never_allows_new_trades() -> None:
    app = RuntimeApplication()
    snapshot = app.start()
    try:
        assert app.lifecycle is ApplicationLifecycle.RUNNING
        assert snapshot.readiness.engine_ready is False
        assert snapshot.readiness.new_trades_allowed is False
        assert "persistence_not_ready" in snapshot.readiness.reasons
        assert "live_authorization_invalid" in snapshot.readiness.reasons
    finally:
        app.stop()
    assert app.lifecycle is ApplicationLifecycle.STOPPED


def test_once_mode_uses_canonical_entrypoint(capsys) -> None:
    assert main(["--once"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["service"] == "cybernetics-engine"
    assert out["new_trades_allowed"] is False
    assert out["lifecycle"] == "RUNNING"


def test_self_check_is_safe_and_non_mutating(capsys) -> None:
    assert main(["--self-check"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["engine_ready"] is False
    assert out["new_trades_allowed"] is False


def test_runtime_config_rejects_invalid_poll_interval() -> None:
    try:
        RuntimeConfig(poll_interval_seconds=0)
    except ValueError as exc:
        assert str(exc) == "poll_interval_seconds_must_be_positive"
    else:
        raise AssertionError("expected validation failure")
