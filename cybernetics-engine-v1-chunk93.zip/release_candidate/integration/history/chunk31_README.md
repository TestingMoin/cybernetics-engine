# Cybernetics Trading Engine — Chunk 31

## Dhan Market-Data REST / Recovery Client

This chunk adds the REST side of market-data recovery and validation.

### Implemented
- LTP snapshot endpoint facade.
- OHLC snapshot endpoint facade.
- Market Quote/depth endpoint facade.
- Daily historical candle endpoint facade.
- Intraday historical candle endpoint facade.
- Instrument payload validation.
- 1000-instrument market-quote request guard.
- Intraday interval validation for 1/5/15/25/60 minutes.
- Recovery-window planner capped at 90 days per historical intraday request.
- Ordered recovery-window execution helper.

The actual transport, access-token injection, rate limiting and retry policy come from the
previous transport layer. This chunk does not open WebSocket connections and does not place orders.

Dhan documents up to 1000 instruments per market-quote request at 1 request/sec, and
intraday historical requests for 1/5/15/25/60 minute intervals are limited to 90 days
per request. Live Market Feed remains the primary tick-by-tick runtime feed.
