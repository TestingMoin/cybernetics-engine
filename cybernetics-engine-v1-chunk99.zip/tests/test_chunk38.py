from cybernetics.scanners.models import ScannerRuntimeKey,ScannerState
from cybernetics.scanners.registry import ScannerRuntimeRegistry
from cybernetics.scanners.state_guard import can_process_market_event

def key(scanner="ICE-NIFTY", underlying="NIFTY", tf="1m"):
    return ScannerRuntimeKey(scanner,underlying,tf)

def test_same_scanner_different_underlyings_are_isolated():
    r=ScannerRuntimeRegistry()
    a=r.create(key(underlying="NIFTY"))
    b=r.create(key(underlying="BANKNIFTY"))
    a.update(signal_delta=2,state_patch={"last":"A"})
    b.update(signal_delta=1,state_patch={"last":"B"})
    assert a.signal_count==2 and b.signal_count==1
    assert a.state_data["last"]=="A"
    assert b.state_data["last"]=="B"

def test_different_timeframes_are_separate_runtime_instances():
    r=ScannerRuntimeRegistry()
    a=r.create(key(tf="1m"))
    b=r.create(key(tf="5m"))
    assert a is not b
    assert r.count()==2

def test_duplicate_runtime_key_is_rejected():
    r=ScannerRuntimeRegistry()
    r.create(key())
    try:
        r.create(key())
        assert False
    except ValueError as e:
        assert str(e)=="scanner_runtime_already_exists"

def test_start_stop_lifecycle():
    r=ScannerRuntimeRegistry()
    x=r.create(key())
    assert x.state==ScannerState.CREATED
    r.start(key())
    assert r.get(key()).state==ScannerState.RUNNING
    r.stop(key())
    assert r.get(key()).state==ScannerState.STOPPED

def test_degraded_state_records_reason_and_blocks_processing():
    r=ScannerRuntimeRegistry()
    r.create(key()); r.start(key())
    r.degrade(key(),"stale_feed")
    x=r.get(key())
    assert x.state==ScannerState.DEGRADED
    assert can_process_market_event(x).allowed is False
    assert x.state_data["degraded_reason"]=="stale_feed"

def test_failure_state_blocks_processing():
    r=ScannerRuntimeRegistry()
    r.create(key()); r.fail(key(),"data_gap")
    assert can_process_market_event(r.get(key())).allowed is False

def test_get_or_create_is_idempotent():
    r=ScannerRuntimeRegistry()
    a=r.get_or_create(key())
    b=r.get_or_create(key())
    assert a is b
    assert r.count()==1

def test_registry_event_callback_fires():
    events=[]
    r=ScannerRuntimeRegistry(events.append)
    r.create(key())
    r.start(key())
    r.stop(key())
    assert [e.action for e in events]==["CREATED","STARTED","STOPPED"]

def test_filtering_by_scanner_and_underlying():
    r=ScannerRuntimeRegistry()
    r.create(key("ICE-NIFTY","NIFTY","1m"))
    r.create(key("ICE-NIFTY","BANKNIFTY","1m"))
    r.create(key("ICE-BANKNIFTY","BANKNIFTY","1m"))
    assert len(r.list(scanner_id="ICE-NIFTY"))==2
    assert len(r.list(underlying_key="BANKNIFTY"))==2
