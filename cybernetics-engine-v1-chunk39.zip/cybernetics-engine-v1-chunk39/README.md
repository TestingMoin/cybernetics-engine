# Cybernetics Trading Engine — Chunk 39

## Scanner Event Dispatcher + Subscription-to-Scanner Routing

This chunk connects market events to the isolated scanner runtime registry.

### Core rule

An event is delivered only when an explicit mapping exists:

`exchange_segment + security_id + timeframe -> scanner_id + underlying_key + timeframe`

There is no symbol-name guessing and no broadcast of every event to every scanner.

### Safety
- Missing route -> rejected.
- Missing timeframe -> rejected.
- Runtime missing -> rejected.
- Runtime not RUNNING -> rejected.
- A routing key cannot silently be rebound to another runtime.
- Only the selected runtime's event counter/state is updated.

This is the dispatch boundary between the market-data plane and scanner runtime plane.
It does not generate signals or place orders.
