from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import pytest
from cybernetics.runtime.watchdog import build_watchdog_runtime_wiring
from cybernetics.runtime.production import RuntimeDependencyState, build_production_runtime
from cybernetics.config.settings import DeploymentConfig, TradingMode
from cybernetics.watchdog.health import Health, HealthRegistry

def cfg(tmp_path):
    return DeploymentConfig(service_name='test', data_dir=tmp_path, trading_mode=TradingMode.PAPER, runtime_poll_seconds=1.0)

def test_builder_validation(tmp_path):
    reg=HealthRegistry()
    with pytest.raises(ValueError): build_watchdog_runtime_wiring(registry=None, required_components=['engine'])
    with pytest.raises(ValueError): build_watchdog_runtime_wiring(registry=reg, required_components=[])
    with pytest.raises(ValueError): build_watchdog_runtime_wiring(registry=reg, required_components=['engine'], heartbeat_timeout_seconds=0)

def test_healthy_fresh():
    reg=HealthRegistry(); reg.beat('engine', health=Health.HEALTHY, now=100)
    p=build_watchdog_runtime_wiring(registry=reg, required_components=['engine'], now_provider=lambda:100)
    assert p.watchdog_healthy() is True and p.reasons()==()

def test_missing_and_stale_fail_closed():
    reg=HealthRegistry(); now=[100]
    p=build_watchdog_runtime_wiring(registry=reg, required_components=['engine'], now_provider=lambda:now[0])
    assert p.watchdog_healthy() is False and 'engine:no_heartbeat' in p.reasons()
    reg.beat('engine', now=80); now[0]=100
    assert p.watchdog_healthy() is False and 'engine:stale_heartbeat' in p.reasons()

def test_degraded_failed_unhealthy():
    for h in (Health.DEGRADED, Health.FAILED):
        reg=HealthRegistry(); reg.beat('engine', health=h, now=100)
        p=build_watchdog_runtime_wiring(registry=reg, required_components=['engine'], now_provider=lambda:100)
        assert p.watchdog_healthy() is False

def test_probe_exception_fail_closed():
    class FailingSupervisor:
        def evaluate(self,*a,**k): raise RuntimeError('boom')
    reg=HealthRegistry()
    p=build_watchdog_runtime_wiring(registry=reg, required_components=['engine'], supervisor=FailingSupervisor())
    assert p.watchdog_healthy() is False
    assert p.reasons()[0].startswith('watchdog_probe_error:')

def test_production_runtime_uses_watchdog(tmp_path):
    reg=HealthRegistry(); reg.beat('engine', health=Health.HEALTHY, now=10)
    p=build_watchdog_runtime_wiring(registry=reg, required_components=['engine'], now_provider=lambda:10)
    state=RuntimeDependencyState(engine_running=True, persistence_ready=True, recovery_clear=True, orders_reconciled=True,
        positions_reconciled=True, market_data_ready=True, scanner_health_ready=True, watchdog_healthy=False, broker_available=True)
    runtime=build_production_runtime(cfg(tmp_path), dependency_state=state, watchdog_runtime=p)
    snap=runtime.snapshot()
    assert snap.inputs.watchdog_healthy is True
