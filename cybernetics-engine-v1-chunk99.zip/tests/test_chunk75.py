import pytest

from cybernetics.control.gateway import (
    CommandName, CommandResult, ControlCommand, ControlCommandGateway,
    GatewayPolicy,
)
from cybernetics.control.memory_store import InMemoryAuditSink, InMemoryCommandIdStore
from cybernetics.runtime.control import (
    ControlAction, ControlState, ControlStateMachine,
    GuardedController, InvalidTransition, TransitionPolicy,
)


NOW = 1_000.0


def gateway(state=ControlState.RUNNING, policy=None):
    machine = ControlStateMachine(state)
    controller = GuardedController(machine)
    ids = InMemoryCommandIdStore()
    audit = InMemoryAuditSink()
    gw = ControlCommandGateway(
        controller, ids, audit, policy=policy, clock=lambda: NOW
    )
    return gw, ids, audit


def cmd(
    name=CommandName.STOP_NEW_TRADES,
    command_id="C1",
    source="PWA",
    issued_at=NOW,
    expected_state=None,
):
    return ControlCommand(
        command_id=command_id,
        command=name,
        issued_at=issued_at,
        source=source,
        expected_state=expected_state,
    )


def test_accepts_valid_stop_command():
    gw, _, _ = gateway()
    r = gw.handle(cmd())
    assert r.result is CommandResult.ACCEPTED
    assert r.state is ControlState.STOP_NEW_TRADES


def test_duplicate_command_is_rejected():
    gw, _, _ = gateway()
    first = gw.handle(cmd())
    second = gw.handle(cmd())
    assert first.result is CommandResult.ACCEPTED
    assert second.result is CommandResult.DUPLICATE


def test_stale_command_is_rejected():
    gw, _, _ = gateway()
    r = gw.handle(cmd(issued_at=NOW - 31))
    assert r.result is CommandResult.STALE


def test_future_command_is_rejected():
    gw, _, _ = gateway()
    r = gw.handle(cmd(issued_at=NOW + 1))
    assert r.result is CommandResult.REJECTED
    assert r.reason == "command_from_future"


def test_unknown_source_is_rejected():
    gw, _, _ = gateway()
    r = gw.handle(cmd(source="UNKNOWN"))
    assert r.result is CommandResult.REJECTED


def test_missing_command_id_is_rejected():
    gw, _, _ = gateway()
    r = gw.handle(cmd(command_id=""))
    assert r.result is CommandResult.REJECTED


def test_expected_state_mismatch_blocks_command():
    gw, _, _ = gateway(ControlState.RUNNING)
    r = gw.handle(
        cmd(
            name=CommandName.STOP_NEW_TRADES,
            expected_state=ControlState.STOP_NEW_TRADES,
        )
    )
    assert r.result is CommandResult.REJECTED
    assert r.reason == "expected_state_mismatch"


def test_external_resume_requires_expected_state():
    gw, _, _ = gateway(ControlState.STOP_NEW_TRADES)
    r = gw.handle(
        cmd(
            name=CommandName.RESUME_NEW_TRADES,
            command_id="R1",
            expected_state=None,
        ),
        policy=TransitionPolicy(True, True),
    )
    assert r.result is CommandResult.REJECTED
    assert r.reason == "expected_state_required_for_resume"


def test_external_resume_requires_live_auth_even_when_expected_state_matches():
    gw, _, _ = gateway(ControlState.STOP_NEW_TRADES)
    r = gw.handle(
        cmd(
            name=CommandName.RESUME_NEW_TRADES,
            command_id="R2",
            expected_state=ControlState.STOP_NEW_TRADES,
        ),
        policy=TransitionPolicy(False, True),
    )
    assert r.result is CommandResult.REJECTED
    assert "policy_blocked" in r.reason


def test_external_resume_succeeds_with_both_independent_guards():
    gw, _, _ = gateway(ControlState.STOP_NEW_TRADES)
    r = gw.handle(
        cmd(
            name=CommandName.RESUME_NEW_TRADES,
            command_id="R3",
            expected_state=ControlState.STOP_NEW_TRADES,
        ),
        policy=TransitionPolicy(True, True),
    )
    assert r.result is CommandResult.ACCEPTED
    assert r.state is ControlState.RUNNING


def test_emergency_stop_is_accepted_from_running():
    gw, _, _ = gateway(ControlState.RUNNING)
    r = gw.handle(
        cmd(name=CommandName.EMERGENCY_STOP, command_id="E1")
    )
    assert r.result is CommandResult.ACCEPTED
    assert r.state is ControlState.EMERGENCY_STOP


def test_invalid_transition_is_rejected():
    gw, _, _ = gateway(ControlState.ENGINE_OFF)
    r = gw.handle(cmd(name=CommandName.STOP_NEW_TRADES))
    assert r.result is CommandResult.REJECTED


def test_start_sequence_can_be_driven_by_gateway():
    gw, _, _ = gateway(ControlState.ENGINE_OFF)
    r1 = gw.handle(cmd(CommandName.ENGINE_START, "S1"))
    r2 = gw.handle(cmd(CommandName.ENGINE_START_SUCCESS, "S2"))
    assert r1.state is ControlState.STARTING
    assert r2.state is ControlState.RUNNING


def test_start_failure_returns_engine_off():
    gw, _, _ = gateway(ControlState.ENGINE_OFF)
    gw.handle(cmd(CommandName.ENGINE_START, "S3"))
    r = gw.handle(cmd(CommandName.ENGINE_START_FAILURE, "S4"))
    assert r.state is ControlState.ENGINE_OFF


def test_recovery_sequence_requires_correct_states():
    gw, _, _ = gateway(ControlState.EMERGENCY_STOP)
    r1 = gw.handle(cmd(CommandName.BEGIN_RECOVERY, "R4"))
    r2 = gw.handle(cmd(CommandName.RECOVERY_COMPLETE, "R5"))
    assert r1.state is ControlState.RECOVERY
    assert r2.result is CommandResult.REJECTED  # recovery_clear absent


def test_recovery_complete_with_clear_policy():
    gw, _, _ = gateway(ControlState.RECOVERY)
    r = gw.handle(
        cmd(
            CommandName.RECOVERY_COMPLETE,
            "R6",
            expected_state=ControlState.RECOVERY,
        ),
        policy=TransitionPolicy(True, True),
    )
    assert r.result is CommandResult.ACCEPTED
    assert r.state is ControlState.STOP_NEW_TRADES


def test_audit_event_is_emitted_for_acceptance():
    gw, _, audit = gateway()
    gw.handle(cmd())
    assert len(audit.events) == 1
    assert audit.events[0]["result"] == "ACCEPTED"


def test_audit_event_is_emitted_for_rejection():
    gw, _, audit = gateway()
    gw.handle(cmd(issued_at=NOW - 100))
    assert len(audit.events) == 1
    assert audit.events[0]["result"] == "STALE"


def test_duplicate_still_generates_audit():
    gw, _, audit = gateway()
    gw.handle(cmd())
    gw.handle(cmd())
    assert [e["result"] for e in audit.events] == ["ACCEPTED", "DUPLICATE"]


def test_command_id_not_remembered_when_rejected():
    gw, ids, _ = gateway(ControlState.ENGINE_OFF)
    gw.handle(cmd(name=CommandName.STOP_NEW_TRADES))
    assert not ids.seen("C1")


def test_gateway_has_no_broker_order_endpoint():
    from pathlib import Path
    src = Path("src/cybernetics/control/gateway.py").read_text()
    for token in ("place_order", "submit_order", "cancel_order", "replace_order", "/v2/orders"):
        assert token not in src


def test_gateway_does_not_create_live_authorization():
    from pathlib import Path
    src = Path("src/cybernetics/control/gateway.py").read_text()
    assert "approve(" not in src
