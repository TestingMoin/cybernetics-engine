from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import signal
import threading
from typing import Callable, Optional

from .composition import RuntimeSignals, RuntimeSnapshot, RuntimeStateComposer
from .state import EngineMode


class ApplicationLifecycle(str, Enum):
    CREATED = "CREATED"
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    STOPPING = "STOPPING"
    STOPPED = "STOPPED"
    FAILED = "FAILED"


@dataclass(frozen=True)
class RuntimeConfig:
    """Configuration for the canonical process entrypoint.

    The entrypoint is intentionally fail-closed: no broker connection, live
    authorization, order submission, or database mutation is created by
    default. Those are injected by a later production composition layer.
    """

    service_name: str = "cybernetics-engine"
    poll_interval_seconds: float = 1.0

    def __post_init__(self) -> None:
        if not self.service_name:
            raise ValueError("service_name_required")
        if self.poll_interval_seconds <= 0:
            raise ValueError("poll_interval_seconds_must_be_positive")


class FailClosedBootstrapSignals:
    """Safe bootstrap signal source used until production dependencies exist."""

    def engine_mode(self):
        return EngineMode.STOPPED

    def control_state(self):
        from .state import ControlState
        return ControlState.STOP_NEW_TRADES

    def persistence_ready(self):
        return False

    def recovery_clear(self):
        return False

    def orders_reconciled(self):
        return False

    def positions_reconciled(self):
        return False

    def market_data_ready(self):
        return False

    def scanner_health_ready(self):
        return False

    def watchdog_healthy(self):
        return False

    def live_authorization_valid(self):
        return False

    def broker_available(self):
        return False

    def emergency_state(self):
        from .state import EmergencyState
        return EmergencyState.CLEAR


class RuntimeApplication:
    """Canonical lifecycle wrapper for the Cybernetics process.

    The class owns process lifecycle only. It deliberately does not embed
    trading, broker, or order logic. A production composition root can inject
    real ``RuntimeSignals`` and lifecycle hooks without changing the process
    entrypoint contract.
    """

    def __init__(
        self,
        *,
        config: RuntimeConfig | None = None,
        signals: RuntimeSignals | None = None,
        on_start: Optional[Callable[[], None]] = None,
        on_stop: Optional[Callable[[], None]] = None,
    ) -> None:
        self.config = config or RuntimeConfig()
        self.signals = signals or FailClosedBootstrapSignals()
        self.composer = RuntimeStateComposer(self.signals)
        self.on_start = on_start
        self.on_stop = on_stop
        self.lifecycle = ApplicationLifecycle.CREATED
        self._stop_event = threading.Event()
        self._last_snapshot: RuntimeSnapshot | None = None

    def snapshot(self) -> RuntimeSnapshot:
        current = self.composer.snapshot()
        self._last_snapshot = current
        return current

    @property
    def last_snapshot(self) -> RuntimeSnapshot | None:
        return self._last_snapshot

    def start(self) -> RuntimeSnapshot:
        if self.lifecycle is not ApplicationLifecycle.CREATED:
            raise RuntimeError("application_not_created")
        self.lifecycle = ApplicationLifecycle.STARTING
        try:
            if self.on_start:
                self.on_start()
            # Evaluate readiness during startup, but do not equate engine
            # process liveness with trading readiness. The process may be
            # RUNNING while new-trade readiness remains false.
            startup_snapshot = self.snapshot()
            self.lifecycle = ApplicationLifecycle.RUNNING
            return startup_snapshot
        except Exception:
            self.lifecycle = ApplicationLifecycle.FAILED
            raise

    def refresh_snapshot(self) -> RuntimeSnapshot:
        """Refresh canonical readiness without changing process lifecycle."""
        if self.lifecycle not in {ApplicationLifecycle.STARTING, ApplicationLifecycle.RUNNING}:
            raise RuntimeError("application_not_running_or_starting")
        return self.snapshot()

    def stop(self) -> None:
        if self.lifecycle in {
            ApplicationLifecycle.STOPPED,
            ApplicationLifecycle.CREATED,
        }:
            self.lifecycle = ApplicationLifecycle.STOPPED
            return
        self.lifecycle = ApplicationLifecycle.STOPPING
        try:
            if self.on_stop:
                self.on_stop()
        finally:
            self._stop_event.set()
            self.lifecycle = ApplicationLifecycle.STOPPED

    def wait(self) -> None:
        if self.lifecycle is not ApplicationLifecycle.RUNNING:
            raise RuntimeError("application_not_running")
        self._stop_event.wait(self.config.poll_interval_seconds)

    def request_stop(self) -> None:
        self._stop_event.set()

    def run(self) -> int:
        self.start()
        try:
            while not self._stop_event.is_set():
                self.wait()
            return 0
        except KeyboardInterrupt:
            return 0
        except Exception:
            self.lifecycle = ApplicationLifecycle.FAILED
            raise
        finally:
            self.stop()


def install_signal_handlers(app: RuntimeApplication) -> None:
    """Install process-level stop handlers for SIGINT/SIGTERM."""

    def _handle(_signum: int, _frame: object) -> None:
        app.request_stop()

    signal.signal(signal.SIGINT, _handle)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, _handle)
