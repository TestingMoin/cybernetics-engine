# Cybernetics Trading Engine — Chunk 68

## Real PostgreSQL Fill Ledger/Outbox Repository

This chunk implements the repository boundary that maps the durable contracts
from Chunks 64–65 onto PostgreSQL SQL operations.

### Fill ledger
- idempotent claim by `fill_id`
- fetch existing fill
- CLAIMED → COMPLETED
- CLAIMED/RECOVERY_REQUIRED → RECOVERY_REQUIRED

### Fill outbox
- idempotent enqueue by `fill_id`
- batch claim using `FOR UPDATE SKIP LOCKED`
- PROCESSING → COMPLETED
- PROCESSING → FAILED

### Transaction boundary
`atomic_fill_transaction()` delegates transaction ownership to the caller's
PostgreSQL connection. It does not own the connection pool, credentials,
reconnect policy, or retry policy.

No live broker calls are present. No production PostgreSQL instance is touched
during this build.
