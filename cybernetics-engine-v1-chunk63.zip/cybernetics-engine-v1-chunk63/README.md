# Cybernetics Trading Engine — Chunk 63

## Fill/Event → Order + Position + Trade Lifecycle Atomic Coordinator

This chunk creates the coordination boundary for one canonical broker fill.

Flow:

Canonical Fill
→ Fill Registry Claim
→ Order Manager update
→ Position Manager update
→ Strategy Trade Lifecycle update
→ Fill Registry Complete

The coordinator is deliberately explicit about the atomicity boundary. Python
in-memory sequencing is not a true distributed transaction. Therefore, any
downstream exception after a fill is claimed produces `RECOVERY_REQUIRED`
instead of silently retrying the fill.

The production implementation should replace the reference registry with the
existing PostgreSQL ledger and use a transactional event/idempotency boundary.

Safety:
- fill IDs are idempotent
- completed fills are never replayed
- claimed-but-incomplete fills require recovery
- downstream failures do not cause blind duplicate reapplication
- no broker calls are made
- no direct Dhan interaction is introduced
