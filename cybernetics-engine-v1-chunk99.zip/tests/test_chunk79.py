from cybernetics.runtime.readiness import (
    RuntimeInputs, RuntimeReadiness, EngineMode, EmergencyState, evaluate_runtime
)
from cybernetics.execution.gate import (
    ExecutionInputs, ExecutionDecision, evaluate_entry
)

def runtime(**kw):
    x=dict(
        engine_mode=EngineMode.RUNNING,
        control_state="RUNNING",
        emergency_state=EmergencyState.CLEAR,
        persistence_ready=True,
        recovery_clear=True,
        orders_reconciled=True,
        positions_reconciled=True,
        market_data_ready=True,
        scanner_health_ready=True,
        watchdog_healthy=True,
        broker_available=True,
        live_authorization_valid=True,
    )
    x.update(kw)
    return RuntimeInputs(**x)

def execution(**kw):
    x=dict(
        engine_ready=True,
        new_trades_allowed=True,
        emergency_active=False,
        live_authorization_valid=True,
        reconciliation_ready=True,
        risk_approved=True,
        pretrade_approved=True,
        broker_available=True,
        positive_quantity=True,
        positive_price=True,
    )
    x.update(kw)
    return ExecutionInputs(**x)

def test_clear_emergency_allows_runtime_when_other_gates_pass():
    r=evaluate_runtime(runtime())
    assert r.engine_ready
    assert r.new_trades_allowed

def test_active_emergency_blocks_new_trades():
    r=evaluate_runtime(runtime(emergency_state=EmergencyState.ACTIVE))
    assert r.engine_ready
    assert not r.new_trades_allowed
    assert "emergency_stop_active" in r.reasons

def test_emergency_does_not_make_engine_unhealthy_by_itself():
    r=evaluate_runtime(runtime(emergency_state=EmergencyState.ACTIVE))
    assert r.engine_ready is True

def test_execution_blocks_on_emergency():
    r=evaluate_entry(execution(emergency_active=True))
    assert r.decision is ExecutionDecision.BLOCK
    assert "emergency_stop_active" in r.reasons

def test_execution_blocks_even_if_runtime_flag_is_stale_healthy():
    r=evaluate_entry(execution(new_trades_allowed=True, emergency_active=True))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_when_new_trades_disallowed():
    r=evaluate_entry(execution(new_trades_allowed=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_without_live_authorization():
    r=evaluate_entry(execution(live_authorization_valid=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_without_engine_ready():
    r=evaluate_entry(execution(engine_ready=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_without_reconciliation():
    r=evaluate_entry(execution(reconciliation_ready=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_without_risk():
    r=evaluate_entry(execution(risk_approved=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_without_pretrade_approval():
    r=evaluate_entry(execution(pretrade_approved=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_without_broker():
    r=evaluate_entry(execution(broker_available=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_invalid_quantity():
    r=evaluate_entry(execution(positive_quantity=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_blocks_invalid_price():
    r=evaluate_entry(execution(positive_price=False))
    assert r.decision is ExecutionDecision.BLOCK

def test_execution_allows_only_when_all_entry_gates_pass():
    r=evaluate_entry(execution())
    assert r.decision is ExecutionDecision.ALLOW
    assert r.reasons==()

def test_multiple_blockers_are_reported():
    r=evaluate_entry(execution(
        emergency_active=True,
        risk_approved=False,
        pretrade_approved=False,
    ))
    assert r.decision is ExecutionDecision.BLOCK
    assert len(r.reasons)>=3

def test_emergency_reason_survives_live_auth_failure():
    r=evaluate_runtime(
        runtime(
            emergency_state=EmergencyState.ACTIVE,
            live_authorization_valid=False
        )
    )
    assert "emergency_stop_active" in r.reasons
    assert "live_authorization_invalid" in r.reasons

def test_no_broker_endpoint_in_enforcement_modules():
    from pathlib import Path
    for f in (
        "src/cybernetics/execution/gate.py",
        "src/cybernetics/runtime/readiness.py",
    ):
        src=Path(f).read_text()
        for token in ("/v2/orders","place_order","submit_order","cancel_order","replace_order"):
            assert token not in src
