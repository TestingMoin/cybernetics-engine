# Cybernetics Trading Engine — Chunk 5

## Purpose
Integrate the existing Options Master Engine as an analytics-only subsystem and introduce isolated per-underlying Options Signal Monitor instances.

## Preserved analytics
The source file `app/options/master_engine_legacy.py` is the existing Options Master Engine copied into the project without mathematical rewrites. The integration adapter exposes its existing models and engine while keeping broker execution outside the options subsystem.

## Architecture

Dhan Option Chain REST
→ request coordinator (future chunk)
→ normalized rows
→ OptionsMasterEngine
→ data-quality audit
→ OptionsSignalMonitor (per underlying)
→ Signal Registry (future chunk)
→ risk (future chunk)
→ execution (future chunk)

No option analytics module can place orders.

## Important limitation
This chunk does not yet implement the Dhan option-chain fetch scheduler. Dhan's current documentation states that the Option Chain API returns OI, Greeks, volume, LTP, best bid/ask and IV for all strikes and permits a unique request every 3 seconds. The scheduler/cache will be implemented in the subsequent data-intelligence chunk.

## Safety
- Live trading remains disabled.
- No broker order transport is called.
- Scanner state is isolated by scanner instance and underlying.
- Existing Options Master Engine source is preserved as the source of truth for its analytics until it is independently regression-tested against its prior self-tests.
