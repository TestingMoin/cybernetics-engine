# Chunk 87 — Strategy Models Interface Reconciliation

## Conflict

Chunk 45 defines the framework-wide `strategy.models` contract:

- DecisionType
- StrategyContext
- StrategyDecision

Chunk 46 independently defines:

- GoldenContext
- GoldenDecision

Replacing Chunk 45 with Chunk 46 would break the StrategyEngine and qualified
signal bridge. Replacing Chunk 46's specialized context would weaken the Golden
strategy reproduction target.

## Canonical resolution

`strategy.models` remains the generic, framework-wide canonical contract from
Chunk 45.

Golden-specific models are isolated in:
`strategy.golden_models`

`strategy.golden` imports GoldenContext/GoldenDecision from that module.

This preserves both contracts without duplicate public ownership of the same
module path.

No execution/broker behavior is introduced by this reconciliation.
