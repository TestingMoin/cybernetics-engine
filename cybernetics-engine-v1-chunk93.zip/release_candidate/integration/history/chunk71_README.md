# Cybernetics Trading Engine — Chunk 71

## Fill Recovery & Reconciliation Worker

This chunk establishes a controlled recovery boundary for fills that cannot be
safely completed.

### Recovery states

RECOVERY_REQUIRED -> RECOVERY_IN_PROGRESS
                  -> RECOVERY_RESOLVED
                  -> RECOVERY_BLOCKED

### Recovery sequence

1. Register the recovery case.
2. Mark it in progress.
3. Read broker order state.
4. Read broker positions.
5. Compare broker state against internal state.
6. Resolve only when the evidence is consistent.
7. Otherwise block the case and require reconciliation/review.

### Critical safety rule

Recovery never submits, replaces, or blindly retries an order.

A mismatch is treated as a safety event, not as permission to "fix" the
broker account automatically.

New-trade readiness remains blocked whenever reconciliation is not consistent.

No broker order submission is present in this chunk.
