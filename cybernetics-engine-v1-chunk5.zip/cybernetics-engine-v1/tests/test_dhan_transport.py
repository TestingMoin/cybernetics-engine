import pytest
import httpx

from app.broker.dhan_rest import DhanRestClient


class FakeGovernor:
    def __init__(self):
        self.calls = []
    async def acquire(self, kind):
        self.calls.append(kind)


@pytest.mark.asyncio
async def test_ltp_uses_dhan_headers_and_endpoint():
    seen = {}
    def handler(request: httpx.Request) -> httpx.Response:
        seen['url'] = str(request.url)
        seen['auth'] = request.headers.get('access-token')
        seen['client'] = request.headers.get('client-id')
        return httpx.Response(200, json={'status': 'success', 'data': {}})

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    gov = FakeGovernor()
    api = DhanRestClient('123', access_token='TOKEN', governor=gov, http_client=client)
    payload = await api.get_ltp({'NSE_FNO': [1, 2]})
    await api.close()
    assert payload['status'] == 'success'
    assert seen['url'].endswith('/marketfeed/ltp')
    assert seen['auth'] == 'TOKEN'
    assert seen['client'] == '123'
    assert len(gov.calls) == 1


@pytest.mark.asyncio
async def test_order_transport_is_explicitly_blocked():
    from app.broker.dhan import DhanV2BrokerAdapter
    from app.broker.interface import OrderRequest
    from decimal import Decimal
    adapter = DhanV2BrokerAdapter('123', access_token='TOKEN')
    with pytest.raises(RuntimeError, match='disabled'):
        await adapter.place_order(OrderRequest('X', 'NSE_FNO', 'BUY', 1, 'MARKET', Decimal('100')))
    await adapter.close()
