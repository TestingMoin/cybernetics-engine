# Cybernetics Trading Engine — Chunk 17

Position Manager + Independent Exit Manager.

The Position Manager consumes executed fills and maintains:
- quantity and side
- average entry price
- realized P&L
- last price
- unrealized P&L
- fees

The Exit Manager evaluates stop-loss/target conditions but does not execute them.
This separation allows future risk and broker layers to veto or control exits.
