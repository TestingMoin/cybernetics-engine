# Chunk 86 — Signal Lifecycle Interface Reconciliation

## Conflict resolved

The unified candidate contained competing signal-lifecycle contracts.

The canonical contract is the richer Chunk 44 lifecycle implementation because it
contains the complete state machine required by the signal qualification boundary:

OBSERVED -> ACTIVE
terminal states: INVALIDATED, EXPIRED, SUPERSEDED

It also preserves:
- TTL/expiry handling
- explicit invalidation reasons
- supersession linking
- validity checks used by qualification

The reconciliation rule is therefore to preserve lifecycle semantics and adapt
callers to this contract rather than weakening the lifecycle API.

This chunk does not introduce execution, order placement, or broker mutation.
