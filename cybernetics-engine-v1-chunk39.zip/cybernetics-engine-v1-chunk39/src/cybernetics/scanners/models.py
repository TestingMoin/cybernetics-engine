from dataclasses import dataclass,field
from enum import Enum
from datetime import datetime,timezone
class ScannerState(str,Enum):
 CREATED="CREATED";STARTING="STARTING";RUNNING="RUNNING";DEGRADED="DEGRADED";STOPPED="STOPPED";FAILED="FAILED"
@dataclass(frozen=True)
class ScannerRuntimeKey:
 scanner_id:str; underlying_key:str; timeframe:str
@dataclass
class ScannerRuntime:
 key:ScannerRuntimeKey; state:ScannerState=ScannerState.CREATED; event_count:int=0; signal_count:int=0
 state_data:dict=field(default_factory=dict)
 def update(self,*,event_delta=0,signal_delta=0,state_patch=None,when=None):
  self.event_count+=event_delta;self.signal_count+=signal_delta
  if state_patch:self.state_data.update(state_patch)
