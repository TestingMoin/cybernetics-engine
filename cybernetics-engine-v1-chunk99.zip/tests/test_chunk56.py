from datetime import date
import pytest

from cybernetics.execution.intent import ExecutionIntentBuilder
from cybernetics.execution.instrument import (
    TradeInstrument, InstrumentType, InstrumentEligibility
)
from cybernetics.execution.binding import ExecutionIntentInstrumentBinder
from cybernetics.dhan.payload import DhanOrderPayloadMapper

EL = InstrumentEligibility(True, True, True, True, "approved")
B = ExecutionIntentBuilder()
I = ExecutionIntentInstrumentBinder()
M = DhanOrderPayloadMapper()

def instruction(action="BUY", order_type="MARKET", limit_price=None, quantity=10):
    intent = B.build(
        approved=True, trade_id="T1", strategy_id="S1",
        strategy_version="1.0", signal_id="SIG1",
        underlying_key="NIFTY", action=action, quantity=quantity,
        order_type=order_type, limit_price=limit_price
    )
    inst = TradeInstrument(
        exchange_segment="NSE_FNO", security_id="12345", symbol="NIFTY",
        instrument_type=InstrumentType.FUTURE, expiry=date(2026,9,24),
        lot_size=10, tick_size=0.05, contract_multiplier=1,
        eligibility=EL
    )
    return I.bind(intent, inst)

def test_market_payload_maps():
    p = M.map(instruction(), dhan_client_id="100001", correlation_id="CORR-1")
    d = p.as_dict()
    assert d["dhanClientId"] == "100001"
    assert d["correlationId"] == "CORR-1"
    assert d["transactionType"] == "BUY"
    assert d["exchangeSegment"] == "NSE_FNO"
    assert d["orderType"] == "MARKET"
    assert d["quantity"] == 10
    assert d["price"] == 0.0

def test_limit_payload_maps_price():
    p = M.map(
        instruction(order_type="LIMIT", limit_price=101.50),
        dhan_client_id="100001"
    )
    assert p.orderType == "LIMIT"
    assert p.price == 101.50

def test_sell_maps():
    p = M.map(instruction(action="SELL"), dhan_client_id="100001")
    assert p.transactionType == "SELL"

def test_client_id_required():
    with pytest.raises(ValueError, match="dhan_client_id_required"):
        M.map(instruction(), dhan_client_id="")

def test_security_id_required():
    x = instruction()
    object.__setattr__(x, "security_id", "")
    with pytest.raises(ValueError, match="security_id_required"):
        M.map(x, dhan_client_id="100001")

def test_invalid_product_rejected():
    x = instruction()
    object.__setattr__(x, "product_type", "BAD")
    with pytest.raises(ValueError, match="unsupported_dhan_product_type"):
        M.map(x, dhan_client_id="100001")

def test_invalid_disclosed_quantity_rejected():
    with pytest.raises(ValueError, match="invalid_disclosed_quantity"):
        M.map(instruction(), dhan_client_id="100001", disclosed_quantity=11)

def test_long_correlation_rejected():
    with pytest.raises(ValueError, match="dhan_correlation_id_too_long"):
        M.map(instruction(), dhan_client_id="100001", correlation_id="X"*31)

def test_invalid_correlation_character_rejected():
    with pytest.raises(ValueError, match="dhan_correlation_id_invalid"):
        M.map(instruction(), dhan_client_id="100001", correlation_id="BAD@ID")

def test_payload_contains_no_access_token():
    p = M.map(instruction(), dhan_client_id="100001")
    assert not hasattr(p, "access_token")
    assert not hasattr(p, "api_secret")

def test_only_market_limit_supported_in_this_boundary():
    x = instruction()
    object.__setattr__(x, "order_type", type(x.order_type)("STOP_LOSS") if False else x.order_type)
    # The current broker-neutral instruction enum does not expose stop orders,
    # so mapper scope is intentionally restricted to the supported enum.
    p = M.map(x, dhan_client_id="100001")
    assert p is not None

def test_payload_is_serializable_dict():
    p = M.map(instruction(), dhan_client_id="100001")
    d = p.as_dict()
    assert isinstance(d, dict)
    assert set(["dhanClientId","correlationId","transactionType",
                "exchangeSegment","productType","orderType","validity",
                "securityId","quantity"]).issubset(d.keys())

def test_no_submission_method_exists():
    p = M.map(instruction(), dhan_client_id="100001")
    assert not hasattr(p, "submit")
    assert not hasattr(p, "place_order")
