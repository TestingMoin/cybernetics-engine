from cybernetics.ai.auditor import AuditAnalyzer, ProposalEngine
from cybernetics.ai.gates import ImprovementGate
from cybernetics.ai.policy import DEFAULT_AI_POLICY
from cybernetics.ai.registry import ProposalRegistry

def test_analyzer_detects_reconciliation_failure():
    f=AuditAnalyzer().analyze([{"event_type":"RECONCILIATION","matched":False}], "v1")
    assert len(f)==1 and f[0].severity=="CRITICAL"

def test_proposal_defaults_to_proposed():
    f=AuditAnalyzer().analyze([{"event_type":"DATA_QUALITY","healthy":False}], "v1")[0]
    p=ProposalEngine().propose(f,"STRATEGY","GOLDEN_X",{"threshold":0.7},
                                "reduce repeated false positives",("golden_regression",))
    assert p.status=="PROPOSED" and len(p.proposal_hash)==64

def test_all_validation_stages_are_required():
    f=AuditAnalyzer().analyze([{"event_type":"DATA_QUALITY","healthy":False}], "v1")[0]
    p=ProposalEngine().propose(f,"STRATEGY","X",{}, "x", ("t1",))
    r=ImprovementGate().evaluate(p,run_tests=lambda:True,run_backtest=lambda:True,
                                 run_oos=lambda:True,run_paper=lambda:True,
                                 run_regression=lambda:True)
    assert r.tests_passed and r.backtest_passed and r.out_of_sample_passed and r.paper_passed and r.regression_passed

def test_human_approval_is_mandatory():
    f=AuditAnalyzer().analyze([{"event_type":"DATA_QUALITY","healthy":False}], "v1")[0]
    p=ProposalEngine().propose(f,"STRATEGY","X",{}, "x", ("t1",))
    r=ImprovementGate().evaluate(p,run_tests=lambda:True,run_backtest=lambda:True,
                                 run_oos=lambda:True,run_paper=lambda:True,
                                 run_regression=lambda:True)
    assert ImprovementGate().require_human_approval(r).approved is False
    assert ImprovementGate().require_human_approval(r,approved_by="operator").approved is True

def test_policy_blocks_automation():
    assert DEFAULT_AI_POLICY.allow_auto_strategy_edit is False
    assert DEFAULT_AI_POLICY.allow_auto_deployment is False
    assert DEFAULT_AI_POLICY.allow_ai_order_generation is False

def test_registry_tracks_approval():
    f=AuditAnalyzer().analyze([{"event_type":"DATA_QUALITY","healthy":False}], "v1")[0]
    p=ProposalEngine().propose(f,"STRATEGY","X",{}, "x", ("t1",))
    r=ProposalRegistry(); r.add(p); r.set_validation(p.proposal_id,"PASSED"); r.approve(p.proposal_id,"operator")
    assert r.get(p.proposal_id).approval_status=="operator"
