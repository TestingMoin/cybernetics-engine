from app.instruments.universe import NSE_INDEXES, BSE_PLANNED_INDEXES, MCX_GROUPS, LOGICAL_SCANNER_GROUP_COUNT
from app.scanners.registry import build_index_scanners


def test_index_universe():
    assert len(NSE_INDEXES) == 6
    assert len(BSE_PLANNED_INDEXES) == 3
    assert len(build_index_scanners()) == 27


def test_mcx_groups():
    assert len(MCX_GROUPS) == 9
    assert "NATURAL_GAS" in MCX_GROUPS
    assert LOGICAL_SCANNER_GROUP_COUNT == 39
