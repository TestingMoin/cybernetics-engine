from __future__ import annotations

from datetime import date

from app.options.engine_adapter import OptionsEngineAdapter
from app.scanners.options.monitor import OptionChainRequest, OptionsSignalMonitor


def test_legacy_options_engine_loads() -> None:
    adapter = OptionsEngineAdapter()
    assert adapter.engine is not None


def test_monitors_keep_independent_state() -> None:
    a = OptionsSignalMonitor(OptionChainRequest("OPT-NIFTY", "NIFTY", 1, "IDX_I", date(2099, 1, 1)))
    b = OptionsSignalMonitor(OptionChainRequest("OPT-SENSEX", "SENSEX", 2, "IDX_I", date(2099, 1, 1)))
    assert a.last_snapshot is None
    assert b.last_snapshot is None
    assert a.request.scanner_id != b.request.scanner_id
    assert a.request.underlying != b.request.underlying
