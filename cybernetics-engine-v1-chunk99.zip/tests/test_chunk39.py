from datetime import datetime, timezone
from cybernetics.dispatch.events import MarketEvent
from cybernetics.dispatch.router import ScannerEventRouter, RoutingKey
from cybernetics.dispatch.builder import BindingSpec, bind_runtime
from cybernetics.scanners.models import ScannerRuntimeKey, ScannerState
from cybernetics.scanners.registry import ScannerRuntimeRegistry

def event(sec="101",seg="NSE_FNO",tf="1m"):
    return MarketEvent(sec,seg,"TICK",datetime(2026,1,1,9,15,tzinfo=timezone.utc),
                       {"ltp":100},tf)

def test_explicit_binding_routes_to_one_runtime():
    reg=ScannerRuntimeRegistry()
    k=ScannerRuntimeKey("ICE-NIFTY","NIFTY","1m")
    reg.create(k);reg.start(k)
    router=ScannerEventRouter(reg)
    router.bind(RoutingKey("NSE_FNO","101","1m"),k)
    d=router.route(event())
    assert d.delivered is True
    assert reg.get(k).event_count==1

def test_unrouted_event_is_rejected():
    router=ScannerEventRouter(ScannerRuntimeRegistry())
    d=router.route(event())
    assert d.delivered is False
    assert d.reason=="no_scanner_route"

def test_missing_timeframe_is_rejected():
    router=ScannerEventRouter(ScannerRuntimeRegistry())
    d=router.route(MarketEvent("101","NSE_FNO","TICK",
        datetime(2026,1,1,9,15,tzinfo=timezone.utc),{"ltp":100},None))
    assert d.reason=="event_timeframe_required"

def test_degraded_runtime_blocks_delivery():
    reg=ScannerRuntimeRegistry()
    k=ScannerRuntimeKey("ICE-NIFTY","NIFTY","1m")
    reg.create(k);reg.start(k);reg.degrade(k,"stale_feed")
    router=ScannerEventRouter(reg)
    router.bind(RoutingKey("NSE_FNO","101","1m"),k)
    d=router.route(event())
    assert d.delivered is False
    assert "DEGRADED" in d.reason

def test_different_security_ids_route_to_different_runtimes():
    reg=ScannerRuntimeRegistry()
    a=ScannerRuntimeKey("ICE-NIFTY","NIFTY","1m")
    b=ScannerRuntimeKey("ICE-NIFTY","BANKNIFTY","1m")
    reg.create(a);reg.create(b);reg.start(a);reg.start(b)
    router=ScannerEventRouter(reg)
    router.bind(RoutingKey("NSE_FNO","101","1m"),a)
    router.bind(RoutingKey("NSE_FNO","202","1m"),b)
    assert router.route(event("101")).runtime_key==a
    assert router.route(event("202")).runtime_key==b
    assert reg.get(a).event_count==1 and reg.get(b).event_count==1

def test_route_cannot_be_rebound_to_different_runtime():
    reg=ScannerRuntimeRegistry()
    a=ScannerRuntimeKey("S1","U1","1m")
    b=ScannerRuntimeKey("S2","U2","1m")
    reg.create(a);reg.create(b)
    router=ScannerEventRouter(reg)
    route=RoutingKey("NSE_FNO","101","1m")
    router.bind(route,a)
    try:
        router.bind(route,b);assert False
    except ValueError as e:
        assert str(e)=="routing_key_already_bound"

def test_builder_creates_explicit_runtime_key():
    reg=ScannerRuntimeRegistry()
    router=ScannerEventRouter(reg)
    k=ScannerRuntimeKey("ICE-SENSEX","SENSEX","5m")
    reg.create(k);reg.start(k)
    out=bind_runtime(router,BindingSpec("BSE_FNO","303","5m","ICE-SENSEX","SENSEX"))
    assert out==k
    assert router.get_runtime(RoutingKey("BSE_FNO","303","5m"))==k

def test_event_updates_runtime_state_only_on_delivery():
    reg=ScannerRuntimeRegistry()
    k=ScannerRuntimeKey("S","U","1m")
    reg.create(k);reg.start(k)
    router=ScannerEventRouter(reg)
    router.bind(RoutingKey("NSE_FNO","101","1m"),k)
    before=reg.get(k).event_count
    d=router.route(event("999"))
    assert d.delivered is False
    assert reg.get(k).event_count==before

def test_market_event_requires_dict_payload():
    try:
        MarketEvent("1","NSE_FNO","TICK",
            datetime(2026,1,1,9,15,tzinfo=timezone.utc),[], "1m")
        assert False
    except ValueError as e:
        assert str(e)=="market_event_payload_must_be_dict"
