from cybernetics.analytics.indicators import Bar, ema, rsi, atr, bollinger
from cybernetics.analytics.registry import default_registry
from cybernetics.analytics.state import AnalyticsStateEngine

def bars(n=40):
    out=[]
    p=100.0
    for i in range(n):
        o=p
        c=p+1.0
        out.append(Bar(i,o,c+0.5,o-0.25,c,1000+i))
        p=c
    return out

def test_indicators_have_values():
    b=bars()
    assert ema([x.close for x in b],5) is not None
    assert rsi(b,14) == 100.0
    assert atr(b,14) is not None
    assert bollinger(b,20,2)["upper"] >= bollinger(b,20,2)["middle"]

def test_registry():
    r=default_registry()
    assert r.get("EMA_5").parameters["length"] == 5
    assert len(r.enabled()) == 5

def test_state_and_regime():
    s=AnalyticsStateEngine().compute(bars())
    assert s.ema5 > s.ema15
    assert s.regime is not None
    assert s.regime.regime == "TREND_UP"

def test_short_history_is_safe():
    s=AnalyticsStateEngine().compute(bars(3))
    assert s.ema5 is None
    assert s.rsi14 is None
    assert s.regime.regime == "RANGE" or s.regime.regime == "UNKNOWN"

def test_no_signal_or_order_generation():
    assert not hasattr(AnalyticsStateEngine(), "place_order")
