from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timezone
from threading import Lock


@dataclass(frozen=True)
class ControlState:
    engine_running: bool = False
    live_authorized: bool = False
    kill_switch: bool = False
    emergency_stop: bool = False
    updated_at: str = ""
    updated_by: str = "system"


class ControlPlane:
    def __init__(self) -> None:
        self._lock = Lock()
        self._state = ControlState(updated_at=self._now())

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def snapshot(self) -> ControlState:
        with self._lock:
            return replace(self._state)

    def start_engine(self, actor: str) -> ControlState:
        with self._lock:
            self._state = replace(self._state, engine_running=True, emergency_stop=False,
                                  updated_at=self._now(), updated_by=actor)
            return self._state

    def stop_engine(self, actor: str) -> ControlState:
        with self._lock:
            self._state = replace(self._state, engine_running=False, live_authorized=False,
                                  updated_at=self._now(), updated_by=actor)
            return self._state

    def enable_live(self, actor: str) -> ControlState:
        with self._lock:
            if not self._state.engine_running:
                raise RuntimeError("Engine must be running before live authorization")
            if self._state.kill_switch or self._state.emergency_stop:
                raise RuntimeError("Cannot authorize live trading while a protective stop is active")
            self._state = replace(self._state, live_authorized=True, updated_at=self._now(), updated_by=actor)
            return self._state

    def disable_live(self, actor: str) -> ControlState:
        with self._lock:
            self._state = replace(self._state, live_authorized=False, updated_at=self._now(), updated_by=actor)
            return self._state

    def activate_kill_switch(self, actor: str) -> ControlState:
        with self._lock:
            self._state = replace(self._state, kill_switch=True, live_authorized=False,
                                  updated_at=self._now(), updated_by=actor)
            return self._state

    def emergency_stop_now(self, actor: str) -> ControlState:
        with self._lock:
            self._state = replace(self._state, emergency_stop=True, kill_switch=True,
                                  engine_running=False, live_authorized=False,
                                  updated_at=self._now(), updated_by=actor)
            return self._state
