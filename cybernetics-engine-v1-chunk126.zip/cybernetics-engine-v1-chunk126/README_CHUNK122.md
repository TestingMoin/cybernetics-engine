# Chunk 122 — Hostinger Staging Installer Hardening

Chunk 122 hardens the first real Hostinger Ubuntu staging installation boundary from Chunk 121.

## Changes

- Refuses installation when the persisted staging environment file is missing.
- Refuses installation unless the environment explicitly remains `staging` + `paper` + order submission disabled.
- Never overwrites the persisted environment file during release installation.
- Verifies release structure before switching `current`.
- Keeps the previous current release at `current.previous` for rollback.
- Validates the installed release self-check before starting systemd.
- Strengthens staging verification to assert the environment and runtime are both paper-safe.
- Updates the Hostinger runbook with the guarded installation/rollback sequence.

No remote VPS connection, PostgreSQL mutation, Dhan call, live authorization, or order submission was performed by this chunk.
