from __future__ import annotations

import os
from dataclasses import dataclass
from enum import StrEnum


class TradingMode(StrEnum):
    PAPER = "paper"
    SHADOW = "shadow"
    LIVE = "live"


@dataclass(frozen=True)
class Settings:
    environment: str
    trading_mode: TradingMode
    live_enabled: bool
    emergency_enabled: bool
    api_host: str
    api_port: int
    api_token: str
    dhan_client_id: str
    dhan_access_token: str
    database_url: str

    @classmethod
    def from_env(cls) -> "Settings":
        mode = TradingMode(os.getenv("TRADING_MODE", "paper").lower())
        live_enabled = os.getenv("LIVE_TRADING_ENABLED", "false").lower() == "true"
        emergency_enabled = os.getenv("EMERGENCY_TRADING_ENABLED", "false").lower() == "true"
        token = os.getenv("CONTROL_API_TOKEN", "")
        if not token:
            raise ValueError("CONTROL_API_TOKEN must be configured")
        if mode is TradingMode.LIVE and not live_enabled:
            raise ValueError("TRADING_MODE=live requires LIVE_TRADING_ENABLED=true")
        if mode is TradingMode.LIVE and emergency_enabled and not live_enabled:
            raise ValueError("EMERGENCY_TRADING_ENABLED cannot be true while live is disabled")
        return cls(
            environment=os.getenv("ENVIRONMENT", "production"),
            trading_mode=mode,
            live_enabled=live_enabled,
            emergency_enabled=emergency_enabled,
            api_host=os.getenv("CONTROL_API_HOST", "127.0.0.1"),
            api_port=int(os.getenv("CONTROL_API_PORT", "8080")),
            api_token=token,
            dhan_client_id=os.getenv("DHAN_CLIENT_ID", ""),
            dhan_access_token=os.getenv("DHAN_ACCESS_TOKEN", ""),
            database_url=os.getenv("DATABASE_URL", "sqlite:///./cybernetics.db"),
        )
