import pytest

from cybernetics.integration.contracts import (
    ModuleContract, IntegrationLayer, ContractViolation,
    DependencyAuditor, CORE_CONTRACTS
)
from cybernetics.integration.registry import IntegrationRegistry


def contract(mid, provides, requires=frozenset()):
    return ModuleContract(
        mid,
        IntegrationLayer.CONTROL,
        "1",
        frozenset(provides),
        frozenset(requires),
    )


def test_core_contracts_are_audited_ready():
    report=DependencyAuditor().audit(CORE_CONTRACTS)
    assert report.ready
    assert report.issues==()


def test_missing_provider_is_blocking():
    c=contract("consumer", {"x"}, {"missing"})
    report=DependencyAuditor().audit((c,))
    assert not report.ready
    assert report.issues[0].code=="MISSING_PROVIDER"


def test_ambiguous_provider_is_blocking():
    contracts=(
        contract("a", {"shared"}),
        contract("b", {"shared"}),
        contract("c", {"out"}, {"shared"}),
    )
    report=DependencyAuditor().audit(contracts)
    assert not report.ready
    assert any(i.code=="AMBIGUOUS_PROVIDER" for i in report.issues)


def test_duplicate_module_id_is_blocking():
    contracts=(
        contract("dup", {"a"}),
        contract("dup", {"b"}),
    )
    report=DependencyAuditor().audit(contracts)
    assert not report.ready
    assert any(i.code=="DUPLICATE_MODULE_ID" for i in report.issues)


def test_self_dependency_rejected_at_contract_creation():
    with pytest.raises(ContractViolation, match="self_dependency"):
        contract("self", {"x"}, {"x"})


def test_module_id_required():
    with pytest.raises(ContractViolation, match="module_id_required"):
        ModuleContract(
            "", IntegrationLayer.CONTROL, "1", frozenset({"x"}), frozenset()
        )


def test_version_required():
    with pytest.raises(ContractViolation, match="version_required"):
        ModuleContract(
            "x", IntegrationLayer.CONTROL, "", frozenset({"x"}), frozenset()
        )


def test_provides_required():
    with pytest.raises(ContractViolation, match="provides_required"):
        ModuleContract(
            "x", IntegrationLayer.CONTROL, "1", frozenset(), frozenset()
        )


def test_registry_rejects_duplicate_module():
    r=IntegrationRegistry()
    r.register(contract("x", {"a"}))
    with pytest.raises(ContractViolation, match="duplicate_module_id"):
        r.register(contract("x", {"b"}))


def test_registry_register_and_audit():
    r=IntegrationRegistry()
    r.register(contract("provider", {"a"}))
    r.register(contract("consumer", {"b"},{"a"}))
    assert r.audit().ready


def test_registry_graph_contains_dependency_edge():
    r=IntegrationRegistry()
    r.register(contract("provider", {"a"}))
    r.register(contract("consumer", {"b"},{"a"}))
    g=r.graph()
    assert len(g.edges)==1
    assert g.edges[0].consumer=="consumer"
    assert g.edges[0].provider=="provider"


def test_graph_omits_unresolved_dependency():
    r=IntegrationRegistry()
    r.register(contract("consumer", {"b"},{"missing"}))
    assert r.graph().edges==()


def test_production_eligibility_is_metadata_only():
    prod=ModuleContract(
        "p",IntegrationLayer.PERSISTENCE,"1",
        frozenset({"db"}),frozenset(),True
    )
    r=IntegrationRegistry()
    r.register(prod)
    assert r.production_eligible_modules()==("p",)


def test_core_contracts_cover_required_layers():
    layers={c.layer for c in CORE_CONTRACTS}
    assert IntegrationLayer.CONTROL in layers
    assert IntegrationLayer.PERSISTENCE in layers
    assert IntegrationLayer.MARKET_DATA in layers
    assert IntegrationLayer.UNIVERSE in layers
    assert IntegrationLayer.SCANNERS in layers
    assert IntegrationLayer.SIGNALS in layers
    assert IntegrationLayer.STRATEGY in layers
    assert IntegrationLayer.RISK in layers
    assert IntegrationLayer.EXECUTION in layers


def test_execution_requires_control_state():
    execution=next(c for c in CORE_CONTRACTS if c.module_id=="execution")
    assert "control.state" in execution.requires


def test_strategy_requires_qualified_signal():
    strategy=next(c for c in CORE_CONTRACTS if c.module_id=="strategy-risk")
    assert "signal.qualified" in strategy.requires


def test_no_broker_endpoints_in_integration_layer():
    from pathlib import Path
    for f in Path("src/cybernetics/integration").glob("*.py"):
        src=f.read_text()
        for token in ("/v2/orders","place_order","submit_order","cancel_order"):
            assert token not in src
