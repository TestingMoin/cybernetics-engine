from datetime import datetime, timedelta, timezone
from cybernetics.signals.lifecycle import (
    SignalLifecycleManager,SignalLifecycleState,InvalidationReason
)
from cybernetics.signals.qualification import SignalQualifier

BASE=datetime(2026,1,1,9,15,tzinfo=timezone.utc)

class Clock:
    def __init__(self,now): self.now=now
    def __call__(self): return self.now

def test_new_signal_is_observed_and_valid():
    c=Clock(BASE);m=SignalLifecycleManager(c)
    e=m.register("S1")
    assert e.state==SignalLifecycleState.OBSERVED and e.valid

def test_activation_moves_observed_to_active():
    c=Clock(BASE);m=SignalLifecycleManager(c)
    m.register("S1")
    e=m.activate("S1")
    assert e.state==SignalLifecycleState.ACTIVE and e.valid

def test_ttl_expires_signal():
    c=Clock(BASE);m=SignalLifecycleManager(c)
    m.register("S1",ttl=timedelta(minutes=5))
    c.now=BASE+timedelta(minutes=5)
    e=m.evaluate("S1")
    assert e.state==SignalLifecycleState.EXPIRED and not e.valid

def test_expired_signal_cannot_be_reactivated():
    c=Clock(BASE);m=SignalLifecycleManager(c)
    m.register("S1",ttl=timedelta(minutes=1))
    c.now=BASE+timedelta(minutes=1)
    m.evaluate("S1")
    assert m.activate("S1").state==SignalLifecycleState.EXPIRED

def test_invalidation_reason_is_preserved():
    m=SignalLifecycleManager(lambda:BASE);m.register("S1")
    e=m.invalidate("S1",InvalidationReason.DATA_STALE)
    assert e.state==SignalLifecycleState.INVALIDATED
    assert "DATA_STALE" in e.reason

def test_terminal_signal_is_not_reactivated_by_repeated_invalidate():
    m=SignalLifecycleManager(lambda:BASE);m.register("S1")
    m.invalidate("S1",InvalidationReason.MANUAL)
    rev=m.revision("S1")
    e=m.invalidate("S1",InvalidationReason.OPPOSITE_SIGNAL)
    assert e.state==SignalLifecycleState.INVALIDATED
    assert m.revision("S1")==rev

def test_supersession_links_old_to_new():
    m=SignalLifecycleManager(lambda:BASE)
    m.register("OLD");m.register("NEW")
    e=m.supersede("OLD","NEW")
    assert e.state==SignalLifecycleState.SUPERSEDED
    assert "NEW" in e.reason

def test_qualifier_rejects_expired_signal():
    c=Clock(BASE);m=SignalLifecycleManager(c)
    m.register("S1",ttl=timedelta(minutes=1))
    c.now=BASE+timedelta(minutes=2)
    q=SignalQualifier(m,minimum_strength=0.7)
    out=q.qualify("S1",strength=0.9)
    assert not out.qualified and "EXPIRED" in out.reason

def test_qualifier_requires_data_ready_and_scanner_health():
    m=SignalLifecycleManager(lambda:BASE);m.register("S1")
    q=SignalQualifier(m,minimum_strength=0.7)
    assert not q.qualify("S1",strength=0.9,scanner_healthy=False).qualified
    assert not q.qualify("S1",strength=0.9,data_ready=False).qualified

def test_qualifier_strength_gate():
    m=SignalLifecycleManager(lambda:BASE);m.register("S1")
    q=SignalQualifier(m,minimum_strength=0.7)
    out=q.qualify("S1",strength=0.69)
    assert not out.qualified and out.reason=="strength_below_threshold"

def test_qualifier_passes_active_signal():
    m=SignalLifecycleManager(lambda:BASE);m.register("S1");m.activate("S1")
    q=SignalQualifier(m,minimum_strength=0.7)
    out=q.qualify("S1",strength=0.9)
    assert out.qualified and out.reason=="qualified"

def test_duplicate_signal_registration_is_rejected():
    m=SignalLifecycleManager(lambda:BASE);m.register("S1")
    try:
        m.register("S1");assert False
    except ValueError as e: assert str(e)=="signal_already_registered"
