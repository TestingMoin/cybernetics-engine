import time
from cybernetics.signals.registry import SignalRegistry, make_signal
from cybernetics.signals.gateway import SignalGateway

def sig(**kwargs):
    base = dict(exchange="NSE", scanner_id="ICE-NIFTY", instrument="NIFTY",
                underlying="NIFTY", timeframe="1m", side="LONG", source="iceberg",
                score=.85, confidence=.90, regime="TREND_UP", ttl_seconds=60)
    base.update(kwargs)
    return make_signal(**base)

def test_publish_and_recent():
    r = SignalRegistry()
    s = sig()
    r.publish(s)
    assert r.count() == 1
    assert r.recent("NSE","ICE-NIFTY","NIFTY")

def test_gateway_accepts_valid_signal():
    r = SignalRegistry()
    d = SignalGateway(r).accept(sig(), minimum_score=.7, minimum_confidence=.8)
    assert d.accepted and r.count() == 1

def test_gateway_rejects_bad_confidence():
    d = SignalGateway(SignalRegistry()).accept(sig(confidence=1.5))
    assert not d.accepted
    assert "invalid_confidence" in d.reasons

def test_expiry():
    r = SignalRegistry()
    s = sig(timestamp=time.time()-10, ttl_seconds=1)
    r.publish(s)
    assert r.recent("NSE","ICE-NIFTY","NIFTY") == []
    assert r.clear_expired(now=time.time()) == 1
    assert r.count() == 0

def test_no_execution_surface():
    g = SignalGateway(SignalRegistry())
    assert not hasattr(g, "place_order")
