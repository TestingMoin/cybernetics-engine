from pathlib import Path
import json

def test_chunk128_benchmark_artifacts_exist():
    root = Path(__file__).resolve().parents[1]
    data = json.loads((root / 'performance' / 'benchmark.json').read_text())
    assert data['run_cycles'] == 100000
    assert data['startup_seconds'] >= 0
    assert data['cycle_mean_microseconds'] >= 0
    assert data['cycle_throughput_per_second'] > 0

