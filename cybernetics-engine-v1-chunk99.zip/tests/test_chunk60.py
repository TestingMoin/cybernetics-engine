from cybernetics.order.manager import (
    BrokerUpdate, OrderManager, OrderManagerStatus, OrderRecord
)
from cybernetics.order.restart import OrderRecoveryCoordinator


class FakeLedger:
    def __init__(self):
        self.by_key={}
        self.by_broker={}
        self.by_corr={}
    def get_by_client_order_key(self,k):
        return self.by_key.get(k)
    def get_by_broker_order_id(self,k):
        return self.by_broker.get(k)
    def get_by_correlation_id(self,k):
        return self.by_corr.get(k)
    def upsert_order(self,r):
        self.by_key[r.client_order_key]=r
        if r.broker_order_id: self.by_broker[r.broker_order_id]=r
        if r.correlation_id: self.by_corr[r.correlation_id]=r


def initial(status=OrderManagerStatus.ACTIVE):
    return OrderRecord(
        client_order_key="CK1",
        trade_id="T1",
        strategy_id="S1",
        underlying_key="NIFTY",
        broker_order_id="OID1",
        correlation_id="CORR1",
        quantity=10,
        filled_quantity=0,
        remaining_quantity=10,
        average_price=None,
        status=status,
    )


def setup():
    l=FakeLedger()
    l.upsert_order(initial())
    return l,OrderManager(l)


def test_partial_fill_persisted():
    l,m=setup()
    r=m.apply_broker_update(BrokerUpdate(
        "OID1","CORR1",OrderManagerStatus.PARTIAL,4,6,101.0
    ))
    assert r.status==OrderManagerStatus.PARTIAL
    assert r.filled_quantity==4
    assert l.by_key["CK1"].filled_quantity==4


def test_full_fill_persisted():
    _,m=setup()
    r=m.apply_broker_update(BrokerUpdate(
        "OID1","CORR1",OrderManagerStatus.FILLED,10,0,101.25
    ))
    assert r.status==OrderManagerStatus.FILLED
    assert r.filled_quantity==10


def test_duplicate_update_is_idempotent():
    _,m=setup()
    u=BrokerUpdate("OID1","CORR1",OrderManagerStatus.PARTIAL,4,6,101)
    a=m.apply_broker_update(u)
    b=m.apply_broker_update(u)
    assert a==b
    assert b.version==1


def test_terminal_regression_rejected():
    _,m=setup()
    m.apply_broker_update(BrokerUpdate("OID1","CORR1",OrderManagerStatus.FILLED,10,0,101))
    try:
        m.apply_broker_update(BrokerUpdate("OID1","CORR1",OrderManagerStatus.ACTIVE,0,10,None))
        assert False
    except ValueError as exc:
        assert str(exc)=="terminal_order_state_regression"


def test_filled_quantity_regression_rejected():
    _,m=setup()
    m.apply_broker_update(BrokerUpdate("OID1","CORR1",OrderManagerStatus.PARTIAL,6,4,101))
    try:
        m.apply_broker_update(BrokerUpdate("OID1","CORR1",OrderManagerStatus.PARTIAL,4,6,101))
        assert False
    except ValueError as exc:
        assert str(exc)=="filled_quantity_regression"


def test_filled_quantity_cannot_exceed_order_quantity():
    _,m=setup()
    try:
        m.apply_broker_update(BrokerUpdate("OID1","CORR1",OrderManagerStatus.FILLED,11,0,101))
        assert False
    except ValueError as exc:
        assert str(exc)=="filled_quantity_exceeds_order_quantity"


def test_correlation_can_resolve_order_when_broker_id_not_indexed():
    l,m=setup()
    del l.by_broker["OID1"]
    r=m.apply_broker_update(BrokerUpdate("OID1","CORR1",OrderManagerStatus.PARTIAL,2,8,100.5))
    assert r.filled_quantity==2


def test_unknown_without_resolution_is_persisted():
    l,m=setup()
    r=m.reconcile_unknown(client_order_key="CK1",broker_order_id="OID1",resolved_update=None)
    assert r.status==OrderManagerStatus.UNKNOWN
    assert l.by_key["CK1"].status==OrderManagerStatus.UNKNOWN


def test_unknown_resolution_updates_order():
    _,m=setup()
    m.reconcile_unknown(client_order_key="CK1",broker_order_id="OID1",resolved_update=None)
    r=m.reconcile_unknown(
        client_order_key="CK1",
        broker_order_id="OID1",
        resolved_update=BrokerUpdate("OID1","CORR1",OrderManagerStatus.FILLED,10,0,102)
    )
    assert r.status==OrderManagerStatus.FILLED


def test_unknown_resolution_id_mismatch_rejected():
    _,m=setup()
    m.reconcile_unknown(client_order_key="CK1",broker_order_id="OID1",resolved_update=None)
    try:
        m.reconcile_unknown(
            client_order_key="CK1",
            broker_order_id="OID2",
            resolved_update=BrokerUpdate("OID1","CORR1",OrderManagerStatus.FILLED,10,0,102)
        )
        assert False
    except ValueError as exc:
        assert str(exc)=="unknown_resolution_broker_id_mismatch"


def test_unknown_order_not_found_rejected():
    l=FakeLedger()
    m=OrderManager(l)
    try:
        m.reconcile_unknown(client_order_key="NOPE",broker_order_id=None,resolved_update=None)
        assert False
    except LookupError as exc:
        assert str(exc)=="client_order_key_not_found"


def test_broker_update_not_found():
    l=FakeLedger()
    m=OrderManager(l)
    try:
        m.apply_broker_update(BrokerUpdate("OID9","CORR9",OrderManagerStatus.PARTIAL,1,9,100))
        assert False
    except LookupError as exc:
        assert str(exc)=="broker_update_order_not_found"


def test_startup_recovery_summary():
    records=[
        initial(OrderManagerStatus.ACTIVE),
        OrderRecord("CK2","T2","S2","BANKNIFTY","OID2","C2",10,5,5,100,OrderManagerStatus.PARTIAL),
        OrderRecord("CK3","T3","S3","NIFTY",None,"C3",10,0,10,None,OrderManagerStatus.UNKNOWN),
        OrderRecord("CK4","T4","S4","NIFTY","OID4","C4",10,10,0,101,OrderManagerStatus.FILLED),
        OrderRecord("CK5","T5","S5","NIFTY","OID5","C5",10,0,10,None,OrderManagerStatus.REJECTED),
    ]
    s=OrderRecoveryCoordinator().recover(records)
    assert s.loaded_orders==5
    assert s.active_orders==2
    assert s.unknown_orders==1
    assert s.terminal_orders==2
