from datetime import datetime, timezone, timedelta
from cybernetics.signals.lifecycle import SignalLifecycleManager
from cybernetics.strategy.engine import StrategyEngine, deterministic_direction_strategy
from cybernetics.strategy.models import DecisionType
from cybernetics.execution.instrument import TradeInstrument, InstrumentType, InstrumentEligibility
from cybernetics.integration.reconciled_path import build_preview

NOW=datetime(2026,9,7,9,30,tzinfo=timezone.utc)
EL=InstrumentEligibility(True,True,True,True)

def instr():
    return TradeInstrument("NSE_FNO","999","NIFTY",InstrumentType.INDEX,
                           lot_size=50,tick_size=.05,contract_multiplier=1.0,
                           eligibility=EL)
def lm(sid,ttl=60):
    m=SignalLifecycleManager(now=lambda: NOW)
    m.register(sid,created_at=NOW,ttl=timedelta(seconds=ttl)); m.activate(sid); return m
def eng():
    e=StrategyEngine(); e.register(deterministic_direction_strategy("STRAT-1")); return e

def test_buy_path():
    o=build_preview(lifecycle=lm("S1"),strategy_engine=eng(),strategy_id="STRAT-1",
                     signal_id="S1",instrument=instr(),timestamp=NOW,direction="BUY",strength=.9)
    assert o.decision is DecisionType.ENTER_LONG and o.payload["transactionType"]=="BUY"
    assert o.payload["securityId"]=="999"

def test_sell_path():
    o=build_preview(lifecycle=lm("S2"),strategy_engine=eng(),strategy_id="STRAT-1",
                     signal_id="S2",instrument=instr(),timestamp=NOW,direction="SELL",strength=.8)
    assert o.decision is DecisionType.ENTER_SHORT and o.payload["transactionType"]=="SELL"

def test_expired_signal_blocked():
    t={"v":NOW}; m=SignalLifecycleManager(now=lambda:t["v"])
    m.register("S3",created_at=NOW,ttl=timedelta(seconds=1)); m.activate("S3"); t["v"]=NOW+timedelta(seconds=2)
    try:
        build_preview(lifecycle=m,strategy_engine=eng(),strategy_id="STRAT-1",
                      signal_id="S3",instrument=instr(),timestamp=t["v"],direction="BUY",strength=.9)
        assert False
    except PermissionError as e: assert str(e)=="signal_not_valid"

def test_allows_canonical_chain_without_http_submission():
    o=build_preview(lifecycle=lm("S4"),strategy_engine=eng(),strategy_id="STRAT-1",
                    signal_id="S4",instrument=instr(),timestamp=NOW,direction="BUY",strength=.7)
    assert o.intent_id and o.security_id=="999"
    from pathlib import Path
    txt=Path("src/cybernetics/integration/reconciled_path.py").read_text()
    assert "/v2/orders" not in txt and "requests." not in txt and "httpx." not in txt

def test_no_live_token_or_secret_in_preview():
    from pathlib import Path
    txt=Path("src/cybernetics/integration/reconciled_path.py").read_text()
    assert "access_token" not in txt and "api_secret" not in txt
