from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ScannerConfig:
    scanner_id: str
    scanner_name: str
    group_id: str
    underlying: str | None
    asset_types: tuple[str, ...]
    timeframes: tuple[str, ...]
    enabled: bool
    options_requirement: str
    risk_profile: str



def build_index_scanners() -> tuple[ScannerConfig, ...]:
    symbols = (
        "NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "NIFTYNXT50", "NIFTYFPI",
        "SENSEX", "BANKEX", "SENSEX50",
    )
    out: list[ScannerConfig] = []
    for symbol in symbols:
        for kind in ("ICEBERG", "OPTIONS", "GAP"):
            out.append(
                ScannerConfig(
                    scanner_id=f"{kind[:3]}-{symbol}",
                    scanner_name=f"{kind.title()} {symbol}",
                    group_id=f"INDEX-{symbol}",
                    underlying=symbol,
                    asset_types=("INDEX",),
                    timeframes=("1m", "5m", "15m"),
                    enabled=True,
                    options_requirement="required" if kind == "OPTIONS" else "not_required",
                    risk_profile="index-default",
                )
            )
    return tuple(out)
