# Cybernetics Trading Engine — Chunk 34

## Market-Data Gap Detector + State Recovery Coordinator

This chunk closes the gap between feed-health monitoring and canonical market state.

### Flow

Live feed → canonical timestamps → gap detector → REST recovery → dedupe → atomic merge
→ verify → market-state-ready.

### Safety rules

- The detector works only on already-normalized timestamps.
- The caller owns exchange session/calendar knowledge.
- Recovery rows are deduplicated by timestamp before merge.
- An unresolved gap leaves the affected market state NOT READY.
- Recovery failures do not get treated as successful.
- Permission failures are explicitly BLOCKED.
- No trading order is created by this component.

The REST fetch implementation is injected, allowing Chunk 31's Dhan historical/intraday
client and Chunk 30 transport/rate-limiter to be connected without duplicating them.
