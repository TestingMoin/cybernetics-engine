from cybernetics.persistence.outbox_worker import (
    DurableOutboxWorker, WorkerConfig, OutboxItem
)
from cybernetics.persistence.postgres_outbox import PostgresOutboxRepository
import pytest


class Result:
    def __init__(self, rowcount=1): self.rowcount = rowcount


class FakeTx:
    def __init__(self, rows=None, rowcount=1, count=0):
        self.rows = rows or []
        self.rowcount = rowcount
        self.count = count
        self.calls = []

    def fetchall(self, sql, params=()):
        self.calls.append(("fetchall", sql, params))
        return self.rows

    def fetchone(self, sql, params=()):
        self.calls.append(("fetchone", sql, params))
        return (self.count,)

    def execute(self, sql, params=()):
        self.calls.append(("execute", sql, params))
        return Result(self.rowcount)


class FakeRepo:
    def __init__(self, items=None):
        self.items = items or []
        self.calls = []

    def claim_outbox_batch(self, limit=100):
        self.calls.append(("claim", limit))
        return self.items

    def complete_outbox(self, event_id):
        self.calls.append(("complete", event_id))
        return True

    def fail_outbox(self, event_id, error):
        self.calls.append(("fail", event_id, error))
        return True

    def recover_stale_processing(self, max_age_seconds):
        self.calls.append(("recover", max_age_seconds))
        return 2

    def pending_count(self):
        return 3


def item(attempts=1):
    return OutboxItem("E1","F1","O1","T1",{"x":1},attempts)


def test_config_rejects_invalid_batch():
    with pytest.raises(ValueError, match="batch_size"):
        WorkerConfig(batch_size=0)


def test_config_rejects_invalid_attempts():
    with pytest.raises(ValueError, match="max_attempts"):
        WorkerConfig(max_attempts=0)


def test_config_rejects_invalid_stale_age():
    with pytest.raises(ValueError, match="stale_after"):
        WorkerConfig(stale_after_seconds=0)


def test_success_completes():
    repo = FakeRepo([item(1)])
    result = DurableOutboxWorker(repo).run_once(lambda x: None)
    assert result[0].status == "COMPLETED"
    assert ("complete","E1") in repo.calls


def test_handler_error_below_limit_is_retryable_failure():
    repo = FakeRepo([item(1)])
    result = DurableOutboxWorker(repo, WorkerConfig(max_attempts=3)).run_once(
        lambda x: (_ for _ in ()).throw(RuntimeError("boom"))
    )
    assert result[0].status == "RETRYABLE_FAILURE"
    assert any(c[0] == "fail" for c in repo.calls)


def test_handler_error_at_limit_is_failed():
    repo = FakeRepo([item(3)])
    result = DurableOutboxWorker(repo, WorkerConfig(max_attempts=3)).run_once(
        lambda x: (_ for _ in ()).throw(RuntimeError("boom"))
    )
    assert result[0].status == "FAILED"


def test_preclaimed_max_attempt_is_not_dispatched():
    repo = FakeRepo([item(3)])
    seen = []
    result = DurableOutboxWorker(repo, WorkerConfig(max_attempts=3)).run_once(
        lambda x: seen.append(x)
    )
    assert seen == []
    assert result[0].status == "FAILED"


def test_stale_recovery_delegates_to_repository():
    repo = FakeRepo()
    assert DurableOutboxWorker(repo, WorkerConfig(stale_after_seconds=60)).recover_stale() == 2
    assert ("recover",60) in repo.calls


def test_postgres_claim_uses_skip_locked():
    tx = FakeTx(rows=[("E1","F1","O1","T1",{"x":1},1)])
    repo = PostgresOutboxRepository(tx)
    got = repo.claim_outbox_batch(10)
    assert got[0].event_id == "E1"
    assert "SKIP LOCKED" in tx.calls[0][1]


def test_postgres_claim_rejects_nonpositive_limit():
    with pytest.raises(ValueError, match="limit"):
        PostgresOutboxRepository(FakeTx()).claim_outbox_batch(0)


def test_postgres_completion_requires_processing():
    tx = FakeTx(rowcount=1)
    assert PostgresOutboxRepository(tx).complete_outbox("E1")
    assert "state='PROCESSING'" in tx.calls[0][1]


def test_postgres_failure_is_durable():
    tx = FakeTx(rowcount=1)
    assert PostgresOutboxRepository(tx).fail_outbox("E1","handler failed")
    assert "state='FAILED'" in tx.calls[0][1]


def test_postgres_stale_recovery_moves_processing_to_pending():
    tx = FakeTx(rowcount=4)
    assert PostgresOutboxRepository(tx).recover_stale_processing(300) == 4
    assert "state='PENDING'" in tx.calls[0][1]


def test_postgres_pending_count():
    tx = FakeTx(count=7)
    assert PostgresOutboxRepository(tx).pending_count() == 7


def test_completion_unknown_is_not_hidden():
    class UnknownRepo(FakeRepo):
        def complete_outbox(self, event_id): return False
    repo = UnknownRepo([item(1)])
    result = DurableOutboxWorker(repo).run_once(lambda x: None)
    assert result[0].status == "COMPLETION_UNKNOWN"


def test_handler_receives_original_payload():
    got=[]
    repo=FakeRepo([item(1)])
    DurableOutboxWorker(repo).run_once(lambda x: got.append(dict(x.payload)))
    assert got == [{"x":1}]
