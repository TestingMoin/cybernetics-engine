from datetime import datetime, timezone, timedelta
from cybernetics.signals.lifecycle import SignalLifecycleManager
from cybernetics.signals.qualification import SignalQualifier
from cybernetics.strategy.engine import StrategyEngine, deterministic_direction_strategy
from cybernetics.strategy.integration import QualifiedSignalStrategyBridge
from cybernetics.strategy.models import DecisionType, StrategyDecision

T=datetime(2026,1,1,9,15,tzinfo=timezone.utc)

def setup():
    lifecycle=SignalLifecycleManager(lambda:T)
    lifecycle.register("S1")
    qualifier=SignalQualifier(lifecycle,minimum_strength=0.7)
    engine=StrategyEngine()
    engine.register(deterministic_direction_strategy("GOLDEN-TEST"))
    bridge=QualifiedSignalStrategyBridge(lifecycle,qualifier,engine)
    return lifecycle,bridge,engine

def test_qualified_buy_signal_creates_long_decision():
    _,bridge,_=setup()
    out=bridge.evaluate("GOLDEN-TEST",signal_id="S1",scanner_id="ICE-NIFTY",
        underlying_key="NIFTY",timeframe="1m",timestamp=T,direction="BUY",strength=0.9)
    assert out.accepted
    assert out.decision.decision==DecisionType.ENTER_LONG
    assert out.decision.signal_id=="S1"

def test_qualified_sell_signal_creates_short_decision():
    lifecycle,bridge,_=setup()
    lifecycle.register("S2")
    out=bridge.evaluate("GOLDEN-TEST",signal_id="S2",scanner_id="ICE-NIFTY",
        underlying_key="NIFTY",timeframe="1m",timestamp=T,direction="SELL",strength=0.9)
    assert out.decision.decision==DecisionType.ENTER_SHORT

def test_low_strength_signal_never_reaches_strategy():
    _,bridge,_=setup()
    out=bridge.evaluate("GOLDEN-TEST",signal_id="S1",scanner_id="ICE-NIFTY",
        underlying_key="NIFTY",timeframe="1m",timestamp=T,direction="BUY",strength=0.69)
    assert not out.accepted
    assert out.decision is None
    assert out.reason=="strength_below_threshold"

def test_unhealthy_scanner_blocks_strategy():
    _,bridge,_=setup()
    out=bridge.evaluate("GOLDEN-TEST",signal_id="S1",scanner_id="ICE-NIFTY",
        underlying_key="NIFTY",timeframe="1m",timestamp=T,direction="BUY",strength=0.9,
        scanner_healthy=False)
    assert not out.accepted and out.reason=="scanner_unhealthy"

def test_stale_signal_is_blocked():
    lifecycle,bridge,_=setup()
    lifecycle.evaluate("S1",T+timedelta(hours=1))
    out=bridge.evaluate("GOLDEN-TEST",signal_id="S1",scanner_id="ICE-NIFTY",
        underlying_key="NIFTY",timeframe="1m",timestamp=T,direction="BUY",strength=0.9)
    # No TTL was set; the signal remains valid. This verifies that lifecycle
    # evaluation alone does not invent staleness.
    assert out.accepted

def test_strategy_definition_version_is_preserved():
    _,_,engine=setup()
    assert engine.get("GOLDEN-TEST").version=="1.0.0"

def test_duplicate_strategy_id_is_rejected():
    e=StrategyEngine()
    d=deterministic_direction_strategy("S1")
    e.register(d)
    try:
        e.register(d);assert False
    except ValueError as exc:
        assert str(exc)=="strategy_already_registered"

def test_decision_identity_mismatch_is_rejected():
    e=StrategyEngine()
    e.register(deterministic_direction_strategy("S1"))
    def bad(ctx):
        return StrategyDecision("D","OTHER","S1",DecisionType.NO_ACTION,T,"bad",0.1)
    from types import SimpleNamespace
    e.register(SimpleNamespace(strategy_id="S2",version="1.0",evaluate=bad))
    try:
        e.evaluate("S2",type("C",(),{"signal_id":"S1"})())
        assert False
    except ValueError as exc:
        assert str(exc)=="strategy_decision_strategy_id_mismatch"

def test_strategy_decision_does_not_contain_broker_fields():
    _,bridge,_=setup()
    out=bridge.evaluate("GOLDEN-TEST",signal_id="S1",scanner_id="ICE-NIFTY",
        underlying_key="NIFTY",timeframe="1m",timestamp=T,direction="BUY",strength=0.9)
    assert not hasattr(out.decision,"broker_order_id")
    assert not hasattr(out.decision,"quantity")

def test_unknown_strategy_is_blocked_without_decision():
    _,bridge,_=setup()
    out=bridge.evaluate("NO-SUCH",signal_id="S1",scanner_id="ICE-NIFTY",
        underlying_key="NIFTY",timeframe="1m",timestamp=T,direction="BUY",strength=0.9)
    assert not out.accepted
    assert out.decision is None
    assert "strategy_error" in out.reason
