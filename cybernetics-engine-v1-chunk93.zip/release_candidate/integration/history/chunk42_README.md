# Cybernetics Trading Engine — Chunk 42

## Indicator-State Adapter

Connects the versioned individual-indicator registry to isolated per-scanner runtime state.

### Responsibilities
- Own per-(security_id, timeframe) rolling history.
- Execute registered indicators incrementally on each candle.
- Apply deterministic default parameter sets for the standard registry.
- Record current indicator values and readiness.
- Bound retained history.
- Reject invalid OHLCV inputs.
- Fail explicitly when a registered indicator is not supported by the adapter.

The adapter does not generate signals, confluence, strategy decisions, or broker orders.

A later integration will connect Chunk 39 routing → scanner runtime → this adapter →
existing Signal Registry.
