from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator, Protocol


class Connection(Protocol):
    def transaction(self): ...


@contextmanager
def atomic_fill_transaction(connection: Connection) -> Iterator[Any]:
    """
    Transaction boundary for a fill + ledger/outbox operation.

    This wrapper intentionally does not open/close the pool or decide retry
    policy. The caller owns connection acquisition and release.
    """
    with connection.transaction() as tx:
        yield tx
