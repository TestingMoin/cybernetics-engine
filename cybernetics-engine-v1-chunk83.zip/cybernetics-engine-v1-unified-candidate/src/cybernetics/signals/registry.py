from dataclasses import dataclass, field
from enum import Enum

class SignalState(str, Enum):
    OBSERVED="OBSERVED"
    ACTIVE="ACTIVE"
    INVALIDATED="INVALIDATED"
    EXPIRED="EXPIRED"

@dataclass(frozen=True)
class SignalRecord:
    signal_id: str
    scanner_id: str
    underlying_key: str
    timeframe: str
    timestamp: object
    signal_type: str
    direction: str | None
    strength: float
    evidence: dict = field(default_factory=dict)
    state: SignalState = SignalState.OBSERVED

    def __post_init__(self):
        if not self.signal_id or not self.scanner_id or not self.underlying_key:
            raise ValueError("signal_identity_required")
        if not 0 <= self.strength <= 1:
            raise ValueError("signal_strength_out_of_range")

class SignalRegistry:
    def __init__(self):
        self._items={}
    def register(self, signal):
        if signal.signal_id in self._items:
            raise ValueError("duplicate_signal_id")
        self._items[signal.signal_id]=signal
        return signal
    def get(self, signal_id):
        if signal_id not in self._items: raise KeyError("signal_not_found")
        return self._items[signal_id]
    def list(self):
        return list(self._items.values())
