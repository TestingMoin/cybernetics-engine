from __future__ import annotations
from dataclasses import dataclass
from threading import RLock
from typing import Optional

@dataclass(frozen=True)
class IdempotencyRecord:
    client_order_key: str
    broker_order_id: Optional[str]
    status: str

class IdempotencyStore:
    """Thread-safe in-memory foundation; persistent backing is a later integration point."""
    def __init__(self):
        self._records: dict[str, IdempotencyRecord] = {}
        self._lock = RLock()

    def get(self, key: str) -> Optional[IdempotencyRecord]:
        with self._lock:
            return self._records.get(key)

    def put_once(self, record: IdempotencyRecord) -> bool:
        with self._lock:
            if record.client_order_key in self._records:
                return False
            self._records[record.client_order_key] = record
            return True

    def update(self, record: IdempotencyRecord) -> None:
        with self._lock:
            if record.client_order_key not in self._records:
                raise KeyError("unknown_client_order_key")
            self._records[record.client_order_key] = record
