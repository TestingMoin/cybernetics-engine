import pytest
from pathlib import Path

from cybernetics.config import ConfigValidationError, DeploymentConfig
from cybernetics.config.settings import TradingMode


def test_defaults_are_fail_closed():
    c = DeploymentConfig.from_env({})
    assert c.trading_mode is TradingMode.PAPER
    assert c.order_submission_enabled is False
    assert c.live_authorization_configured is False


def test_live_requires_production():
    with pytest.raises(ConfigValidationError, match="live_mode_requires_production_environment"):
        DeploymentConfig.from_env({"CYBERNETICS_TRADING_MODE": "live", "CYBERNETICS_LIVE_APPROVAL_ID": "A"})


def test_live_requires_approval_id():
    with pytest.raises(ConfigValidationError, match="live_mode_requires_approval_id"):
        DeploymentConfig.from_env({"CYBERNETICS_TRADING_MODE": "live", "CYBERNETICS_ENV": "production"})


def test_order_submission_requires_live():
    with pytest.raises(ConfigValidationError, match="order_submission_requires_live_mode"):
        DeploymentConfig.from_env({"CYBERNETICS_ORDER_SUBMISSION_ENABLED": "true"})


def test_order_submission_requires_approval():
    with pytest.raises(ConfigValidationError, match="order_submission_requires_approval_id"):
        DeploymentConfig.from_env({
            "CYBERNETICS_ENV": "production",
            "CYBERNETICS_TRADING_MODE": "live",
            "CYBERNETICS_ORDER_SUBMISSION_ENABLED": "true",
        })


def test_valid_live_configuration_is_explicit():
    c = DeploymentConfig.from_env({
        "CYBERNETICS_ENV": "production",
        "CYBERNETICS_TRADING_MODE": "live",
        "CYBERNETICS_LIVE_APPROVAL_ID": "APP-1",
        "CYBERNETICS_ORDER_SUBMISSION_ENABLED": "true",
    })
    assert c.live_authorization_configured is True
    assert c.order_submission_enabled is True


def test_bad_mode_rejected():
    with pytest.raises(ConfigValidationError, match="invalid_trading_mode"):
        DeploymentConfig.from_env({"CYBERNETICS_TRADING_MODE": "rocket"})


def test_bad_boolean_rejected():
    with pytest.raises(ConfigValidationError, match="invalid_boolean"):
        DeploymentConfig.from_env({"CYBERNETICS_ORDER_SUBMISSION_ENABLED": "maybe"})


def test_bad_poll_rejected():
    with pytest.raises(ConfigValidationError, match="runtime_poll_seconds_must_be_positive"):
        DeploymentConfig.from_env({"CYBERNETICS_RUNTIME_POLL_SECONDS": "0"})


def test_filesystem_validation_rejects_file(tmp_path: Path):
    f = tmp_path / "data"
    f.write_text("x")
    c = DeploymentConfig(data_dir=f)
    with pytest.raises(ConfigValidationError, match="data_dir_not_directory"):
        c.validate_filesystem()
