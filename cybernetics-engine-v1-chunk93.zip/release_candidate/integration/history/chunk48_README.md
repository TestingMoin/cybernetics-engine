# Cybernetics Trading Engine — Chunk 48

## Strategy Exit & Trade Lifecycle Integration

This chunk adds the strategy-side lifecycle boundary connecting decisions to
trade lifecycle intent.

Lifecycle:

FLAT -> ENTRY_DECIDED -> ENTRY_PENDING -> OPEN
OPEN -> EXIT_DECIDED -> EXIT_PENDING -> CLOSED

Invalid transitions become BLOCKED and cannot be applied.

The bridge is intentionally execution-free. It does not:
- place/cancel orders
- calculate quantity
- bypass Risk or Pre-Trade
- call Dhan
- mutate broker state

The execution coordinator remains the only appropriate boundary for broker
submission. Actual broker fills/reconciliation should be the authoritative
source used later to reconcile lifecycle state.
