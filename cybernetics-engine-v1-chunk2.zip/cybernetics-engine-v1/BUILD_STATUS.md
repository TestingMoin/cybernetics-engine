# Cybernetics Trading Engine — Build Status

## Chunk 1
- Foundation repository created.
- Paper-first controls.
- Configuration-driven scanner registry/universe foundation.
- Tests: 5/5 previously passing.

## Chunk 2 — completed in local build
- Dhan 24-hour TOTP token manager (secrets never logged).
- Central Dhan API rate-limit governor.
- Async SQLAlchemy database foundation for SQLite/PostgreSQL.
- Dhan detailed/compact instrument-master downloader with atomic file replacement.
- Settings extended for Dhan PIN/TOTP and instrument-master path.
- Dhan current documented limits wired into local governor: Order 10/sec, 250/min, 1000/hr, 7000/day; Data 5/sec, 100000/day; Quote 1/sec; Non-trading 20/sec.

## Safety
- Live trading remains OFF.
- No broker order transport is enabled by this chunk.
- No credentials or access tokens are included in source.
