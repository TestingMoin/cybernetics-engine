# Cybernetics Trading Engine — Chunk 53

## Execution Command Builder & Broker-Neutral Order Intent

This chunk converts a **successful Pre-Trade approval** into an immutable,
broker-neutral `ExecutionIntent`.

Flow:

Pre-Trade APPROVED
→ ExecutionIntentBuilder
→ ExecutionIntent
→ Broker adapter (later)

The intent contains only broker-neutral execution information:
- trade/strategy/signal identity
- underlying
- BUY/SELL action
- MARKET/LIMIT order type
- approved quantity
- limit price when required
- product type
- validity
- auditable metadata

It intentionally does NOT contain Dhan-specific fields such as security IDs,
correlation IDs, access tokens, or HTTP payloads.

Safety:
- pre-trade approval is mandatory
- quantity must be positive
- LIMIT orders require a positive limit price
- MARKET orders cannot carry a limit price
- unsupported actions/order types are rejected

No order is submitted by this chunk.
