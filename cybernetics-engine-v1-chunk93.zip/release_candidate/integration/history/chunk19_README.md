# Cybernetics Trading Engine — Chunk 19

Emergency Controls + Safe Recovery + Atomic Checkpoints.

Control states:
- RUNNING
- STOP_NEW_TRADES
- EMERGENCY_STOP

Live authorization is independent and defaults OFF.

Recovery requires all stages to pass before returning READY:
load state -> broker check -> reconcile -> restore data -> restore strategies.

Any failure leaves new trades disabled.
No broker mutation is performed here.
