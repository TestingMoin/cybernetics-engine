from cybernetics.trading.unified_fill import (
    CanonicalFillRecord, UnifiedFillProcessor, UnifiedFillState, InMemoryDurability
)

class Consumer:
    def __init__(self, name, fail=False):
        self.name=name
        self.fail=fail
        self.calls=[]
    def apply(self, fill):
        if self.fail:
            raise RuntimeError(f"{self.name}_failure")
        self.calls.append(fill.fill_id)

def make(fid="F1", qty=10, price=100, side="BUY"):
    return CanonicalFillRecord(fid,"O1","T1","NIFTY",side,qty,price,1.5)

def setup(*, order=None, position=None, lifecycle=None, durability=None):
    return UnifiedFillProcessor(
        durability=durability or InMemoryDurability(),
        order_consumer=order or Consumer("order"),
        position_consumer=position or Consumer("position"),
        lifecycle_consumer=lifecycle or Consumer("lifecycle"),
    )

def test_single_canonical_path_reaches_all_consumers_in_order():
    d=InMemoryDurability()
    o,p,l=Consumer("order"),Consumer("position"),Consumer("lifecycle")
    result=setup(order=o,position=p,lifecycle=l,durability=d).process(make())
    assert result.state==UnifiedFillState.ACCEPTED
    assert o.calls==["F1"] and p.calls==["F1"] and l.calls==["F1"]
    assert d.states["F1"]=="COMPLETED"

def test_second_application_is_duplicate():
    d=InMemoryDurability()
    x=setup(durability=d)
    assert x.process(make()).state==UnifiedFillState.ACCEPTED
    assert x.process(make()).state==UnifiedFillState.DUPLICATE

def test_claimed_state_requires_recovery():
    d=InMemoryDurability()
    d.states["F1"]="CLAIMED"
    assert setup(durability=d).process(make()).state==UnifiedFillState.RECOVERY_REQUIRED

def test_recovery_required_state_cannot_replay():
    d=InMemoryDurability()
    d.states["F1"]="RECOVERY_REQUIRED"
    o=Consumer("order")
    result=setup(order=o,durability=d).process(make())
    assert result.state==UnifiedFillState.RECOVERY_REQUIRED
    assert o.calls==[]

def test_order_failure_records_recovery():
    d=InMemoryDurability()
    r=setup(order=Consumer("order",True),durability=d).process(make())
    assert r.state==UnifiedFillState.RECOVERY_REQUIRED
    assert d.states["F1"]=="RECOVERY_REQUIRED"
    assert "order_failure" in d.errors["F1"]

def test_position_failure_prevents_lifecycle_application():
    d=InMemoryDurability()
    o,p,l=Consumer("order"),Consumer("position",True),Consumer("lifecycle")
    r=setup(order=o,position=p,lifecycle=l,durability=d).process(make())
    assert r.state==UnifiedFillState.RECOVERY_REQUIRED
    assert o.calls==["F1"]
    assert p.calls==[]
    assert l.calls==[]

def test_lifecycle_failure_records_recovery_after_prior_application():
    d=InMemoryDurability()
    o,p,l=Consumer("order"),Consumer("position"),Consumer("lifecycle",True)
    r=setup(order=o,position=p,lifecycle=l,durability=d).process(make())
    assert r.state==UnifiedFillState.RECOVERY_REQUIRED
    assert o.calls==["F1"] and p.calls==["F1"]

def test_completion_failure_never_blindly_replays_downstream():
    class CompletionFail(InMemoryDurability):
        def complete(self, fill_id):
            raise RuntimeError("db_completion_failure")
    d=CompletionFail()
    o,p,l=Consumer("order"),Consumer("position"),Consumer("lifecycle")
    r=setup(order=o,position=p,lifecycle=l,durability=d).process(make())
    assert r.state==UnifiedFillState.RECOVERY_REQUIRED
    assert o.calls==["F1"] and p.calls==["F1"] and l.calls==["F1"]
    assert d.states["F1"]=="RECOVERY_REQUIRED"

def test_invalid_identity_blocked():
    d=InMemoryDurability()
    f=CanonicalFillRecord("","O1","T1","NIFTY","BUY",1,100)
    r=setup(durability=d).process(f)
    assert r.state==UnifiedFillState.BLOCKED
    assert d.claim_log==[]

def test_invalid_side_blocked():
    d=InMemoryDurability()
    r=setup(durability=d).process(make(side="HOLD"))
    assert r.state==UnifiedFillState.BLOCKED
    assert d.claim_log==[]

def test_invalid_quantity_blocked():
    d=InMemoryDurability()
    r=setup(durability=d).process(make(qty=0))
    assert r.state==UnifiedFillState.BLOCKED

def test_invalid_price_blocked():
    d=InMemoryDurability()
    r=setup(durability=d).process(make(price=0))
    assert r.state==UnifiedFillState.BLOCKED

def test_different_fills_are_independent():
    d=InMemoryDurability()
    o=Consumer("order")
    x=setup(order=o,durability=d)
    assert x.process(make("F1")).state==UnifiedFillState.ACCEPTED
    assert x.process(make("F2")).state==UnifiedFillState.ACCEPTED
    assert o.calls==["F1","F2"]

def test_fill_claim_happens_once():
    d=InMemoryDurability()
    x=setup(durability=d)
    x.process(make())
    x.process(make())
    assert d.claim_log==["F1"]
