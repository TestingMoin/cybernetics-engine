from types import SimpleNamespace
from cybernetics.persistence.fill_ledger import (
    FillLedgerState, PostgreSQLFillLedger, FillLedgerRecord, FILL_LEDGER_DDL
)
from cybernetics.trading.pg_fill_coordinator import DurableFillCoordinator


class Cursor:
    def __init__(self, row=None, rowcount=1):
        self.row = row
        self.rowcount = rowcount
        self.sql = None
        self.args = None
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def execute(self, sql, args):
        self.sql = sql; self.args = args
    def fetchone(self): return self.row


class Conn:
    def __init__(self, cursor):
        self.c = cursor
        self.commits = 0
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def cursor(self):
        return self.c
    def commit(self): self.commits += 1


class ConnectionFactory:
    def __init__(self, rows=None, rowcount=1):
        self.rows = list(rows or [])
        self.rowcount = rowcount
        self.last = None
    def __call__(self):
        row = self.rows.pop(0) if self.rows else None
        cur = Cursor(row=row, rowcount=self.rowcount)
        self.last = Conn(cur)
        return self.last


class LedgerFake:
    def __init__(self):
        self.records={}
    def fetch_fill(self, fid): return self.records.get(fid)
    def insert_claim(self,fid,oid,tid):
        if fid in self.records: return False
        self.records[fid]=FillLedgerRecord(fid,oid,tid,FillLedgerState.CLAIMED)
        return True
    def mark_completed(self,fid):
        r=self.records[fid]
        self.records[fid]=FillLedgerRecord(r.fill_id,r.order_id,r.trade_id,
                                           FillLedgerState.COMPLETED,None)
    def mark_recovery_required(self,fid,error):
        r=self.records[fid]
        self.records[fid]=FillLedgerRecord(r.fill_id,r.order_id,r.trade_id,
                                           FillLedgerState.RECOVERY_REQUIRED,error)


class Sink:
    def __init__(self, fail=False): self.fail=fail; self.calls=[]
    def mark_fill_applied(self,fill):
        if self.fail: raise RuntimeError("order_fail")
        self.calls.append(fill.fill_id)
class Pos:
    def __init__(self, fail=False): self.fail=fail; self.calls=[]
    def apply_fill(self,fill):
        if self.fail: raise RuntimeError("position_fail")
        self.calls.append(fill.fill_id)
class Life:
    def __init__(self, fail=False): self.fail=fail; self.calls=[]
    def on_fill(self,fill):
        if self.fail: raise RuntimeError("life_fail")
        self.calls.append(fill.fill_id)


F=SimpleNamespace(fill_id="F1",order_id="O1",trade_id="T1",
                  underlying_key="NIFTY",side="BUY",quantity=10,price=100,fee=0)


def test_ddl_contains_primary_key_and_states():
    assert "fill_id TEXT PRIMARY KEY" in FILL_LEDGER_DDL
    assert "CLAIMED" in FILL_LEDGER_DDL
    assert "COMPLETED" in FILL_LEDGER_DDL
    assert "RECOVERY_REQUIRED" in FILL_LEDGER_DDL


def test_postgres_fetch_maps_record():
    row=("F1","O1","T1","CLAIMED",None)
    cf=ConnectionFactory([row])
    l=PostgreSQLFillLedger(cf)
    r=l.fetch_fill("F1")
    assert r.state==FillLedgerState.CLAIMED
    assert r.fill_id=="F1"


def test_postgres_insert_claim_uses_conflict_safe_sql():
    cf=ConnectionFactory([], rowcount=1)
    l=PostgreSQLFillLedger(cf)
    assert l.insert_claim("F1","O1","T1")
    assert "ON CONFLICT (fill_id) DO NOTHING" in cf.last.c.sql
    assert cf.last.commits==1


def test_postgres_insert_conflict_returns_false():
    cf=ConnectionFactory([], rowcount=0)
    l=PostgreSQLFillLedger(cf)
    assert not l.insert_claim("F1","O1","T1")


def test_postgres_completion_requires_claimed_row():
    cf=ConnectionFactory([], rowcount=1)
    l=PostgreSQLFillLedger(cf)
    l.mark_completed("F1")
    assert "state = 'CLAIMED'" in cf.last.c.sql


def test_postgres_recovery_persists_error():
    cf=ConnectionFactory([], rowcount=1)
    l=PostgreSQLFillLedger(cf)
    l.mark_recovery_required("F1","boom")
    assert "RECOVERY_REQUIRED" in cf.last.c.sql
    assert cf.last.c.args==("boom","F1")


def test_durable_apply_completes():
    reg=LedgerFake(); o=Sink(); p=Pos(); q=Life()
    c=DurableFillCoordinator(reg,o,p,q)
    r=c.apply(F)
    assert r.state=="APPLIED"
    assert reg.records["F1"].state==FillLedgerState.COMPLETED
    assert o.calls==["F1"] and p.calls==["F1"] and q.calls==["F1"]


def test_durable_duplicate_is_blocked():
    reg=LedgerFake(); reg.records["F1"]=FillLedgerRecord(
        "F1","O1","T1",FillLedgerState.COMPLETED)
    c=DurableFillCoordinator(reg,Sink(),Pos(),Life())
    r=c.apply(F)
    assert r.state=="DUPLICATE"


def test_durable_claimed_requires_recovery():
    reg=LedgerFake(); reg.records["F1"]=FillLedgerRecord(
        "F1","O1","T1",FillLedgerState.CLAIMED)
    c=DurableFillCoordinator(reg,Sink(),Pos(),Life())
    assert c.apply(F).state=="RECOVERY_REQUIRED"


def test_downstream_failure_becomes_durable_recovery():
    reg=LedgerFake(); c=DurableFillCoordinator(
        reg,Sink(fail=True),Pos(),Life()
    )
    r=c.apply(F)
    assert r.state=="RECOVERY_REQUIRED"
    assert reg.records["F1"].state==FillLedgerState.RECOVERY_REQUIRED
    assert reg.records["F1"].error=="RuntimeError:order_fail"


def test_position_failure_does_not_complete():
    reg=LedgerFake(); c=DurableFillCoordinator(
        reg,Sink(),Pos(fail=True),Life()
    )
    r=c.apply(F)
    assert r.state=="RECOVERY_REQUIRED"
    assert reg.records["F1"].state != FillLedgerState.COMPLETED


def test_lifecycle_failure_does_not_complete():
    reg=LedgerFake(); c=DurableFillCoordinator(
        reg,Sink(),Pos(),Life(fail=True)
    )
    r=c.apply(F)
    assert r.state=="RECOVERY_REQUIRED"
    assert reg.records["F1"].state==FillLedgerState.RECOVERY_REQUIRED


def test_recovery_required_is_not_automatically_replayed():
    reg=LedgerFake(); reg.records["F1"]=FillLedgerRecord(
        "F1","O1","T1",FillLedgerState.RECOVERY_REQUIRED,"prior")
    o,p,q=Sink(),Pos(),Life()
    r=DurableFillCoordinator(reg,o,p,q).apply(F)
    assert r.state=="RECOVERY_REQUIRED"
    assert not o.calls and not p.calls and not q.calls
