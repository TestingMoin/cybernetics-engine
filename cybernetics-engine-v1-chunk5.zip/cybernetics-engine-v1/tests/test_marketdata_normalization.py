from datetime import datetime, timezone
import struct

from app.marketdata.dhan_protocol import decode_message
from app.marketdata.normalize import DataQuality, MarketNormalizer
from app.marketdata.candles import CandleBuilder
from app.data.quality import MarketDataQualityEngine


def header(code, length=16, segment=1, sid=123):
    return struct.pack("<BHBI", code, length, segment, sid)


def test_ticker_decode_and_normalize():
    raw = header(2) + struct.pack("<fI", 250.5, 1_725_000_000)
    event = decode_message(raw)[0]
    assert event.packet_kind == "ticker"
    assert event.last_price == 250.5
    tick = MarketNormalizer().normalize(event)
    assert tick.price == 250.5
    assert tick.quality is DataQuality.OK


def test_full_packet_decodes_depth_and_oi():
    raw = header(8, 162) + struct.pack("<fhifiiiiiiffff", 100.0, 10, 1_725_000_000, 100.0, 1000, 500, 700, 50, 60, 40, 99.0, 105.0, 110.0, 95.0)
    # Build depth exactly: five bid/ask pairs of 20 bytes.
    raw += b"".join(struct.pack("<iihhff", 10, 12, 1, 1, 99.9, 100.1) for _ in range(5))
    event = decode_message(raw)[0]
    assert event.packet_kind == "full"
    assert event.open_interest == 50
    assert len(event.depth) == 10


def test_quality_rejects_crossed_book():
    raw = header(8, 162) + struct.pack("<fhifiiiiiiffff", 100.0, 10, 1_725_000_000, 100.0, 1000, 500, 700, 50, 60, 40, 99.0, 105.0, 110.0, 95.0)
    raw += struct.pack("<iihhff", 10, 12, 1, 1, 101.0, 100.0)
    raw += b"".join(struct.pack("<iihhff", 10, 12, 1, 1, 99.9, 100.1) for _ in range(4))
    result = MarketDataQualityEngine().assess(MarketNormalizer().normalize(decode_message(raw)[0]))
    assert not result.accepted


def test_candle_builder_non_negative_volume_and_reset():
    from app.marketdata.normalize import NormalizedTick, DataQuality
    builder = CandleBuilder(("1m",))
    t0 = datetime(2026, 9, 7, 9, 15, 1, tzinfo=timezone.utc)
    ticks = [
        NormalizedTick(1, "123", t0, t0, 100.0, 1, 100, None, None, None, None, None, None, None, None, None, "ticker", DataQuality.OK, ()),
        NormalizedTick(1, "123", t0, t0, 101.0, 1, 110, None, None, None, None, None, None, None, None, None, "ticker", DataQuality.OK, ()),
        # cumulative-volume reset: no negative/fabricated delta
        NormalizedTick(1, "123", t0, t0, 102.0, 1, 3, None, None, None, None, None, None, None, None, None, "ticker", DataQuality.OK, ()),
    ]
    for tick in ticks:
        builder.update(tick)
    current = builder._current[(1, "123", "1m")]
    assert current.volume == 10
    assert current.volume_delta == 10
    assert current.volume >= 0


def test_multiple_packets_are_decoded_in_one_message():
    first = header(2, 16, sid=101) + struct.pack("<fI", 100.0, 1_700_000_000)
    second = header(2, 16, sid=202) + struct.pack("<fI", 200.0, 1_700_000_001)
    events = decode_message(first + second)
    assert [e.security_id for e in events] == ["101", "202"]
    assert [e.last_price for e in events] == [100.0, 200.0]
