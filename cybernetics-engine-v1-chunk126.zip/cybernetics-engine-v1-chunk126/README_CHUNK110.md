# Chunk 110 — Runtime Dependency Health Refresh

The canonical runtime no longer has to rely on a stale startup boolean snapshot when a dependency wiring object is supplied. The same injected health/readiness boundaries are refreshed before each supervisory-cycle snapshot.

The refresh remains fail-closed through the existing readiness probes. It does not itself open connections, submit orders, mutate PostgreSQL, or authorize live trading.
