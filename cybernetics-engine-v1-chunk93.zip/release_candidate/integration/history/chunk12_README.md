# Cybernetics Trading Engine — Chunk 12

Strategy framework and Golden Strategy reproduction targets.

Included:
- NIFTY/SENSEX Golden EMA strategy
- BankNifty Golden Multi-Factor strategy
- Smart Renko research adapter
- Swing Structure Forecast research engine
- Strategy manifest with GOLDEN vs RESEARCH status

The attached Pine source remains the authority for initial reproduction.
This chunk intentionally does not optimize, combine, or auto-create confluence.
Risk and execution are separate downstream layers.
