from datetime import datetime, timezone, timedelta
from cybernetics.indicator_bus.models import CandleInput
from cybernetics.indicator_bus.state import IndicatorState
from cybernetics.indicator_bus.pipeline import IndicatorPipeline, IndicatorDefinition, standard_indicator_definitions

def candle(i, close):
    return CandleInput("1","1m",
        datetime(2026,1,1,9,15,tzinfo=timezone.utc)+timedelta(minutes=i),
        close-1,close+1,close-2,close,1000)

def test_state_is_independent_between_instances():
    a=IndicatorState(); b=IndicatorState()
    for i in range(20):
        a.update(99,101,98,100+i)
    assert b.ema[5] is None
    assert b.prev_close is None

def test_ema_5_becomes_ready_after_five_closes():
    s=IndicatorState()
    for i in range(4):
        assert s.update(0,2,0,1+i)["ema_5"] is None
    value=s.update(0,6,0,5)["ema_5"]
    assert value==3.0

def test_bollinger_requires_twenty_closes():
    s=IndicatorState()
    last=None
    for i in range(19):
        last=s.update(0,100,0,100)["bb_mid_20"]
        assert last is None
    last=s.update(0,100,0,100)["bb_mid_20"]
    assert last==100

def test_roc_12_uses_percentage_change():
    s=IndicatorState()
    for i in range(12):
        s.update(0,100+i,0,100+i)
    v=s.update(0,200,0,200)["roc_12"]
    assert round(v,6)==100.0

def test_rsi_reaches_extreme_for_only_gains():
    s=IndicatorState()
    s.update(0,100,0,100)
    for i in range(1,16):
        value=s.update(0,101+i,0,101+i)["rsi_14"]
    assert value==100.0

def test_atr_returns_after_fourteen_true_ranges():
    s=IndicatorState()
    value=None
    for i in range(14):
        value=s.update(0,110,90,100)["atr_14"]
    assert value==20

def test_pipeline_registers_and_produces_snapshot():
    p=IndicatorPipeline()
    p.register(standard_indicator_definitions()[0])
    s=IndicatorState()
    snap=None
    for i in range(20):
        snap=p.process(candle(i,100+i),s)
    assert "ema_5" in snap.values
    assert "rsi_14" in snap.values
    assert snap.security_id=="1" and snap.timeframe=="1m"

def test_duplicate_indicator_registration_is_rejected():
    p=IndicatorPipeline()
    d=standard_indicator_definitions()[0]
    p.register(d)
    try:
        p.register(d); assert False
    except ValueError as e:
        assert str(e)=="indicator_definition_already_registered"

def test_snapshot_ready_contains_only_fully_computed_definition():
    p=IndicatorPipeline()
    p.register(standard_indicator_definitions()[0])
    s=IndicatorState()
    snap=p.process(candle(0,100),s)
    assert snap.ready==()

def test_candle_validation_prevents_bad_ohlc():
    try:
        CandleInput("1","1m",datetime.now(timezone.utc),10,9,8,9)
        assert False
    except ValueError as e:
        assert str(e)=="invalid_candle_high"
