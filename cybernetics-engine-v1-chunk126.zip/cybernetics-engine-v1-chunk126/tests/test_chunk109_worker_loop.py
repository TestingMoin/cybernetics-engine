from cybernetics.runtime.application import ApplicationLifecycle, RuntimeApplication, RuntimeConfig
from cybernetics.runtime.state import ControlState, EmergencyState, EngineMode


class MutableSignals:
    def __init__(self):
        self.ready = False

    def engine_mode(self):
        return EngineMode.RUNNING

    def control_state(self):
        return ControlState.RUNNING

    def emergency_state(self):
        return EmergencyState.CLEAR

    def persistence_ready(self):
        return self.ready

    def recovery_clear(self):
        return self.ready

    def orders_reconciled(self):
        return self.ready

    def positions_reconciled(self):
        return self.ready

    def market_data_ready(self):
        return self.ready

    def scanner_health_ready(self):
        return self.ready

    def watchdog_healthy(self):
        return self.ready

    def broker_available(self):
        return self.ready

    def live_authorization_valid(self):
        return False


def test_run_cycle_refreshes_readiness_without_changing_lifecycle():
    signals = MutableSignals()
    app = RuntimeApplication(config=RuntimeConfig(poll_interval_seconds=0.01), signals=signals)
    app.start()
    assert app.lifecycle is ApplicationLifecycle.RUNNING
    assert app.last_snapshot is not None
    assert app.last_snapshot.readiness.new_trades_allowed is False

    signals.ready = True
    snap = app.run_cycle()
    assert app.lifecycle is ApplicationLifecycle.RUNNING
    assert snap is app.last_snapshot
    assert snap.readiness.new_trades_allowed is False  # live auth remains a separate gate
    app.stop()


def test_run_cycle_requires_running_state():
    app = RuntimeApplication()
    try:
        app.run_cycle()
        assert False
    except RuntimeError as exc:
        assert str(exc) == "application_not_running"


def test_request_stop_causes_run_loop_to_exit_cleanly():
    app = RuntimeApplication(config=RuntimeConfig(poll_interval_seconds=0.01))
    def stop_on_start():
        app.request_stop()
    app.on_start = stop_on_start
    assert app.run() == 0
    assert app.lifecycle is ApplicationLifecycle.STOPPED
