#!/usr/bin/env python3
"""
OPTIONS MASTER ENGINE
=====================
Deterministic, audit-first engine for the completed options/futures curriculum.

Scope
-----
• Option-chain data quality and normalization
• OI / OI-change / Volume / LTP buildup classification
• ATM / nearby strikes / moneyness
• OI-PCR and Volume-PCR
• Standard Max Pain (minimum aggregate theoretical intrinsic payout)
• Intrinsic / time value / breakeven / expiry P&L
• Delta / Gamma / Theta / Vega approximations
• IV Rank, skew, Black-Scholes, Black-76 and IV inversion
• Futures notional, tick value, MTM, basis, leverage
• Synthetic positions, hedges and common option structures
• Position/portfolio risk
• Lesson coverage audit for 1..516 and A1..H58

Safety / reliability principles
-------------------------------
1. No calculation is presented as a guaranteed market prediction.
2. Missing data is reported; it is never silently invented.
3. Contract specifications are external data, not hard-coded assumptions.
4. Max Pain uses OI and theoretical expiry intrinsic payout, not option LTP.
5. Buildup requires a comparable LTP change plus OI change.
6. PCR is contextual, never a standalone signal.
7. Delta is sensitivity, not probability of profit.
8. Model outputs are approximations and model-dependent.
9. This program does not place broker orders.
10. Historical lesson completeness is only declared when an exact manifest
    contains every required lesson. The program will not falsely claim that
    all 516 historical micro-lessons were semantically reconstructed.

Python 3.10+; standard library only.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from datetime import date, datetime
from enum import Enum
from math import erf, exp, isfinite, log, sqrt
from pathlib import Path
from statistics import median
from typing import Any, Iterable, Mapping, Optional, Sequence
import argparse
import csv
import json


# ---------------------------------------------------------------------------
# ENUMS
# ---------------------------------------------------------------------------

class OptionType(str, Enum):
    CE = "CE"
    PE = "PE"


class Buildup(str, Enum):
    LONG_BUILDUP = "Long Buildup"
    SHORT_BUILDUP = "Short Buildup"
    LONG_UNWINDING = "Long Unwinding"
    SHORT_COVERING = "Short Covering"
    UNDETERMINED = "Undetermined"


# ---------------------------------------------------------------------------
# DATA MODELS
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ContractSpec:
    underlying: str
    quantity: float
    tick_size: float
    multiplier: float = 1.0
    currency: str = "INR"
    settlement_type: Optional[str] = None
    exercise_style: Optional[str] = None

    def validate(self) -> None:
        if self.quantity <= 0 or self.tick_size <= 0 or self.multiplier <= 0:
            raise ValueError("Contract quantity, tick size and multiplier must be > 0")


@dataclass
class OptionQuote:
    underlying: str
    expiry: date
    strike: float
    option_type: OptionType
    ltp: Optional[float] = None
    oi: Optional[float] = None
    oi_change: Optional[float] = None
    volume: Optional[float] = None
    iv: Optional[float] = None
    bid: Optional[float] = None
    ask: Optional[float] = None
    timestamp: Optional[datetime] = None
    previous_ltp: Optional[float] = None
    previous_oi: Optional[float] = None

    def validate(self) -> None:
        if not self.underlying or self.strike <= 0:
            raise ValueError("Underlying and positive strike are required")
        for name in ("ltp", "oi", "volume", "iv", "bid", "ask", "previous_oi"):
            value = getattr(self, name)
            if value is not None and (not isfinite(float(value)) or float(value) < 0):
                raise ValueError(f"{name} must be a finite non-negative number")
        if self.bid is not None and self.ask is not None and self.ask < self.bid:
            raise ValueError("Ask cannot be below bid")


@dataclass
class Chain:
    quotes: list[OptionQuote]
    source: str = "unknown"
    snapshot_timestamp: Optional[datetime] = None

    def validate(self) -> None:
        if not self.quotes:
            raise ValueError("Option chain is empty")
        for q in self.quotes:
            q.validate()
        keys = [(q.underlying, q.expiry, q.strike, q.option_type.value) for q in self.quotes]
        dup = sorted({k for k in keys if keys.count(k) > 1}, key=str)
        if dup:
            raise ValueError(f"Duplicate contracts detected: {dup[:10]}")

    @property
    def underlyings(self) -> set[str]:
        return {q.underlying for q in self.quotes}

    @property
    def expiries(self) -> set[date]:
        return {q.expiry for q in self.quotes}


@dataclass
class Finding:
    code: str
    severity: str
    message: str
    evidence: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# BASIC NUMERIC FUNCTIONS
# ---------------------------------------------------------------------------

def safe_div(a: float, b: float) -> Optional[float]:
    return None if b == 0 else a / b


def pct_change(old: float, new: float) -> Optional[float]:
    return None if old == 0 else (new - old) / old * 100.0


def intrinsic_value(underlying: float, strike: float, option_type: OptionType) -> float:
    return max(underlying - strike, 0.0) if option_type == OptionType.CE else max(strike - underlying, 0.0)


def breakeven_long(strike: float, premium: float, option_type: OptionType) -> float:
    return strike + premium if option_type == OptionType.CE else strike - premium


def long_expiry_pnl(s: float, k: float, premium: float, option_type: OptionType) -> float:
    return intrinsic_value(s, k, option_type) - premium


def short_expiry_pnl(s: float, k: float, premium_received: float, option_type: OptionType) -> float:
    return premium_received - intrinsic_value(s, k, option_type)


def classify_buildup(ltp_change: Optional[float], oi_change: Optional[float]) -> Buildup:
    if ltp_change is None or oi_change is None:
        return Buildup.UNDETERMINED
    if ltp_change > 0 and oi_change > 0:
        return Buildup.LONG_BUILDUP
    if ltp_change < 0 and oi_change > 0:
        return Buildup.SHORT_BUILDUP
    if ltp_change < 0 and oi_change < 0:
        return Buildup.LONG_UNWINDING
    if ltp_change > 0 and oi_change < 0:
        return Buildup.SHORT_COVERING
    return Buildup.UNDETERMINED


def quote_buildup(q: OptionQuote) -> Buildup:
    change = None
    if q.previous_ltp is not None and q.ltp is not None:
        change = q.ltp - q.previous_ltp
    return classify_buildup(change, q.oi_change)


def atm_strike(underlying_price: float, strikes: Sequence[float], platform_atm: Optional[float] = None) -> Optional[float]:
    if platform_atm is not None:
        return platform_atm
    if not strikes:
        return None
    return min(set(strikes), key=lambda x: abs(x - underlying_price))


def nearby_strikes(underlying_price: float, strikes: Sequence[float], each_side: int = 1) -> list[float]:
    s = sorted(set(float(x) for x in strikes))
    atm = atm_strike(underlying_price, s)
    if atm is None:
        return []
    lower = sorted((x for x in s if x < atm), reverse=True)[:each_side]
    upper = sorted((x for x in s if x > atm))[:each_side]
    return sorted(lower + [atm] + upper)


# ---------------------------------------------------------------------------
# PCR
# ---------------------------------------------------------------------------

def pcr_oi(quotes: Iterable[OptionQuote]) -> Optional[float]:
    q = [x for x in quotes if x.oi is not None]
    puts = sum(x.oi for x in q if x.option_type == OptionType.PE)
    calls = sum(x.oi for x in q if x.option_type == OptionType.CE)
    return safe_div(puts, calls)


def pcr_volume(quotes: Iterable[OptionQuote]) -> Optional[float]:
    q = [x for x in quotes if x.volume is not None]
    puts = sum(x.volume for x in q if x.option_type == OptionType.PE)
    calls = sum(x.volume for x in q if x.option_type == OptionType.CE)
    return safe_div(puts, calls)


# ---------------------------------------------------------------------------
# MAX PAIN
# ---------------------------------------------------------------------------

def max_pain(
    quotes: Iterable[OptionQuote],
    expiry: date,
    candidate_prices: Optional[Sequence[float]] = None,
    multiplier: float = 1.0,
) -> tuple[Optional[float], dict[float, float]]:
    q = [x for x in quotes if x.expiry == expiry and x.oi is not None]
    if not q:
        return None, {}
    candidates = sorted(set(candidate_prices or [x.strike for x in q]))
    curve: dict[float, float] = {}
    for p in candidates:
        total = 0.0
        for x in q:
            total += intrinsic_value(p, x.strike, x.option_type) * x.oi * multiplier
        curve[p] = total
    minimum = min(curve.values())
    winners = [p for p, v in curve.items() if v == minimum]
    return median(winners), curve


# ---------------------------------------------------------------------------
# LIQUIDITY
# ---------------------------------------------------------------------------

def bid_ask_spread(q: OptionQuote) -> Optional[float]:
    if q.bid is None or q.ask is None:
        return None
    return q.ask - q.bid


def mid_price(q: OptionQuote) -> Optional[float]:
    if q.bid is None or q.ask is None:
        return None
    return (q.bid + q.ask) / 2.0


def liquidity_record(q: OptionQuote) -> dict[str, Any]:
    spread = bid_ask_spread(q)
    mid = mid_price(q)
    return {
        "strike": q.strike,
        "option_type": q.option_type.value,
        "oi": q.oi,
        "volume": q.volume,
        "bid": q.bid,
        "ask": q.ask,
        "spread": spread,
        "relative_spread_pct": safe_div(spread, mid) * 100 if spread is not None and mid else None,
        "warning": "High OI/volume does not guarantee good execution."
    }


# ---------------------------------------------------------------------------
# BLACK-SCHOLES / BLACK-76
# ---------------------------------------------------------------------------

def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


def black_scholes(
    spot: float,
    strike: float,
    time_years: float,
    volatility: float,
    rate: float,
    option_type: OptionType,
    dividend_yield: float = 0.0,
) -> float:
    if time_years == 0:
        return intrinsic_value(spot, strike, option_type)
    if min(spot, strike, time_years, volatility) <= 0:
        raise ValueError("Spot, strike, time and volatility must be > 0")
    d1 = (log(spot / strike) + (rate - dividend_yield + 0.5 * volatility**2) * time_years) / (volatility * sqrt(time_years))
    d2 = d1 - volatility * sqrt(time_years)
    df = exp(-rate * time_years)
    dq = exp(-dividend_yield * time_years)
    if option_type == OptionType.CE:
        return spot * dq * norm_cdf(d1) - strike * df * norm_cdf(d2)
    return strike * df * norm_cdf(-d2) - spot * dq * norm_cdf(-d1)


def black_76(
    forward: float,
    strike: float,
    time_years: float,
    volatility: float,
    rate: float,
    option_type: OptionType,
) -> float:
    if time_years == 0:
        return exp(-rate * time_years) * intrinsic_value(forward, strike, option_type)
    if min(forward, strike, time_years, volatility) <= 0:
        raise ValueError("Forward, strike, time and volatility must be > 0")
    d1 = (log(forward / strike) + 0.5 * volatility**2 * time_years) / (volatility * sqrt(time_years))
    d2 = d1 - volatility * sqrt(time_years)
    df = exp(-rate * time_years)
    if option_type == OptionType.CE:
        return df * (forward * norm_cdf(d1) - strike * norm_cdf(d2))
    return df * (strike * norm_cdf(-d2) - forward * norm_cdf(-d1))


def implied_volatility(
    market_price: float,
    model: str,
    option_type: OptionType,
    strike: float,
    time_years: float,
    rate: float,
    *,
    spot: Optional[float] = None,
    forward: Optional[float] = None,
    dividend_yield: float = 0.0,
    low: float = 1e-8,
    high: float = 5.0,
    tolerance: float = 1e-8,
    iterations: int = 200,
) -> float:
    if market_price < 0:
        raise ValueError("Market price cannot be negative")
    model = model.lower().replace("_", "-")

    def value(vol: float) -> float:
        if model in {"black-scholes", "bs"}:
            if spot is None:
                raise ValueError("spot is required for Black-Scholes")
            return black_scholes(spot, strike, time_years, vol, rate, option_type, dividend_yield)
        if model in {"black-76", "black76", "b76"}:
            if forward is None:
                raise ValueError("forward is required for Black-76")
            return black_76(forward, strike, time_years, vol, rate, option_type)
        raise ValueError("Unknown model")

    pl, ph = value(low), value(high)
    if not (min(pl, ph) <= market_price <= max(pl, ph)):
        raise ValueError("Market price is outside the requested IV bracket; check inputs/model")

    for _ in range(iterations):
        mid = (low + high) / 2.0
        pm = value(mid)
        if abs(pm - market_price) <= tolerance:
            return mid
        if pm < market_price:
            low = mid
        else:
            high = mid
    return (low + high) / 2.0


# ---------------------------------------------------------------------------
# VOLATILITY METRICS
# ---------------------------------------------------------------------------

def iv_rank(current_iv_pct: float, low_iv_pct: float, high_iv_pct: float) -> Optional[float]:
    if high_iv_pct <= low_iv_pct:
        return None
    return max(0.0, min(100.0, (current_iv_pct - low_iv_pct) / (high_iv_pct - low_iv_pct) * 100.0))


def skew_difference(put_iv_pct: float, call_iv_pct: float) -> float:
    return put_iv_pct - call_iv_pct


def skew_state(previous_put: float, previous_call: float, current_put: float, current_call: float) -> dict[str, Any]:
    old = skew_difference(previous_put, previous_call)
    new = skew_difference(current_put, current_call)
    delta = new - old
    return {
        "previous_points": old,
        "current_points": new,
        "change_points": delta,
        "state": "steepening" if delta > 0 else "flattening" if delta < 0 else "unchanged",
    }


# ---------------------------------------------------------------------------
# GREEKS / P&L APPROXIMATION
# ---------------------------------------------------------------------------

def delta_effect(delta: float, underlying_move: float) -> float:
    return delta * underlying_move


def delta_gamma_effect(delta: float, gamma: float, underlying_move: float) -> float:
    return delta * underlying_move + 0.5 * gamma * underlying_move**2


def greek_change(delta: float, gamma: float, theta_per_day: float, vega_per_iv_point: float,
                 underlying_move: float, days_elapsed: float, iv_change_points: float) -> float:
    return (
        delta * underlying_move
        + 0.5 * gamma * underlying_move**2
        + theta_per_day * days_elapsed
        + vega_per_iv_point * iv_change_points
    )


@dataclass
class Position:
    name: str
    side: str
    quantity: float
    entry_price: float
    instrument_type: str
    delta: Optional[float] = None
    gamma: Optional[float] = None
    theta: Optional[float] = None
    vega: Optional[float] = None
    strike: Optional[float] = None
    option_type: Optional[OptionType] = None
    expiry: Optional[date] = None

    def validate(self) -> None:
        if self.quantity == 0:
            raise ValueError("Position quantity cannot be zero")
        if self.side.upper() not in {"LONG", "SHORT"}:
            raise ValueError("side must be LONG or SHORT")


def portfolio_greek(positions: Iterable[Position], greek: str) -> Optional[float]:
    total = 0.0
    found = False
    for p in positions:
        value = getattr(p, greek)
        if value is None:
            continue
        found = True
        sign = 1 if p.side.upper() == "LONG" else -1
        total += sign * p.quantity * value
    return total if found else None


def delta_hedge_futures_contracts(option_position_delta: float, futures_contract_quantity: float,
                                  target_delta: float = 0.0) -> float:
    if futures_contract_quantity <= 0:
        raise ValueError("futures contract quantity must be > 0")
    return (target_delta - option_position_delta) / futures_contract_quantity


def risk_reward(risk: float, reward: float) -> Optional[float]:
    return None if risk <= 0 or reward < 0 else reward / risk


# ---------------------------------------------------------------------------
# FUTURES
# ---------------------------------------------------------------------------

def futures_notional(price: float, quantity: float) -> float:
    return price * quantity


def futures_tick_value(tick_size: float, quantity: float) -> float:
    return tick_size * quantity


def futures_daily_mtm(previous_settlement: float, current_settlement: float,
                      quantity: float, side: str = "LONG") -> float:
    move = current_settlement - previous_settlement
    return (move if side.upper() == "LONG" else -move) * quantity


def futures_cumulative_pnl(entry: float, settlement: float, quantity: float,
                           side: str = "LONG") -> float:
    move = settlement - entry
    return (move if side.upper() == "LONG" else -move) * quantity


def futures_basis(futures_price: float, spot_price: float) -> float:
    return futures_price - spot_price


def conceptual_leverage(notional: float, margin: float) -> Optional[float]:
    return safe_div(notional, margin)


def calendar_spread_value(near: float, far: float) -> float:
    return far - near


# ---------------------------------------------------------------------------
# STRUCTURE PAYOFFS
# ---------------------------------------------------------------------------

def bull_call_spread(s: float, lower: float, higher: float, debit: float) -> float:
    return max(s-lower, 0) - max(s-higher, 0) - debit


def bear_put_spread(s: float, higher: float, lower: float, debit: float) -> float:
    return max(higher-s, 0) - max(lower-s, 0) - debit


def call_credit_spread(s: float, short_k: float, long_k: float, credit: float) -> float:
    return credit - (max(s-short_k, 0) - max(s-long_k, 0))


def put_credit_spread(s: float, short_k: float, long_k: float, credit: float) -> float:
    return credit - (max(short_k-s, 0) - max(long_k-s, 0))


def long_straddle(s: float, k: float, debit: float) -> float:
    return abs(s-k) - debit


def long_strangle(s: float, put_k: float, call_k: float, debit: float) -> float:
    return max(put_k-s, 0) + max(s-call_k, 0) - debit


def iron_condor(s: float, long_put: float, short_put: float, short_call: float,
                long_call: float, credit: float) -> float:
    put_loss = max(short_put-s, 0) - max(long_put-s, 0)
    call_loss = max(s-short_call, 0) - max(s-long_call, 0)
    return credit - put_loss - call_loss


def call_butterfly(s: float, lower: float, middle: float, higher: float, debit: float) -> float:
    payoff = max(s-lower, 0) - 2*max(s-middle, 0) + max(s-higher, 0)
    return payoff - debit


def synthetic_long_underlying(s: float, k: float, call_paid: float, put_received: float) -> float:
    return max(s-k, 0) - call_paid - max(k-s, 0) + put_received


def synthetic_short_underlying(s: float, k: float, call_received: float, put_paid: float) -> float:
    return call_received - max(s-k, 0) + max(k-s, 0) - put_paid


def protective_put(entry_underlying: float, s: float, put_k: float, put_premium: float) -> float:
    return (s-entry_underlying) + max(put_k-s, 0) - put_premium


def covered_call(entry_underlying: float, s: float, call_k: float, call_premium: float) -> float:
    return (s-entry_underlying) + call_premium - max(s-call_k, 0)


# ---------------------------------------------------------------------------
# CHAIN ANALYSIS
# ---------------------------------------------------------------------------

@dataclass
class ChainReport:
    underlying: str
    underlying_price: float
    expiry: date
    atm: Optional[float]
    nearby: list[float]
    pcr_oi: Optional[float]
    pcr_volume: Optional[float]
    max_pain: Optional[float]
    buildup_counts: dict[str, int]
    liquidity: list[dict[str, Any]]
    findings: list[Finding]
    warnings: list[str]

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["findings"] = [asdict(x) for x in self.findings]
        return d


class OptionsMasterEngine:
    def __init__(self, contract_spec: Optional[ContractSpec] = None):
        self.contract_spec = contract_spec
        if contract_spec:
            contract_spec.validate()

    @staticmethod
    def from_rows(rows: Iterable[Mapping[str, Any]], source: str = "input") -> Chain:
        quotes = []
        for r in rows:
            exp_value = r["expiry"]
            exp_date = exp_value if isinstance(exp_value, date) else date.fromisoformat(str(exp_value)[:10])
            ts = r.get("timestamp")
            timestamp = ts if isinstance(ts, datetime) else datetime.fromisoformat(str(ts)) if ts else None
            q = OptionQuote(
                underlying=str(r["underlying"]),
                expiry=exp_date,
                strike=float(r["strike"]),
                option_type=OptionType(str(r["option_type"]).upper()),
                ltp=_num(r.get("ltp")), oi=_num(r.get("oi")),
                oi_change=_num(r.get("oi_change")), volume=_num(r.get("volume")),
                iv=_num(r.get("iv")), bid=_num(r.get("bid")), ask=_num(r.get("ask")),
                timestamp=timestamp, previous_ltp=_num(r.get("previous_ltp")),
                previous_oi=_num(r.get("previous_oi")),
            )
            q.validate()
            quotes.append(q)
        chain = Chain(quotes, source)
        chain.validate()
        return chain

    def analyze(self, chain: Chain, underlying_price: float, expiry: Optional[date] = None,
                strike_scope: Optional[set[float]] = None) -> ChainReport:
        chain.validate()
        underlying = next(iter(chain.underlyings))
        expiry = expiry or min(chain.expiries)
        q = [x for x in chain.quotes if x.expiry == expiry and (strike_scope is None or x.strike in strike_scope)]
        strikes = sorted({x.strike for x in q})
        atm = atm_strike(underlying_price, strikes)
        nearby = nearby_strikes(underlying_price, strikes)
        counts = {b.value: 0 for b in Buildup}
        for x in q:
            counts[quote_buildup(x).value] += 1
        mp, _ = max_pain(q, expiry, multiplier=self.contract_spec.multiplier if self.contract_spec else 1.0)
        findings = [
            Finding("ATM_REFERENCE", "INFO", "ATM is a reference point, not a standalone signal.", {"atm": atm}),
            Finding("PCR_CONTEXT", "INFO", "PCR is a ratio and is not a standalone directional signal."),
            Finding("MAX_PAIN_CONTEXT", "INFO", "Max Pain is minimum aggregate theoretical intrinsic payout under the supplied OI snapshot; it is not a guaranteed expiry forecast.", {"max_pain": mp}),
        ]
        warnings = []
        if any(x.previous_ltp is None for x in q):
            warnings.append("Some quotes lack previous LTP; their buildup is Undetermined rather than guessed.")
        if any(x.oi is None for x in q):
            warnings.append("Some OI values are missing; OI analysis is partial.")
        if any(x.volume is None for x in q):
            warnings.append("Some Volume values are missing; volume analysis is partial.")
        if any(x.iv is None for x in q):
            warnings.append("Some IV values are missing; volatility analysis is partial.")
        return ChainReport(
            underlying, underlying_price, expiry, atm, nearby,
            pcr_oi(q), pcr_volume(q), mp, counts,
            [liquidity_record(x) for x in q if x.bid is not None or x.ask is not None],
            findings, warnings
        )


# ---------------------------------------------------------------------------
# DATA QUALITY AUDIT
# ---------------------------------------------------------------------------

@dataclass
class DataQualityReport:
    rows: int
    duplicates: int
    missing_ltp: int
    missing_oi: int
    missing_volume: int
    missing_iv: int
    crossed_quotes: int
    warnings: list[str]


def audit_chain(chain: Chain) -> DataQualityReport:
    keys = [(q.underlying, q.expiry, q.strike, q.option_type.value) for q in chain.quotes]
    duplicates = len(keys) - len(set(keys))
    crossed = sum(q.bid is not None and q.ask is not None and q.ask < q.bid for q in chain.quotes)
    warnings = []
    if duplicates: warnings.append("Duplicate contracts detected.")
    if crossed: warnings.append("Crossed bid/ask quotes detected.")
    return DataQualityReport(
        rows=len(chain.quotes), duplicates=duplicates,
        missing_ltp=sum(q.ltp is None for q in chain.quotes),
        missing_oi=sum(q.oi is None for q in chain.quotes),
        missing_volume=sum(q.volume is None for q in chain.quotes),
        missing_iv=sum(q.iv is None for q in chain.quotes),
        crossed_quotes=crossed, warnings=warnings
    )


def _num(v: Any) -> Optional[float]:
    if v is None or v == "" or str(v).upper() in {"NA", "N/A", "-"}:
        return None
    x = float(v)
    if not isfinite(x):
        return None
    return x


# ---------------------------------------------------------------------------
# LESSON COVERAGE AUDIT
# ---------------------------------------------------------------------------

FINAL_58 = {
    "A": [
        "Option payoff diagrams", "Long vs short payoff symmetry",
        "Profit zone vs payoff zone", "Expiration P&L curve",
        "Position sizing and risk per contract",
    ],
    "B": [
        "Black-Scholes / Black-76 purpose", "Inputs to an option-pricing model",
        "Implied volatility inversion", "Why theoretical price and market price can differ",
        "Volatility surface and model assumptions in practice",
    ],
    "C": [
        "Cross-Greek interaction", "Delta-hedged position", "Gamma scalping",
        "Theta versus realized movement", "Vega exposure across expiries",
        "Greek exposure at portfolio level",
    ],
    "D": [
        "Futures contract multiplier and tick value", "Mark-to-market / daily settlement",
        "Initial position vs daily settlement P&L", "Futures leverage",
        "Futures expiry/settlement mechanics", "Delivery versus cash settlement",
        "Hedging with futures", "Speculation with futures",
    ],
    "E": [
        "Synthetic long/short underlying", "Synthetic Call / Put relationships",
        "Protective Put", "Covered Call", "Option hedge using futures",
        "Delta hedging with futures",
    ],
    "F": [
        "Vertical spreads", "Bull Call Spread", "Bear Put Spread", "Credit spreads",
        "Straddles", "Strangles", "Iron Condor", "Butterfly",
        "Calendar option spreads", "Diagonal spreads",
    ],
    "G": [
        "OI + Volume + IV together", "IV by strike and expiry",
        "Delta-based option selection", "ATM/OTM option sensitivity comparison",
        "Expiry selection", "Liquidity / bid-ask spread", "Slippage",
        "Open-interest concentration versus actual tradability",
    ],
    "H": [
        "Maximum loss vs margin requirement", "Risk/reward", "Position-level risk",
        "Portfolio-level risk", "Gap risk", "Liquidity risk", "Volatility risk",
        "Expiry risk", "Correlation/concentration risk", "Model risk",
    ],
}


def required_lesson_ids() -> list[str]:
    ids = [str(i) for i in range(1, 517)]
    for group, lessons in FINAL_58.items():
        ids.extend(f"{group}{i}" for i in range(1, len(lessons)+1))
    return ids


@dataclass
class LessonRecord:
    id: str
    title: str
    content: str
    status: str = "UNKNOWN"
    implementation_refs: list[str] = field(default_factory=list)


def lesson_sort_key(x: str):
    return (0, int(x)) if x.isdigit() else (1, x[0], int(x[1:]))


def audit_lesson_manifest(records: Sequence[LessonRecord]) -> dict[str, Any]:
    required = required_lesson_ids()
    required_set = set(required)
    ids = [r.id for r in records]
    present = set(ids)
    duplicates = sorted({x for x in ids if ids.count(x) > 1}, key=lesson_sort_key)
    missing = sorted(required_set - present, key=lesson_sort_key)
    semantic = sorted({r.id for r in records if r.id in required_set and r.status.upper() == "COMPLETE" and r.content.strip()}, key=lesson_sort_key)
    return {
        "required_count": len(required),
        "present_unique_count": len(present),
        "semantic_complete_count": len(semantic),
        "missing_ids": missing,
        "duplicate_ids": duplicates,
        "structurally_complete": not missing and not duplicates,
        "semantically_complete": not missing and not duplicates and len(semantic) == len(required),
        "warning": None if len(semantic) == len(required) and not missing and not duplicates else "Exact semantic completeness is not established. Supply the exact lesson manifest."
    }


def load_manifest(path: str | Path) -> list[LessonRecord]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    raw = raw["lessons"] if isinstance(raw, dict) else raw
    return [LessonRecord(str(x["id"]), str(x.get("title", "")), str(x.get("content", "")), str(x.get("status", "UNKNOWN")), list(x.get("implementation_refs", []))) for x in raw]


# ---------------------------------------------------------------------------
# SELF TESTS
# ---------------------------------------------------------------------------

def self_test() -> dict[str, str]:
    out = {}
    assert intrinsic_value(24500, 24000, OptionType.CE) == 500
    assert intrinsic_value(23500, 24000, OptionType.PE) == 500
    assert breakeven_long(24000, 200, OptionType.CE) == 24200
    assert breakeven_long(24000, 200, OptionType.PE) == 23800
    assert long_expiry_pnl(24500, 24000, 200, OptionType.CE) == 300
    out["payoff_breakeven"] = "PASS"

    assert classify_buildup(1, 1) == Buildup.LONG_BUILDUP
    assert classify_buildup(-1, 1) == Buildup.SHORT_BUILDUP
    assert classify_buildup(-1, -1) == Buildup.LONG_UNWINDING
    assert classify_buildup(1, -1) == Buildup.SHORT_COVERING
    out["buildup"] = "PASS"

    exp = date(2026, 9, 24)
    ce = OptionQuote("NIFTY", exp, 24000, OptionType.CE, oi=100)
    pe = OptionQuote("NIFTY", exp, 24000, OptionType.PE, oi=150)
    assert pcr_oi([ce, pe]) == 1.5
    mp, _ = max_pain([ce, pe], exp)
    assert mp == 24000
    out["pcr_max_pain"] = "PASS"

    assert futures_notional(24000, 75) == 1800000
    assert futures_tick_value(0.05, 75) == 3.75
    assert futures_daily_mtm(7000, 7020, 1250) == 25000
    assert futures_daily_mtm(7020, 7010, 1250) == -12500
    out["futures"] = "PASS"

    assert delta_effect(0.5, 10) == 5
    assert abs(delta_gamma_effect(0.5, 0.02, 10) - 6) < 1e-12
    out["greeks"] = "PASS"

    assert bull_call_spread(24500, 24000, 24500, 200) == 300
    assert bear_put_spread(23500, 24000, 23500, 200) == 300
    assert long_straddle(25000, 24000, 550) == 450
    assert long_strangle(25000, 23800, 24200, 350) == 450
    assert iron_condor(24000, 23500, 23800, 24200, 24500, 200) == 200
    assert call_butterfly(24000, 23500, 24000, 24500, 50) == 450
    out["structures"] = "PASS"

    assert iv_rank(21, 12, 30) == 50
    out["volatility"] = "PASS"
    return out


# ---------------------------------------------------------------------------
# CSV HELPERS / CLI
# ---------------------------------------------------------------------------

def read_csv(path: str | Path) -> list[dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_json(data: Any, path: str | Path) -> None:
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Options Master Engine")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("self-test")
    sub.add_parser("required-lessons")

    a = sub.add_parser("audit-lessons")
    a.add_argument("manifest")

    c = sub.add_parser("analyze-csv")
    c.add_argument("csv")
    c.add_argument("--underlying-price", type=float, required=True)
    c.add_argument("--expiry")
    c.add_argument("--output")

    args = parser.parse_args()

    if args.cmd == "self-test":
        print(json.dumps(self_test(), indent=2))
        return

    if args.cmd == "required-lessons":
        print(json.dumps(required_lesson_ids(), indent=2))
        return

    if args.cmd == "audit-lessons":
        records = load_manifest(args.manifest)
        print(json.dumps(audit_lesson_manifest(records), indent=2))
        return

    if args.cmd == "analyze-csv":
        rows = read_csv(args.csv)
        chain = OptionsMasterEngine.from_rows(rows, source=args.csv)
        quality = audit_chain(chain)
        expiry = date.fromisoformat(args.expiry) if args.expiry else None
        report = OptionsMasterEngine().analyze(chain, args.underlying_price, expiry)
        result = {"data_quality": asdict(quality), "analysis": report.to_dict(), "self_tests": self_test()}
        if args.output:
            write_json(result, args.output)
        print(json.dumps(result, indent=2, default=str))
        return

    parser.print_help()


if __name__ == "__main__":
    main()
