from cybernetics.config.settings import DeploymentConfig
from cybernetics.runtime.production import (
    ProductionRuntimeSignals,
    RuntimeDependencyState,
    build_production_runtime,
)
from cybernetics.runtime.state import ControlState, EmergencyState, EngineMode


def test_default_production_composition_is_fail_closed():
    config = DeploymentConfig.from_env({})
    app = build_production_runtime(config)
    snap = app.snapshot()
    assert snap.inputs.engine_mode is EngineMode.STOPPED
    assert snap.inputs.control_state is ControlState.STOP_NEW_TRADES
    assert snap.inputs.emergency_state is EmergencyState.CLEAR
    assert snap.readiness.engine_ready is False
    assert snap.readiness.new_trades_allowed is False


def test_ready_paper_runtime_can_be_engine_ready_but_not_live_trading_ready():
    config = DeploymentConfig.from_env({"CYBERNETICS_TRADING_MODE": "paper"})
    state = RuntimeDependencyState(
        engine_running=True,
        control_state=ControlState.RUNNING,
        persistence_ready=True,
        recovery_clear=True,
        orders_reconciled=True,
        positions_reconciled=True,
        market_data_ready=True,
        scanner_health_ready=True,
        watchdog_healthy=True,
        broker_available=True,
    )
    app = build_production_runtime(config, dependency_state=state)
    snap = app.snapshot()
    assert snap.readiness.engine_ready is True
    assert snap.readiness.new_trades_allowed is False
    assert "live_authorization_invalid" in snap.readiness.reasons


def test_live_requires_both_config_and_runtime_authorization():
    config = DeploymentConfig.from_env({
        "CYBERNETICS_ENV": "production",
        "CYBERNETICS_TRADING_MODE": "live",
        "CYBERNETICS_LIVE_APPROVAL_ID": "APP-98",
    })
    state = RuntimeDependencyState(live_authorization_valid=False)
    signals = ProductionRuntimeSignals(state, config)
    assert signals.live_authorization_valid() is False
    state.live_authorization_valid = True
    assert signals.live_authorization_valid() is True


def test_control_stop_blocks_new_trades_even_with_all_dependencies_ready():
    config = DeploymentConfig.from_env({
        "CYBERNETICS_ENV": "production",
        "CYBERNETICS_TRADING_MODE": "live",
        "CYBERNETICS_LIVE_APPROVAL_ID": "APP-98",
    })
    state = RuntimeDependencyState(
        engine_running=True,
        control_state=ControlState.STOP_NEW_TRADES,
        persistence_ready=True,
        recovery_clear=True,
        orders_reconciled=True,
        positions_reconciled=True,
        market_data_ready=True,
        scanner_health_ready=True,
        watchdog_healthy=True,
        broker_available=True,
        live_authorization_valid=True,
    )
    app = build_production_runtime(config, dependency_state=state)
    snap = app.snapshot()
    assert snap.readiness.engine_ready is True
    assert snap.readiness.new_trades_allowed is False
    assert "stop_new_trades" in snap.readiness.reasons


def test_legacy_readiness_module_uses_canonical_state_objects():
    from cybernetics.runtime import readiness
    from cybernetics.runtime import state
    assert readiness.RuntimeInputs is state.RuntimeInputs
    assert readiness.RuntimeReadiness is state.RuntimeReadiness
    assert readiness.evaluate_runtime is state.evaluate_runtime
