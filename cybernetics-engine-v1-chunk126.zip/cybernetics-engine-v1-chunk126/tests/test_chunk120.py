from pathlib import Path

ROOT = Path(__file__).parents[1]


def test_systemd_service_runs_as_cybernetics_and_is_hardened():
    text = (ROOT / "deploy/systemd/cybernetics-engine.service").read_text()
    assert "User=cybernetics" in text
    assert "Group=cybernetics" in text
    assert "NoNewPrivileges=true" in text
    assert "ProtectSystem=strict" in text
    assert "ProtectHome=true" in text
    assert "Restart=on-failure" in text


def test_staging_env_is_paper_safe():
    text = (ROOT / "deploy/config/cybernetics-engine.env.example").read_text()
    assert "CYBERNETICS_ENV=staging" in text
    assert "CYBERNETICS_TRADING_MODE=paper" in text
    assert "CYBERNETICS_ORDER_SUBMISSION_ENABLED=false" in text


def test_install_script_requires_release_and_cybernetics_user():
    text = (ROOT / "deploy/scripts/install_staging.sh").read_text()
    assert "required system user cybernetics is missing" in text
    assert "usage: install_staging.sh" in text
    assert "systemctl daemon-reload" in text


def test_verify_script_asserts_new_trades_blocked():
    text = (ROOT / "deploy/scripts/verify_staging.sh").read_text()
    assert 'new_trades_allowed"] is False' in text
