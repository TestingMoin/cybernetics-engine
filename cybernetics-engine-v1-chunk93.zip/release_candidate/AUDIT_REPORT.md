# Cybernetics Trading Engine — Chunk 93

## Release Candidate Architecture Audit

**Audit target:** Chunk 92 canonical unified release-candidate baseline.

**Audit scope:** repository-wide architecture, ownership, dependency/layering, runtime entrypoint, persistence/schema consistency, Dhan execution boundaries, safety controls, package metadata, and production-installation readiness.

### Validation baseline

| Gate | Result |
|---|---|
| `python -m compileall -q src tests` | PASS |
| `pytest -q` | **789 / 789 PASS** |
| Internal `cybernetics.*` imports | 0 unresolved |
| Strategy/Risk direct network/order calls | 0 |
| Credential literal scan | 0 |
| `0.0.0.0` bind scan | 0 |
| Debug print/breakpoint scan | 0 |

### Findings

| ID | Severity | Finding | Release impact |
|---|---|---|---|
| ARC-001 | **BLOCKER** | No canonical executable runtime entrypoint exists under `src/cybernetics`. Only the historical `legacy/main.py` is executable. | The engine cannot yet be started as a canonical production service from the unified tree. |
| ARC-002 | **BLOCKER** | `src/cybernetics/persistence/postgres_ledger.py` expects an `orders` table with `client_order_key`, `broker_order_id`, and `status`, while `sql/schema.sql` defines a different `orders` shape. | Durable order-idempotency persistence cannot safely be treated as schema-compatible. |
| ARC-003 | **BLOCKER** | PostgreSQL migration ownership is split: versions 1–3 are in `persistence/migration.py`, control is separately version 4, and emergency state has embedded DDL rather than a registered migration. | Startup/database rollout cannot yet have one authoritative migration chain. |
| ARC-004 | **HIGH** | Multiple competing implementations remain in parallel namespaces: `strategy`/`strategies`, `position`/`positions`, `order`/`orders`/`order_management`, and multiple runtime/control representations. | The source is test-complete but not yet ownership-complete; future changes could update the wrong implementation. |
| ARC-005 | **HIGH** | Two Dhan order adapter boundaries exist: `brokers/dhan_v2.py` and `dhan/submission.py`. | There must be one authoritative live submission path before production enablement. |
| ARC-006 | **HIGH** | `pyproject.toml` still identifies `cybernetics-engine-v1-chunk8` version `0.8.0`, and README still describes Chunk 83. | Release identity is inconsistent and unsuitable for controlled deployment/audit. |
| ARC-007 | **HIGH** | `requirements.txt` contains only `pytest>=9`; production runtime dependencies are not declared. | Reproducible VPS installation is not yet defined. |
| ARC-008 | **MEDIUM** | A small number of internal dependencies are loaded with `__import__()`. | Static dependency analysis and future refactoring are harder to perform reliably. |

### Safety assessment

The audit found **no direct order HTTP calls from strategy or risk modules**, **no credential literals**, and **no `0.0.0.0` bind**. The Dhan submission boundary remains explicitly guarded by engine-running, live authorization, emergency-stop, and order-submission-enable conditions in its own policy object. This is a static-source assessment; it is not a live-broker test.

### Architecture decision from this audit

**Chunk 93 does not modify production source code.** The release-candidate baseline is deliberately held at this audit gate because the blockers above require architectural ownership decisions before code is rewritten.

The next implementation sequence is:

1. Establish the canonical production runtime entrypoint and composition root.
2. Unify the PostgreSQL schema/migration chain and remove the order-schema contradiction.
3. Declare the reproducible production runtime dependency set.
4. Declare and enforce one source-of-truth owner for strategy, position, order lifecycle, runtime control, and Dhan submission contracts; retain old APIs only as explicit compatibility shims during migration.
5. Re-run the full 789-test regression suite and a new architecture audit.

**Release status: NOT CLEARED FOR PRODUCTION.**

No Hostinger deployment, production database migration, live trading enablement, or broker order was performed by Chunk 93.
