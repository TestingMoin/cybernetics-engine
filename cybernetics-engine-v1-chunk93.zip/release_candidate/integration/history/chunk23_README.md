# Cybernetics Trading Engine — Chunk 23

Multi-Broker Execution Interface.

A broker-neutral interface now sits between strategies/risk/execution and broker-specific adapters.

Current adapters:
- Dhan V2 contract stub
- Null adapter for safety
- Test fake adapter

The Dhan adapter is deliberately execution-blocked in this chunk.
Additional brokers can later implement the same BrokerAdapter contract without changing
strategy logic.
