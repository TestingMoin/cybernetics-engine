from cybernetics.runtime.application import RuntimeApplication, RuntimeConfig
from cybernetics.runtime.composition import RuntimeSignals
from cybernetics.runtime.state import ControlState, EmergencyState, EngineMode


class Signals:
    def __init__(self): self.ready=False
    def engine_mode(self): return EngineMode.RUNNING if self.ready else EngineMode.STOPPED
    def control_state(self): return ControlState.RUNNING if self.ready else ControlState.STOP_NEW_TRADES
    def emergency_state(self): return EmergencyState.CLEAR
    def persistence_ready(self): return self.ready
    def recovery_clear(self): return self.ready
    def orders_reconciled(self): return self.ready
    def positions_reconciled(self): return self.ready
    def market_data_ready(self): return self.ready
    def scanner_health_ready(self): return self.ready
    def watchdog_healthy(self): return self.ready
    def live_authorization_valid(self): return self.ready
    def broker_available(self): return self.ready


class Audit:
    def __init__(self): self.lifecycle_events=[]; self.readiness_events=[]
    def lifecycle(self, state, *, previous=None): self.lifecycle_events.append((state,previous))
    def readiness(self, *, engine_ready, new_trades_allowed, reason): self.readiness_events.append((engine_ready,new_trades_allowed,reason))


def test_application_emits_lifecycle_and_initial_readiness_audit():
    sig=Signals(); audit=Audit(); app=RuntimeApplication(signals=sig, audit=audit)
    snap=app.start()
    assert app.lifecycle.value=="RUNNING"
    assert [x[0] for x in audit.lifecycle_events]==["STARTING","RUNNING"]
    assert audit.readiness_events and audit.readiness_events[0][0] is False
    app.stop()


def test_application_emits_readiness_only_on_change():
    sig=Signals(); audit=Audit(); app=RuntimeApplication(signals=sig, audit=audit)
    app.start(); count=len(audit.readiness_events)
    app.run_cycle(); assert len(audit.readiness_events)==count
    sig.ready=True
    app.run_cycle()
    assert len(audit.readiness_events)==count+1
    assert audit.readiness_events[-1][0] is True
    assert audit.readiness_events[-1][1] is True
    app.stop()


def test_audit_is_optional_and_does_not_change_lifecycle():
    app=RuntimeApplication(config=RuntimeConfig(poll_interval_seconds=0.01))
    app.start(); app.run_cycle(); app.stop()
    assert app.lifecycle.value=="STOPPED"
