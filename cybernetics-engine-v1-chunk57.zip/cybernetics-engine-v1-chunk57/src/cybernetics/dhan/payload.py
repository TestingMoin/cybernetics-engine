from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class DhanOrderPayload:
    dhanClientId:str; correlationId:str; transactionType:str; exchangeSegment:str
    productType:str; orderType:str; validity:str; securityId:str; quantity:int
    disclosedQuantity:int=0; price:float=0.0; triggerPrice:float=0.0
    afterMarketOrder:bool=False; amoTime:str=""
    boProfitValue:float=0.0; boStopLossValue:float=0.0
    def as_dict(self)->dict[str,Any]:
        return {
          "dhanClientId":self.dhanClientId,"correlationId":self.correlationId,
          "transactionType":self.transactionType,"exchangeSegment":self.exchangeSegment,
          "productType":self.productType,"orderType":self.orderType,"validity":self.validity,
          "securityId":self.securityId,"quantity":self.quantity,
          "disclosedQuantity":self.disclosedQuantity,"price":self.price,
          "triggerPrice":self.triggerPrice,"afterMarketOrder":self.afterMarketOrder,
          "amoTime":self.amoTime,"boProfitValue":self.boProfitValue,
          "boStopLossValue":self.boStopLossValue
        }
