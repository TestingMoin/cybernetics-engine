# Cybernetics Trading Engine — Chunk 121

Hostinger staging preflight and deployment runbook.

This chunk intentionally does not connect to the user's VPS from the build environment. It adds a fail-closed staging preflight script and documents the exact deployment sequence for the existing `cybernetics` service account and `/opt/cybernetics-engine/` layout.
