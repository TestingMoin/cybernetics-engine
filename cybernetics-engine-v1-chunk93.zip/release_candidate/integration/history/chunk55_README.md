# Cybernetics Trading Engine — Chunk 55

## Execution Intent → Instrument Binding

This chunk binds the broker-neutral `ExecutionIntent` to one exact, already
eligible `TradeInstrument`.

Result:

`ExecutionIntent + TradeInstrument -> BoundExecutionInstruction`

The binding boundary revalidates:
- instrument identity
- intent/instrument symbol match
- positive quantity
- lot-size alignment
- tick-size validity
- LIMIT price validity and tick-grid alignment
- option expiry/strike/type fields

The resulting object is broker-ready in the architectural sense, but it is
**not a Dhan API payload** and cannot submit anything by itself.

No credentials, access tokens, broker API payloads, or order submission logic
are included.
