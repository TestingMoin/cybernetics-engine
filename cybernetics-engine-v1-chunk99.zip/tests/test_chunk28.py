from cybernetics.brokers.dhan_v2 import DhanV2OrderAdapter, DhanOrderRequest, DhanApiError

def req():
    return DhanOrderRequest(
        client_order_key="CTE-001",
        dhan_client_id="1000000000",
        security_id="999",
        transaction_type="BUY",
        exchange_segment="NSE_FNO",
        product_type="INTRADAY",
        order_type="MARKET",
        quantity=50,
    )

def test_place_order_maps_dhan_fields_and_headers():
    calls=[]
    def transport(method,url,headers,**kwargs):
        calls.append((method,url,headers,kwargs))
        return {"orderId":"D1","orderStatus":"TRANSIT"}
    a=DhanV2OrderAdapter(transport,"TOKEN")
    out=a.place_order(req())
    assert out.accepted and out.broker_order_id=="D1"
    assert calls[0][0]=="POST"
    assert calls[0][2]["access-token"]=="TOKEN"
    assert calls[0][3]["json"]["correlationId"]=="CTE-001"

def test_correlation_lookup_uses_external_endpoint():
    def transport(method,url,headers,**kwargs):
        assert method=="GET"
        assert url.endswith("/orders/external/CTE-002")
        return {"orderId":"D2","orderStatus":"TRADED"}
    a=DhanV2OrderAdapter(transport,"TOKEN")
    out=a.get_order_by_correlation_id("CTE-002")
    assert out.accepted and out.broker_order_id=="D2"

def test_cancel_normalizes_rejected_response():
    def transport(method,url,headers,**kwargs):
        assert method=="DELETE"
        return {"orderId":"D3","orderStatus":"CANCELLED","message":"Cancelled"}
    a=DhanV2OrderAdapter(transport,"TOKEN")
    out=a.cancel_order("D3")
    assert not out.accepted and out.order_status=="CANCELLED"
    assert out.broker_order_id=="D3"

def test_api_error_response_is_not_marked_accepted():
    def transport(*args,**kwargs):
        return {"errorType":"AUTH","errorCode":"E1","errorMessage":"bad token"}
    a=DhanV2OrderAdapter(transport,"TOKEN")
    out=a.get_order("D4")
    assert out.accepted is False
    assert out.message=="bad token"

def test_non_dict_response_is_rejected():
    def transport(*args,**kwargs):
        return "bad"
    a=DhanV2OrderAdapter(transport,"TOKEN")
    try:
        a.get_order("D5")
        assert False
    except DhanApiError:
        assert True

def test_token_required():
    try:
        DhanV2OrderAdapter(lambda *a,**k:{}, "")
        assert False
    except ValueError as e:
        assert str(e)=="access_token_required"
