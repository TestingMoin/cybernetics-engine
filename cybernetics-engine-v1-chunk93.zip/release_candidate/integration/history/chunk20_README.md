# Cybernetics Trading Engine — Chunk 20

Watchdog + Health Registry + Heartbeat Supervision.

Monitored components can include:
- engine
- Dhan connectivity
- market data
- database
- scanners
- strategies
- reconciliation

A failed/degraded/stale required component produces a safe-state requirement.
This chunk does not mutate broker state or place orders.
