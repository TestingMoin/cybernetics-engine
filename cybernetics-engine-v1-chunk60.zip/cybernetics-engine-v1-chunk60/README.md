# Cybernetics Trading Engine — Chunk 60

## Order Manager + Persistent Ledger + Reconciliation Integration

This chunk connects broker updates to a durable order-management boundary.

Flow:

Dhan REST/WebSocket Update
→ canonical broker response
→ Order Manager
→ Persistent Order Ledger

Key properties:
- durable order state is authoritative
- duplicate broker updates are idempotent
- partial fills are persisted
- terminal-state regression is rejected
- UNKNOWN orders remain explicitly unresolved until reconciliation
- correlation ID and broker order ID can both resolve an order
- startup recovery can classify active/unknown/terminal records

This chunk uses a ledger protocol rather than creating another database
implementation. The existing PostgreSQL order ledger from the earlier chunks
remains the intended production persistence layer.

No Position Manager mutation is performed here. Position updates must be driven
from validated fills through the existing position-management boundary.
