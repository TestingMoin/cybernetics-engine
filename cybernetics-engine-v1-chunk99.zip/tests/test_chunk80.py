from cybernetics.emergency.flatten import (
    EmergencyFlattenCoordinator, OpenPosition, FlattenDecision,
    ExitOrderState, EmergencyExitExecutor
)
from cybernetics.emergency.memory import InMemoryEmergencyFlattenState
import pytest


def pos(pid="P1",sid="NIFTY",side="BUY",qty=25):
    return OpenPosition(pid,sid,side,qty)


def test_inactive_emergency_blocks():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E1",request_id="R1",positions=[pos()],
        emergency_active=False,broker_available=True
    )
    assert r.decision is FlattenDecision.BLOCKED


def test_broker_unavailable_blocks_flatten():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E1",request_id="R1",positions=[pos()],
        emergency_active=True,broker_available=False
    )
    assert r.decision is FlattenDecision.BLOCKED


def test_missing_ids_block():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="",request_id="R1",positions=[],
        emergency_active=True,broker_available=True
    )
    assert r.decision is FlattenDecision.BLOCKED


def test_buy_position_creates_sell_intent():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E1",request_id="R1",positions=[pos()],
        emergency_active=True,broker_available=True
    )
    assert r.decision is FlattenDecision.READY
    assert r.intents[0].exit_side=="SELL"
    assert r.intents[0].quantity==25


def test_sell_position_creates_buy_intent():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E1",request_id="R1",positions=[pos(side="SELL")],
        emergency_active=True,broker_available=True
    )
    assert r.intents[0].exit_side=="BUY"


def test_zero_quantity_is_ignored():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E1",request_id="R1",positions=[pos(qty=0)],
        emergency_active=True,broker_available=True
    )
    assert r.intents==()


def test_invalid_side_blocks_plan():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E1",request_id="R1",positions=[pos(side="HOLD")],
        emergency_active=True,broker_available=True
    )
    assert r.decision is FlattenDecision.BLOCKED


def test_invalid_position_identity_blocks_plan():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E1",request_id="R1",positions=[pos(pid="")],
        emergency_active=True,broker_available=True
    )
    assert r.decision is FlattenDecision.BLOCKED


def test_repeated_emergency_request_is_idempotent():
    state=InMemoryEmergencyFlattenState()
    c=EmergencyFlattenCoordinator(state)
    first=c.plan(
        emergency_id="E1",request_id="R1",positions=[pos()],
        emergency_active=True,broker_available=True
    )
    second=c.plan(
        emergency_id="E1",request_id="R2",positions=[pos()],
        emergency_active=True,broker_available=True
    )
    assert len(first.intents)==1
    assert second.intents==()
    assert second.reason=="emergency_flatten_already_requested"


def test_one_position_gets_one_intent():
    state=InMemoryEmergencyFlattenState()
    c=EmergencyFlattenCoordinator(state)
    r=c.plan(
        emergency_id="E1",request_id="R1",
        positions=[pos(),pos(pid="P2",sid="BANKNIFTY",qty=15)],
        emergency_active=True,broker_available=True
    )
    assert len(r.intents)==2
    assert len({x.intent_id for x in r.intents})==2


def test_intent_id_is_deterministic():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E7",request_id="R1",positions=[pos("P9")],
        emergency_active=True,broker_available=True
    )
    assert r.intents[0].intent_id=="EMERGENCY:E7:P9"


def test_executor_preserves_completed():
    intent=EmergencyFlattenCoordinator(
        InMemoryEmergencyFlattenState()
    ).plan(
        emergency_id="E1",request_id="R1",positions=[pos()],
        emergency_active=True,broker_available=True
    ).intents
    out=EmergencyExitExecutor().execute(
        intent, submit_exit=lambda x: ExitOrderState.COMPLETED
    )
    assert out[0][1] is ExitOrderState.COMPLETED


def test_executor_preserves_unknown_for_reconciliation():
    intent=EmergencyFlattenCoordinator(
        InMemoryEmergencyFlattenState()
    ).plan(
        emergency_id="E1",request_id="R1",positions=[pos()],
        emergency_active=True,broker_available=True
    ).intents
    out=EmergencyExitExecutor().execute(
        intent, submit_exit=lambda x: ExitOrderState.UNKNOWN
    )
    assert out[0][1] is ExitOrderState.UNKNOWN


def test_executor_does_not_convert_unknown_to_complete():
    intent=EmergencyFlattenCoordinator(
        InMemoryEmergencyFlattenState()
    ).plan(
        emergency_id="E1",request_id="R1",positions=[pos()],
        emergency_active=True,broker_available=True
    ).intents
    out=EmergencyExitExecutor().execute(
        intent, submit_exit=lambda x: ExitOrderState.UNKNOWN
    )
    assert out[0][1] != ExitOrderState.COMPLETED


def test_executor_blocks_unsupported_state():
    intent=EmergencyFlattenCoordinator(
        InMemoryEmergencyFlattenState()
    ).plan(
        emergency_id="E1",request_id="R1",positions=[pos()],
        emergency_active=True,broker_available=True
    ).intents
    out=EmergencyExitExecutor().execute(
        intent, submit_exit=lambda x: ExitOrderState.PLANNED
    )
    assert out[0][1] is ExitOrderState.BLOCKED


def test_planner_does_not_size_position():
    intent=EmergencyFlattenCoordinator(
        InMemoryEmergencyFlattenState()
    ).plan(
        emergency_id="E1",request_id="R1",positions=[pos(qty=37)],
        emergency_active=True,broker_available=True
    ).intents[0]
    assert intent.quantity==37


def test_flatten_path_has_no_entry_endpoint():
    from pathlib import Path
    for f in ("src/cybernetics/emergency/flatten.py",):
        src=Path(f).read_text()
        for token in ("/v2/orders","place_order","submit_order","new_entry"):
            assert token not in src


def test_flatten_path_does_not_create_live_authorization():
    from pathlib import Path
    src=Path("src/cybernetics/emergency/flatten.py").read_text()
    assert "authorize_live" not in src


def test_multiple_positions_keep_isolation():
    c=EmergencyFlattenCoordinator(InMemoryEmergencyFlattenState())
    r=c.plan(
        emergency_id="E9",request_id="R9",
        positions=[
            pos("P1","NIFTY","BUY",25),
            pos("P2","BANKNIFTY","SELL",15),
            pos("P3","SENSEX","BUY",10),
        ],
        emergency_active=True,broker_available=True
    )
    assert [(i.security_id,i.exit_side,i.quantity) for i in r.intents] == [
        ("NIFTY","SELL",25),("BANKNIFTY","BUY",15),("SENSEX","SELL",10)
    ]
