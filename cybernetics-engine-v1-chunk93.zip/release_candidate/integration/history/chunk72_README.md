# Cybernetics Trading Engine — Chunk 72

## Startup Recovery Orchestrator

This chunk establishes the restart gate for the engine.

A process restart does not automatically imply trading readiness.

Startup sequence:

1. Validate persistence.
2. Discover unresolved recovery cases.
3. Reconcile broker/internal orders.
4. Reconcile broker/internal positions.
5. Evaluate overall readiness.
6. Only then allow the engine to become READY.

The readiness evaluator separately distinguishes:

- engine readiness
- readiness for new trades

Emergency stop and live authorization therefore remain independent gates.

This component never enables live trading and never submits, cancels, or
replaces broker orders.

### Production integration boundary

The orchestrator receives an injected dependency interface. The actual database,
broker adapter, market-feed health registry, scanner registry, and control-state
components are connected later by the unified application composition layer.
