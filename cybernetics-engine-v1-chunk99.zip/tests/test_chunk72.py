from cybernetics.recovery.startup import (
    StartupRecoveryOrchestrator, StartupStage, Readiness
)
from cybernetics.recovery.readiness import (
    ReadinessInputs, evaluate_readiness
)


class Deps:
    def __init__(
        self,
        persistence=True,
        unresolved=(),
        orders=True,
        positions=True,
    ):
        self.persistence=persistence
        self.unresolved=tuple(unresolved)
        self.orders=orders
        self.positions=positions
        self.calls=[]
    def validate_persistence(self):
        self.calls.append("persistence")
        return self.persistence
    def find_unresolved_recovery_cases(self):
        self.calls.append("recovery")
        return self.unresolved
    def reconcile_orders(self):
        self.calls.append("orders")
        return self.orders
    def reconcile_positions(self):
        self.calls.append("positions")
        return self.positions


def ready_inputs(**overrides):
    values=dict(
        persistence_ready=True,
        recovery_clear=True,
        orders_reconciled=True,
        positions_reconciled=True,
        market_data_ready=True,
        scanner_health_ready=True,
        emergency_stop_active=False,
        live_authorization_valid=True,
    )
    values.update(overrides)
    return ReadinessInputs(**values)


def test_persistence_failure_blocks_first():
    d=Deps(persistence=False)
    r=StartupRecoveryOrchestrator(d).run()
    assert r.stage is StartupStage.BLOCKED
    assert r.readiness is Readiness.BLOCKED
    assert d.calls == ["persistence"]


def test_unresolved_recovery_blocks_before_reconciliation():
    d=Deps(unresolved=["R1","R2"])
    r=StartupRecoveryOrchestrator(d).run()
    assert r.stage is StartupStage.BLOCKED
    assert "UNRESOLVED_RECOVERY_CASES" in [x.code for x in r.findings]
    assert d.calls == ["persistence","recovery"]


def test_order_reconciliation_failure_blocks():
    d=Deps(orders=False)
    r=StartupRecoveryOrchestrator(d).run()
    assert r.readiness is Readiness.BLOCKED
    assert d.calls == ["persistence","recovery","orders"]


def test_position_reconciliation_failure_blocks():
    d=Deps(positions=False)
    r=StartupRecoveryOrchestrator(d).run()
    assert r.readiness is Readiness.BLOCKED
    assert d.calls == ["persistence","recovery","orders","positions"]


def test_clean_start_reaches_ready():
    d=Deps()
    r=StartupRecoveryOrchestrator(d).run()
    assert r.stage is StartupStage.READY
    assert r.readiness is Readiness.READY
    assert d.calls == ["persistence","recovery","orders","positions"]


def test_engine_readiness_requires_persistence():
    d=evaluate_readiness(ready_inputs(persistence_ready=False))
    assert not d.ready_for_engine
    assert not d.ready_for_new_trades
    assert "persistence_not_ready" in d.reasons


def test_engine_readiness_requires_recovery_clear():
    d=evaluate_readiness(ready_inputs(recovery_clear=False))
    assert not d.ready_for_engine


def test_engine_readiness_requires_orders():
    d=evaluate_readiness(ready_inputs(orders_reconciled=False))
    assert not d.ready_for_engine


def test_engine_readiness_requires_positions():
    d=evaluate_readiness(ready_inputs(positions_reconciled=False))
    assert not d.ready_for_engine


def test_engine_readiness_requires_market_data():
    d=evaluate_readiness(ready_inputs(market_data_ready=False))
    assert not d.ready_for_engine


def test_engine_readiness_requires_scanner_health():
    d=evaluate_readiness(ready_inputs(scanner_health_ready=False))
    assert not d.ready_for_engine


def test_engine_can_be_ready_while_live_authorization_is_invalid():
    d=evaluate_readiness(ready_inputs(live_authorization_valid=False))
    assert d.ready_for_engine
    assert not d.ready_for_new_trades
    assert "live_authorization_invalid" in d.reasons


def test_engine_can_be_ready_while_emergency_stop_is_active():
    d=evaluate_readiness(ready_inputs(emergency_stop_active=True))
    assert d.ready_for_engine
    assert not d.ready_for_new_trades
    assert "emergency_stop_active" in d.reasons


def test_all_gates_allow_new_trades():
    d=evaluate_readiness(ready_inputs())
    assert d.ready_for_engine
    assert d.ready_for_new_trades
    assert d.reasons == ()


def test_recovery_and_live_auth_are_independent():
    d=evaluate_readiness(
        ready_inputs(recovery_clear=False, live_authorization_valid=True)
    )
    assert not d.ready_for_engine
    assert not d.ready_for_new_trades
    assert "recovery_not_clear" in d.reasons


def test_no_broker_order_mutation_in_startup_source():
    from pathlib import Path
    src=Path("src/cybernetics/recovery/startup.py").read_text()
    for token in ("place_order", "cancel_order", "replace_order", "/v2/orders"):
        assert token not in src
