from cybernetics.paper.order import PaperBroker
from cybernetics.paper.portfolio import PaperPortfolio

def test_market_fill_has_slippage_and_fee():
    b=PaperBroker(fee_bps=5, slippage_bps=10)
    b.submit("NIFTY","BUY",10,"MARKET",100)
    f=b.fills[-1]
    assert f.quantity==10
    assert f.price==100.1
    assert f.fee>0

def test_zero_price_is_rejected():
    b=PaperBroker()
    try: b.submit("NIFTY","BUY",1,"MARKET",0)
    except ValueError: return
    assert False

def test_limit_only_fills_when_reached():
    b=PaperBroker()
    o=b.submit("NIFTY","BUY",10,"LIMIT",100,99)
    assert b.process_limit(o.order_id,100.5) is False
    assert b.process_limit(o.order_id,98.5) is True
    assert len(b.fills)==1

def test_portfolio_snapshot():
    b=PaperBroker()
    b.submit("NIFTY","BUY",10,"MARKET",100)
    s=PaperPortfolio(b).snapshot()
    assert s.open_positions==1 and s.fees>0

def test_no_real_broker_dependency():
    assert "dhan" not in PaperBroker.submit.__code__.co_names
