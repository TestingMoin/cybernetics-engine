from cybernetics.positions.position import PositionManager
from cybernetics.positions.exit import ExitManager, ExitPlan

def test_long_position_and_mtm():
    p=PositionManager().apply_fill("NIFTY","BUY",10,100,fee=1)
    p.last_price=105
    assert p.quantity==10 and p.side=="LONG" and p.unrealized_pnl==50

def test_partial_close_realized_pnl():
    m=PositionManager()
    m.apply_fill("NIFTY","BUY",10,100)
    p=m.apply_fill("NIFTY","SELL",4,110)
    assert p.quantity==6 and p.realized_pnl==40

def test_reversal_resets_average_price():
    m=PositionManager()
    m.apply_fill("NIFTY","BUY",10,100)
    p=m.apply_fill("NIFTY","SELL",15,95)
    assert p.quantity==-5 and p.avg_price==95

def test_exit_long_stop_and_target():
    e=ExitManager()
    assert e.evaluate(ExitPlan("NIFTY","LONG",100,stop_price=99,target_price=101),98).reason=="STOP_LOSS"
    assert e.evaluate(ExitPlan("NIFTY","LONG",100,stop_price=99,target_price=101),102).reason=="TAKE_PROFIT"

def test_exit_does_not_execute():
    assert not hasattr(ExitManager(),"place_order")
