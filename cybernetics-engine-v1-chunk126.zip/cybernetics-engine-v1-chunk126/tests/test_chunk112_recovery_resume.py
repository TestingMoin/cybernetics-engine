from cybernetics.runtime.failure_handling import RuntimeDependencyFailureHandler
from cybernetics.runtime.recovery_resume import RecoveryPhase, SafeStateRecoveryCoordinator
from cybernetics.runtime.state import ControlState, EmergencyState


def healthy():
    return {name: True for name in RuntimeDependencyFailureHandler.CRITICAL_DEPENDENCIES}


def test_failure_enters_recovery_required():
    r = SafeStateRecoveryCoordinator()
    data = healthy(); data["broker"] = False
    status = r.observe(data, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=False)
    assert status.phase is RecoveryPhase.RECOVERY_REQUIRED
    assert status.resume_allowed is False


def test_health_recovery_does_not_auto_resume():
    events = []
    r = SafeStateRecoveryCoordinator(set_control_state=events.append)
    unhealthy = healthy(); unhealthy["market_data"] = False
    r.observe(unhealthy, control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    status = r.observe(healthy(), control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert status.phase is RecoveryPhase.RECOVERY_READY
    assert status.resume_allowed is True
    assert events == []


def test_recovery_requires_stop_new_trades_control():
    r = SafeStateRecoveryCoordinator(set_control_state=lambda _: None)
    bad = healthy(); bad["broker"] = False
    r.observe(bad, control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    status = r.observe(healthy(), control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert status.phase is RecoveryPhase.RECOVERY_REQUIRED
    assert status.reason == "safe_control_state_required"


def test_recovery_requires_live_authorization():
    r = SafeStateRecoveryCoordinator(set_control_state=lambda _: None)
    bad = healthy(); bad["broker"] = False
    r.observe(bad, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=False)
    status = r.observe(healthy(), control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=False)
    assert status.phase is RecoveryPhase.RECOVERY_REQUIRED
    assert status.reason == "live_authorization_required_for_resume"


def test_recovery_ready_requires_explicit_resume():
    events = []
    r = SafeStateRecoveryCoordinator(set_control_state=events.append)
    bad = healthy(); bad["persistence"] = False
    r.observe(bad, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    r.observe(healthy(), control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert events == []
    status = r.resume(control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True, readiness=healthy())
    assert status.phase is RecoveryPhase.RESUMED
    assert events == [ControlState.RUNNING]


def test_resume_blocked_by_emergency():
    r = SafeStateRecoveryCoordinator(set_control_state=lambda _: None)
    bad = healthy(); bad["broker"] = False
    r.observe(bad, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    r.observe(healthy(), control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    try:
        r.resume(control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.ACTIVE, live_authorization_valid=True, readiness=healthy())
    except RuntimeError as exc:
        assert str(exc) == "emergency_stop_active"
    else:
        raise AssertionError("expected emergency block")


def test_resume_blocked_if_dependency_fails_again():
    r = SafeStateRecoveryCoordinator(set_control_state=lambda _: None)
    bad = healthy(); bad["broker"] = False
    r.observe(bad, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    r.observe(healthy(), control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    again = healthy(); again["broker"] = False
    try:
        r.resume(control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True, readiness=again)
    except RuntimeError as exc:
        assert str(exc) == "dependencies_not_healthy"
    else:
        raise AssertionError("expected dependency block")
    assert r.status.phase is RecoveryPhase.RECOVERY_REQUIRED


def test_resume_requires_callback():
    r = SafeStateRecoveryCoordinator()
    bad = healthy(); bad["watchdog"] = False
    r.observe(bad, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    r.observe(healthy(), control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    try:
        r.resume(control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True, readiness=healthy())
    except RuntimeError as exc:
        assert str(exc) == "resume_callback_required"
    else:
        raise AssertionError("expected callback requirement")


def test_observe_preserves_resumed_state():
    events=[]
    r = SafeStateRecoveryCoordinator(set_control_state=events.append)
    bad=healthy(); bad["scanners"]=False
    r.observe(bad, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    r.observe(healthy(), control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    r.resume(control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True, readiness=healthy())
    status=r.observe(healthy(), control_state=ControlState.RUNNING, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert status.phase is RecoveryPhase.RESUMED
    assert status.reason == "resumed"


def test_new_failure_after_ready_returns_to_recovery_required():
    r = SafeStateRecoveryCoordinator(set_control_state=lambda _: None)
    bad=healthy(); bad["persistence"]=False
    r.observe(bad, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    r.observe(healthy(), control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    worse=healthy(); worse["broker"]=False
    status=r.observe(worse, control_state=ControlState.STOP_NEW_TRADES, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert status.phase is RecoveryPhase.RECOVERY_REQUIRED
    assert status.failures == ("broker",)
