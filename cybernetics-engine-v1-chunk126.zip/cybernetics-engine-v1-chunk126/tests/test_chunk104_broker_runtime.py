from dataclasses import dataclass

import pytest

from cybernetics.brokers.interface import BrokerAdapter, BrokerOrderRequest, BrokerOrderResult
from cybernetics.runtime.broker import BrokerRuntimeWiring, build_broker_runtime_wiring


@dataclass
class HealthyBroker(BrokerAdapter):
    configured: bool = True
    authenticated: bool = True

    name: str = "TEST"

    def health(self):
        return {"broker": self.name, "configured": self.configured, "authenticated": self.authenticated}

    def get_positions(self): return []
    def get_orders(self): return []
    def place_order(self, request: BrokerOrderRequest):
        return BrokerOrderResult(self.name, False, None, "BLOCKED")
    def cancel_order(self, broker_order_id: str):
        return BrokerOrderResult(self.name, False, broker_order_id, "BLOCKED")


def test_healthy_configured_authenticated_broker_is_ready():
    assert BrokerRuntimeWiring(HealthyBroker()).broker_available() is True


def test_unconfigured_broker_fails_closed():
    assert BrokerRuntimeWiring(HealthyBroker(configured=False)).broker_available() is False


def test_unauthenticated_broker_fails_closed_when_reported():
    assert BrokerRuntimeWiring(HealthyBroker(authenticated=False)).broker_available() is False


def test_probe_exception_fails_closed():
    class Broken(HealthyBroker):
        def health(self):
            raise RuntimeError("boom")
    assert BrokerRuntimeWiring(Broken()).broker_available() is False


def test_custom_readiness_is_used():
    broker = HealthyBroker(configured=False)
    wiring = build_broker_runtime_wiring(broker=broker, readiness=lambda _: True)
    assert wiring.broker_available() is True


def test_none_broker_rejected():
    with pytest.raises(ValueError, match="broker_adapter_required"):
        build_broker_runtime_wiring(broker=None)  # type: ignore[arg-type]


def test_health_report_is_safe_copy():
    report = BrokerRuntimeWiring(HealthyBroker()).health()
    assert report["configured"] is True
    assert report["authenticated"] is True


def test_legacy_configured_only_adapter_is_supported():
    class Legacy(HealthyBroker):
        def health(self):
            return {"configured": True}
    assert BrokerRuntimeWiring(Legacy()).broker_available() is True
