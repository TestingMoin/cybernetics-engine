# Cybernetics Trading Engine — Build Status

## Chunk 1
- Foundation repository created.
- Paper-first controls.
- Configuration-driven scanner registry/universe foundation.
- Tests: 5/5 previously passing.

## Chunk 2 — completed in local build
- Dhan 24-hour TOTP token manager (secrets never logged).
- Central Dhan API rate-limit governor.
- Async SQLAlchemy database foundation for SQLite/PostgreSQL.
- Dhan detailed/compact instrument-master downloader with atomic file replacement.
- Settings extended for Dhan PIN/TOTP and instrument-master path.
- Dhan current documented limits wired into local governor: Order 10/sec, 250/min, 1000/hr, 7000/day; Data 5/sec, 100000/day; Quote 1/sec; Non-trading 20/sec.

## Safety
- Live trading remains OFF.
- No broker order transport is enabled by this chunk.
- No credentials or access tokens are included in source.

## Chunk 3 — completed in local build
- Dhan V2 async REST transport with token-manager integration and one-time 401 re-auth retry.
- Read-only broker adapter for profile/holdings/positions/orders/trades.
- Market Quote LTP/OHLC/Quote methods and Option Chain/Expiry methods.
- Reconnectable Dhan market-feed WebSocket transport (raw binary packets; decoder deferred to next data-normalization chunk).
- Reconnectable Dhan Live Order Update WebSocket transport.
- Corrected main.py to use control_api_host/control_api_port from Settings.
- Added websocket dependency and transport tests using httpx MockTransport.

## Safety
- Live order placement remains deliberately disabled.
- No order/cancel REST transport is exposed through the adapter yet.
- No credentials or access tokens are embedded in source.
