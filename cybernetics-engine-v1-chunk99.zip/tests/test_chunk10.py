from cybernetics.analytics.ichimoku import IchimokuEngine
from cybernetics.analytics.gann import GannCycleDecoder
from cybernetics.intelligence.gap import GapEngine
from cybernetics.analytics.research_registry import ResearchRegistry, ResearchAsset

class Bar:
    def __init__(self, ts, open, high, low, close, volume=0):
        self.ts=ts; self.open=open; self.high=high; self.low=low; self.close=close; self.volume=volume

def bars(n=60):
    return [Bar(i,100+i,102+i,99+i,101+i,1000) for i in range(n)]

def test_ichimoku():
    x=IchimokuEngine().compute(bars())
    assert x.conversion is not None and x.base is not None and x.span_b is not None and x.span_a is not None

def test_gann_cycle():
    x=GannCycleDecoder().decode(0,100,90,30,2)
    assert x.period_bars == 30 and x.cycle_ratio == 3.0
    assert x.projected_price == 106

def test_gann_square_levels():
    assert len(GannCycleDecoder().square_of_nine_level(100)) == 4

def test_gap():
    x=GapEngine().evaluate("NIFTY","2026-09-07",100,105,102)
    assert x.gap_type=="GAP_UP"
    assert x.state=="REJECTED"
    assert 0 < x.fill_percent < 100

def test_research_registry():
    r=ResearchRegistry()
    r.add(ResearchAsset("STRAT-NIFTY","Optimized Intraday Strategy","PINE","GOLDEN"))
    assert r.get("STRAT-NIFTY").status=="GOLDEN"
