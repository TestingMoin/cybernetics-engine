# Cybernetics Trading Engine — Chunk 35

## Canonical Market State Store + Atomic Merge + Live/REST Reconciliation

This chunk establishes one authoritative candle store for downstream analytics.

### Canonical key
`(security_id, timestamp)`

### Merge policy
- New key → INSERTED.
- Same key with identical candle → DUPLICATE.
- Same key with different values → CONFLICT; existing canonical value is not overwritten.

### Reconciliation
Live-derived and REST-derived candles can be compared to identify:
- CONSISTENT state
- REST_AHEAD
- LIVE_AHEAD
- INCOMPLETE
- CONFLICT

A conflict or incomplete state is reported rather than silently repaired.

This component does not decide trades. It supplies a trustworthy market-state boundary
for the data-quality and execution safety layers.
