from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Any

class ExecutionAction(str,Enum): BUY="BUY"; SELL="SELL"
class OrderType(str,Enum): MARKET="MARKET"; LIMIT="LIMIT"

@dataclass(frozen=True)
class ExecutionIntent:
    intent_id:str; trade_id:str; strategy_id:str; strategy_version:str; signal_id:str
    underlying_key:str; action:ExecutionAction; order_type:OrderType; quantity:int
    limit_price:Optional[float]=None; product_type:str="INTRADAY"; validity:str="DAY"
    metadata:dict[str,Any]=field(default_factory=dict)
    def __post_init__(self):
        if not self.intent_id or not self.trade_id or not self.strategy_id:
            raise ValueError("execution_intent_identity_required")
        if self.quantity<=0: raise ValueError("execution_quantity_must_be_positive")
        if self.order_type==OrderType.LIMIT and (self.limit_price is None or self.limit_price<=0):
            raise ValueError("limit_price_required_for_limit_order")
        if self.order_type==OrderType.MARKET and self.limit_price is not None:
            raise ValueError("market_order_cannot_have_limit_price")

@dataclass(frozen=True)
class ExecutionIntentBuilder:
    def build(self,*,approved,trade_id,strategy_id,strategy_version,signal_id,
              underlying_key,action,quantity,order_type="MARKET",limit_price=None,
              product_type="INTRADAY",validity="DAY",metadata=None):
        if not approved: raise PermissionError("pretrade_approval_required")
        a=ExecutionAction(str(action).upper()); o=OrderType(str(order_type).upper())
        return ExecutionIntent(
            f"{trade_id}:{signal_id}:{a.value}:{quantity}:{o.value}",trade_id,strategy_id,
            strategy_version,signal_id,underlying_key,a,o,quantity,limit_price,
            product_type,validity,metadata or {})
