# Cybernetics Trading Engine — Chunk 18

Broker Reconciliation Engine.

Compares internal and broker:
- orders
- fill quantities
- statuses
- average prices
- positions
- position quantities

Any mismatch creates a reconciliation issue and blocks new trades until resolved.
This chunk performs no broker mutation and no order execution.
