from cybernetics.runtime.control import (
    ControlAction, ControlState, ControlStateMachine, GuardedController,
    TransitionPolicy,
)
from cybernetics.runtime.control_recovery import ControlRecoveryIntegration
from cybernetics.runtime.failure_handling import RuntimeDependencyFailureHandler
from cybernetics.runtime.state import EmergencyState
from cybernetics.runtime.recovery_resume import RecoveryPhase


def healthy():
    return {name: True for name in RuntimeDependencyFailureHandler.CRITICAL_DEPENDENCIES}


def controller_at_stop():
    c = GuardedController(ControlStateMachine(ControlState.ENGINE_OFF))
    c.apply(ControlAction.START)
    c.apply(ControlAction.START_SUCCESS)
    c.apply(ControlAction.STOP_NEW_TRADES)
    return c


def test_observe_uses_authoritative_machine_state():
    c = controller_at_stop()
    i = ControlRecoveryIntegration(c)
    bad = healthy(); bad["broker"] = False
    s = i.observe(bad, control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert s.phase is RecoveryPhase.RECOVERY_REQUIRED
    assert c.machine.state is ControlState.STOP_NEW_TRADES


def test_health_recovery_does_not_transition_control():
    c = controller_at_stop(); i = ControlRecoveryIntegration(c)
    bad = healthy(); bad["market_data"] = False
    i.observe(bad, control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    s = i.observe(healthy(), control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert s.phase is RecoveryPhase.RECOVERY_READY
    assert c.machine.state is ControlState.STOP_NEW_TRADES


def test_explicit_resume_uses_guarded_state_machine():
    c = controller_at_stop(); i = ControlRecoveryIntegration(c)
    bad = healthy(); bad["watchdog"] = False
    i.observe(bad, control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    i.observe(healthy(), control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    s = i.explicit_resume(healthy(), emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert s.phase is RecoveryPhase.RESUMED
    assert c.machine.state is ControlState.RUNNING


def test_explicit_resume_blocked_without_live_authorization():
    c = controller_at_stop(); i = ControlRecoveryIntegration(c)
    bad = healthy(); bad["scanners"] = False
    i.observe(bad, control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    i.observe(healthy(), control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=False)
    assert i.recovery.status.phase is RecoveryPhase.RECOVERY_REQUIRED
    try:
        i.explicit_resume(healthy(), emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    except RuntimeError as exc:
        assert str(exc) == "recovery_not_ready_for_resume"
    else:
        raise AssertionError("expected recovery gate")


def test_explicit_resume_blocked_by_emergency():
    c = controller_at_stop(); i = ControlRecoveryIntegration(c)
    bad = healthy(); bad["persistence"] = False
    i.observe(bad, control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    i.observe(healthy(), control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    try:
        i.explicit_resume(healthy(), emergency_state=EmergencyState.ACTIVE, live_authorization_valid=True)
    except RuntimeError as exc:
        assert str(exc) == "emergency_stop_active"
    else:
        raise AssertionError("expected emergency block")
    assert c.machine.state is ControlState.STOP_NEW_TRADES


def test_resume_callback_cannot_bypass_running_transition():
    c = GuardedController(ControlStateMachine(ControlState.RUNNING))
    i = ControlRecoveryIntegration(c)
    try:
        i._resume_control_state(__import__("cybernetics.runtime.state", fromlist=["ControlState"]).ControlState.RUNNING)
    except Exception as exc:
        assert type(exc).__name__ == "InvalidTransition"
    else:
        raise AssertionError("expected guarded transition to reject resume from RUNNING")

def test_wrong_control_state_is_rejected_before_resume():
    c = GuardedController(ControlStateMachine(ControlState.RUNNING))
    i = ControlRecoveryIntegration(c)
    try:
        i.explicit_resume(healthy(), emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    except RuntimeError as exc:
        assert str(exc) == "resume_requires_stop_new_trades"
    else:
        raise AssertionError("expected control-state block")


def test_new_dependency_failure_after_ready_blocks_resume():
    c = controller_at_stop(); i = ControlRecoveryIntegration(c)
    bad = healthy(); bad["broker"] = False
    i.observe(bad, control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    i.observe(healthy(), control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    i.observe(bad, control_state=c.machine.state, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    try:
        i.explicit_resume(healthy(), emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    except RuntimeError as exc:
        assert str(exc) == "recovery_not_ready_for_resume"
    else:
        raise AssertionError("expected recovery-not-ready block")
