from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import FrozenSet


class ControlState(str, Enum):
    ENGINE_OFF = "ENGINE_OFF"
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    STOP_NEW_TRADES = "STOP_NEW_TRADES"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    RECOVERY = "RECOVERY"


class ControlAction(str, Enum):
    START = "START"
    START_SUCCESS = "START_SUCCESS"
    START_FAILURE = "START_FAILURE"
    STOP_NEW_TRADES = "STOP_NEW_TRADES"
    RESUME_NEW_TRADES = "RESUME_NEW_TRADES"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    BEGIN_RECOVERY = "BEGIN_RECOVERY"
    RECOVERY_COMPLETE = "RECOVERY_COMPLETE"
    SHUTDOWN = "SHUTDOWN"


@dataclass(frozen=True)
class Transition:
    source: ControlState
    action: ControlAction
    target: ControlState


class InvalidTransition(ValueError):
    pass


class ControlStateMachine:
    """
    Guarded control-state machine.

    This is the authoritative state-transition boundary for runtime controls.
    Live authorization is deliberately NOT created by any transition. It
    remains an independent prerequisite for new-trade permission.
    """

    _TRANSITIONS: FrozenSet[Transition] = frozenset({
        Transition(ControlState.ENGINE_OFF, ControlAction.START, ControlState.STARTING),
        Transition(ControlState.STARTING, ControlAction.START_SUCCESS, ControlState.RUNNING),
        Transition(ControlState.STARTING, ControlAction.START_FAILURE, ControlState.ENGINE_OFF),

        Transition(ControlState.RUNNING, ControlAction.STOP_NEW_TRADES, ControlState.STOP_NEW_TRADES),
        Transition(ControlState.STOP_NEW_TRADES, ControlAction.RESUME_NEW_TRADES, ControlState.RUNNING),

        Transition(ControlState.RUNNING, ControlAction.EMERGENCY_STOP, ControlState.EMERGENCY_STOP),
        Transition(ControlState.STOP_NEW_TRADES, ControlAction.EMERGENCY_STOP, ControlState.EMERGENCY_STOP),

        Transition(ControlState.EMERGENCY_STOP, ControlAction.BEGIN_RECOVERY, ControlState.RECOVERY),
        Transition(ControlState.RECOVERY, ControlAction.RECOVERY_COMPLETE, ControlState.STOP_NEW_TRADES),

        Transition(ControlState.RUNNING, ControlAction.SHUTDOWN, ControlState.ENGINE_OFF),
        Transition(ControlState.STOP_NEW_TRADES, ControlAction.SHUTDOWN, ControlState.ENGINE_OFF),
        Transition(ControlState.RECOVERY, ControlAction.SHUTDOWN, ControlState.ENGINE_OFF),
        Transition(ControlState.STARTING, ControlAction.SHUTDOWN, ControlState.ENGINE_OFF),
    })

    def __init__(self, initial: ControlState = ControlState.ENGINE_OFF):
        self._state = initial

    @property
    def state(self) -> ControlState:
        return self._state

    @classmethod
    def allowed_actions(cls, state: ControlState) -> FrozenSet[ControlAction]:
        return frozenset(
            t.action for t in cls._TRANSITIONS if t.source is state
        )

    @classmethod
    def target_for(cls, state: ControlState, action: ControlAction) -> ControlState:
        for transition in cls._TRANSITIONS:
            if transition.source is state and transition.action is action:
                return transition.target
        raise InvalidTransition(
            f"invalid_transition:{state.value}:{action.value}"
        )

    def transition(self, action: ControlAction) -> ControlState:
        self._state = self.target_for(self._state, action)
        return self._state


@dataclass(frozen=True)
class TransitionPolicy:
    """
    Additional guards for externally-requested actions.

    `live_authorization_valid` is only relevant to RESUME_NEW_TRADES and never
    gets created as a side effect of the transition itself.
    """
    live_authorization_valid: bool = False
    recovery_clear: bool = False

    def authorize(self, state: ControlState, action: ControlAction) -> bool:
        if action is ControlAction.RESUME_NEW_TRADES:
            return (
                state is ControlState.STOP_NEW_TRADES
                and self.live_authorization_valid
                and self.recovery_clear
            )
        if action is ControlAction.RECOVERY_COMPLETE:
            return state is ControlState.RECOVERY and self.recovery_clear
        return True


class GuardedController:
    def __init__(self, machine: ControlStateMachine):
        self.machine = machine

    def apply(self, action: ControlAction, policy: TransitionPolicy | None = None) -> ControlState:
        p = policy or TransitionPolicy()
        if not p.authorize(self.machine.state, action):
            raise InvalidTransition(
                f"policy_blocked:{self.machine.state.value}:{action.value}"
            )
        return self.machine.transition(action)
