# Cybernetics Trading Engine — Chunk 65

## PostgreSQL Transactional Fill Outbox Boundary

Chunk 64 made fill claim/complete state durable. Chunk 65 adds a persistent
outbox event so a canonical fill can be recorded as a durable event before
asynchronous downstream processing.

Schema:

`fill_outbox(event_id PRIMARY KEY, fill_id UNIQUE, order_id, trade_id,
payload_json, state, attempts, last_error, timestamps)`

States:
- PENDING
- PROCESSING
- COMPLETED
- FAILED

Processing:

Fill event
→ durable outbox INSERT
→ claim PENDING event
→ downstream consumer
→ COMPLETED

Failures are recorded as FAILED. They are not blindly retried by this
dispatcher.

Important: an outbox provides durable at-least-once-style delivery semantics;
it does not mathematically guarantee distributed exactly-once execution.
Consumers must remain idempotent using `event_id`/`fill_id`.

This chunk contains no broker calls.
