class SignalQualifier:
 def __init__(self,lifecycle,minimum_strength=0):self.minimum_strength=minimum_strength
 def qualify(self,sid,*,strength,scanner_healthy=True,data_ready=True):
  if not scanner_healthy:return type("Q",(),{"qualified":False,"reason":"scanner_unhealthy"})()
  if not data_ready:return type("Q",(),{"qualified":False,"reason":"market_data_not_ready"})()
  if strength<self.minimum_strength:return type("Q",(),{"qualified":False,"reason":"strength_below_threshold"})()
  return type("Q",(),{"qualified":True,"reason":"qualified"})()
