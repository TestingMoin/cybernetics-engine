# Chunk 119 — PostgreSQL Staging Connection Boundary

Built from the verified Chunk 118 baseline.

Adds a validated PostgreSQL staging configuration and injected connection probe. The core engine can distinguish NOT_CONFIGURED from FAILED and READY, while keeping the database driver outside the core dependency boundary. DSNs are validated and redacted for observability. No real PostgreSQL connection is attempted by the test suite, and no production database is modified.
