from cybernetics.persistence.repository import (
    FillPersistenceRepository, FillLedgerRecord, FillOutboxRecord,
    LedgerState, OutboxState
)
from cybernetics.persistence.transaction import atomic_fill_transaction


class Result:
    def __init__(self,rowcount=0): self.rowcount=rowcount


class FakeTx:
    def __init__(self, fetchone_values=None, fetchall_values=None, rowcount=1):
        self.calls=[]
        self.fetchone_values=list(fetchone_values or [])
        self.fetchall_values=list(fetchall_values or [])
        self.rowcount=rowcount
    def fetchone(self, sql, params=()):
        self.calls.append(("fetchone",sql,params))
        return self.fetchone_values.pop(0) if self.fetchone_values else None
    def fetchall(self, sql, params=()):
        self.calls.append(("fetchall",sql,params))
        return self.fetchall_values.pop(0) if self.fetchall_values else []
    def execute(self, sql, params=()):
        self.calls.append(("execute",sql,params))
        return Result(self.rowcount)


def test_claim_fill_idempotency_sql():
    tx=FakeTx(fetchone_values=[("F1",)])
    r=FillPersistenceRepository(tx)
    assert r.claim_fill(FillLedgerRecord("F1","O1","T1",LedgerState.CLAIMED))
    assert "ON CONFLICT (fill_id) DO NOTHING" in tx.calls[0][1]


def test_claim_fill_duplicate_returns_false():
    tx=FakeTx(fetchone_values=[None])
    r=FillPersistenceRepository(tx)
    assert r.claim_fill(FillLedgerRecord("F1","O1","T1",LedgerState.CLAIMED)) is False


def test_get_fill_maps_row():
    tx=FakeTx(fetchone_values=[("F1","O1","T1","CLAIMED",None)])
    got=FillPersistenceRepository(tx).get_fill("F1")
    assert got.state is LedgerState.CLAIMED
    assert got.fill_id=="F1"


def test_get_missing_fill():
    assert FillPersistenceRepository(FakeTx()).get_fill("missing") is None


def test_complete_fill_requires_claimed():
    tx=FakeTx(rowcount=1)
    assert FillPersistenceRepository(tx).complete_fill("F1")
    assert "state = %s" in tx.calls[0][1]


def test_recovery_update_is_parameterized():
    tx=FakeTx(rowcount=1)
    assert FillPersistenceRepository(tx).mark_recovery_required("F1","db-error")
    assert tx.calls[0][2][1]=="db-error"


def test_outbox_enqueue_uses_fill_id_uniqueness():
    tx=FakeTx(fetchone_values=[("E1",)])
    rec=FillOutboxRecord("E1","F1","O1","T1",{"a":1},OutboxState.PENDING)
    assert FillPersistenceRepository(tx).enqueue_outbox(rec)
    assert "ON CONFLICT (fill_id) DO NOTHING" in tx.calls[0][1]


def test_outbox_claim_rejects_nonpositive_limit():
    import pytest
    with pytest.raises(ValueError,match="limit_must_be_positive"):
        FillPersistenceRepository(FakeTx()).claim_outbox_batch(0)


def test_outbox_claim_uses_skip_locked():
    tx=FakeTx(fetchall_values=[[{"event_id":"E1"}]])
    rows=FillPersistenceRepository(tx).claim_outbox_batch(10)
    assert rows
    assert "SKIP LOCKED" in tx.calls[0][1]


def test_outbox_complete_updates_only_processing():
    tx=FakeTx(rowcount=1)
    assert FillPersistenceRepository(tx).complete_outbox("E1")
    assert "state = %s" in tx.calls[0][1]


def test_outbox_fail_updates_only_processing():
    tx=FakeTx(rowcount=1)
    assert FillPersistenceRepository(tx).fail_outbox("E1","handler error")
    assert tx.calls[0][2][1]=="handler error"


def test_repository_does_not_generate_broker_payload_fields():
    tx=FakeTx(fetchone_values=[("E1",)])
    rec=FillOutboxRecord("E1","F1","O1","T1",{"fill_qty":1},OutboxState.PENDING)
    FillPersistenceRepository(tx).enqueue_outbox(rec)
    assert "access-token" not in tx.calls[0][1].lower()
    assert "/v2/orders" not in tx.calls[0][1]


class FakeTransaction:
    def __init__(self): self.entered=False; self.exited=False
    def __enter__(self): self.entered=True; return "TX"
    def __exit__(self,*args): self.exited=True
    def transaction(self): return self


def test_atomic_transaction_delegates_to_connection():
    c=FakeTransaction()
    with atomic_fill_transaction(c) as tx:
        assert tx=="TX"
    assert c.entered and c.exited


def test_repository_is_injected_not_connection_owned():
    tx=FakeTx()
    repo=FillPersistenceRepository(tx)
    assert repo.tx is tx
