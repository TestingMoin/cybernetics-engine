# Cybernetics Trading Engine — Chunk 33

## Market Feed Supervisor + Multi-Connection Sharding + Health/Gap Detection

This chunk turns the Dhan five-connection capability into a deterministic feed-supervision
layer.

### Implemented
- Deterministic universe sharding across up to 5 feed connections.
- 5000-instrument per connection capacity guard.
- Assignment generation/version.
- Added/removed/unchanged universe diff.
- Connection health tracking.
- Last-message and last-binary-packet timestamps.
- STALE feed detection.
- DISCONNECTED feed detection.
- Reconnect counters/errors.
- `safe_for_market_state()` gate: the market-data state is unsafe until every registered
  shard is healthy.

Dhan currently documents up to five live market-feed WebSocket connections and 5000
instruments per connection. The feed server sends ping every 10 seconds and closes a
connection after more than 40 seconds without an appropriate response.

This supervisor deliberately does not place orders or change strategy decisions. Its job is
to establish whether the market-data plane is healthy enough for downstream state/signals.
