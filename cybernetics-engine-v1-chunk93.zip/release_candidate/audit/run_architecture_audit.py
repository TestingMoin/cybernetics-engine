from __future__ import annotations
import ast, json, re
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/'src'/'cybernetics'
files=list(SRC.rglob('*.py'))
def internal_imports():
    modules={p.relative_to(SRC).with_suffix('').as_posix().replace('/','.') for p in files}; bad=[]
    for p in files:
        for n in ast.walk(ast.parse(p.read_text())):
            vals=[]
            if isinstance(n,ast.Import): vals=[a.name for a in n.names]
            elif isinstance(n,ast.ImportFrom) and n.level==0 and n.module: vals=[n.module]
            for name in vals:
                if name.startswith('cybernetics.'):
                    rel=name[len('cybernetics.'):]
                    if rel not in modules and not any(m.startswith(rel+'.') for m in modules): bad.append((str(p.relative_to(ROOT)),name))
    return sorted(set(bad))
def hits(rx, subset=None):
    r=re.compile(rx,re.I); out=[]
    for p in (subset or files):
        for i,l in enumerate(p.read_text(errors='ignore').splitlines(),1):
            if r.search(l): out.append({'file':str(p.relative_to(ROOT)),'line':i,'text':l.strip()})
    return out
def dup_classes():
    d=defaultdict(list)
    for p in files:
        for n in ast.parse(p.read_text()).body:
            if isinstance(n,ast.ClassDef): d[n.name].append(str(p.relative_to(ROOT)))
    return {k:v for k,v in sorted(d.items()) if len(v)>1}
strategy_risk=[p for p in files if any(x in str(p) for x in ('/strategy/','/strategies/','/risk/'))]
result={
'source_python_files':len(files),
'internal_imports_unresolved':internal_imports(),
'credential_literal_hits':hits(r"(?:api[_-]?secret|access[_-]?token|totp|password|pin|secret)\s*[:=]\s*['\"][^'\"]+['\"]"),
'bind_all_hits':hits(r'0\.0\.0\.0'),
'debug_print_hits':hits(r'(?:print\s*\(|breakpoint\s*\()'),
'main_entrypoint_hits':hits(r"__name__\s*==\s*['\"]__main__['\"]"),
'strategy_risk_network_order_hits':hits(r'(?:requests\.|httpx\.|urllib|aiohttp|/orders\b|place_order\s*\(|cancel_order\s*\()',strategy_risk),
'duplicate_classes':dup_classes(),
'metadata':{'project_name':'cybernetics-engine-v1-chunk8','project_version':'0.8.0','readme_claim':'Chunk 83','requires_python':'>=3.11','requirements':'pytest>=9'}
}
print(json.dumps(result,indent=2,sort_keys=True))
