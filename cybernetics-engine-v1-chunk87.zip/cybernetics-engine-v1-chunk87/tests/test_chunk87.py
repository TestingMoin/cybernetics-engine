from datetime import datetime, timezone
from cybernetics.strategy.models import StrategyContext, StrategyDecision, DecisionType
from cybernetics.strategy.engine import StrategyEngine, deterministic_direction_strategy
from cybernetics.strategy.golden_models import GoldenContext, GoldenDecision
from cybernetics.strategy.golden import NiftySensexGolden, BankNiftyGolden

NOW=datetime(2026,6,15,10,0,tzinfo=timezone.utc)

def ctx(direction="BUY",strength=.8):
    return StrategyContext("SIG1","ICE-NIFTY","NIFTY","5m",NOW,direction,strength,{})
def test_strategy_context_contract():
    c=ctx()
    assert c.signal_id=="SIG1" and c.direction=="BUY"
def test_decision_identity_and_confidence():
    d=StrategyDecision("D1","S1","SIG1",DecisionType.ENTER_LONG,NOW,"ok",.9,{})
    assert d.decision==DecisionType.ENTER_LONG
def test_decision_rejects_invalid_confidence():
    try:
        StrategyDecision("D1","S1","SIG1",DecisionType.HOLD,NOW,"bad",1.1,{})
        assert False
    except ValueError as e:
        assert str(e)=="strategy_confidence_out_of_range"
def test_engine_consumes_canonical_models():
    e=StrategyEngine()
    e.register(deterministic_direction_strategy("S1"))
    d=e.evaluate("S1",ctx())
    assert d.strategy_id=="S1" and d.signal_id=="SIG1"
def test_engine_maps_sell():
    e=StrategyEngine(); e.register(deterministic_direction_strategy("S1"))
    d=e.evaluate("S1",ctx("SELL",.7))
    assert d.decision is DecisionType.ENTER_SHORT
def test_engine_unknown_direction_no_action():
    e=StrategyEngine(); e.register(deterministic_direction_strategy("S1"))
    d=e.evaluate("S1",ctx(None,.7))
    assert d.decision is DecisionType.NO_ACTION
def test_golden_context_preserved_separately():
    g=GoldenContext("GOLDEN-NIFTY-SENSEX","SIG2",NOW,6,100.0,"BUY",
                    ema5=101,ema15=99,prev_ema5=98,prev_ema15=100,
                    daily_ema5=110,daily_ema15=100,allow_shorts=True)
    assert g.prev_ema5==98 and g.daily_ema15==100
def test_nifty_golden_evaluates():
    g=GoldenContext("GOLDEN-NIFTY-SENSEX","SIG2",NOW,6,100.0,"BUY",
                    ema5=101,ema15=99,prev_ema5=98,prev_ema15=100,
                    daily_ema5=110,daily_ema15=100,allow_shorts=True)
    d=NiftySensexGolden().evaluate(g)
    assert d.action=="ENTER_LONG"
def test_bank_golden_evaluates():
    g=GoldenContext("GOLDEN-BANKNIFTY","SIG3",NOW,6,100.0,"BUY",
                    ema40=105,ema120=100,ema200=95,
                    daily_ema40=105,daily_ema120=100,daily_ema200=95,daily_close=101,
                    md_line=3,md_signal=2,higher_tf_pass=True)
    d=BankNiftyGolden().evaluate(g)
    assert d.action=="ENTER_LONG"
def test_no_broker_execution_surface():
    from pathlib import Path
    for p in Path("src/cybernetics/strategy").glob("*.py"):
        text=p.read_text()
        assert "/v2/orders" not in text
        assert "place_order(" not in text
