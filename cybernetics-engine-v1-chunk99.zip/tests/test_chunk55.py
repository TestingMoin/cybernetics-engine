from datetime import date
import pytest

from cybernetics.execution.intent import ExecutionIntentBuilder
from cybernetics.execution.instrument import (
    TradeInstrument, InstrumentType, OptionType, InstrumentEligibility
)
from cybernetics.execution.binding import (
    ExecutionIntentInstrumentBinder, BoundExecutionInstruction
)

B = ExecutionIntentBuilder()
X = ExecutionIntentInstrumentBinder()
ELIGIBLE = InstrumentEligibility(True, True, True, True, "approved")


def intent(**kw):
    d = dict(
        approved=True,
        trade_id="T1",
        strategy_id="GOLDEN-NIFTY-SENSEX",
        strategy_version="1.0.0-reproduction-target",
        signal_id="SIG1",
        underlying_key="NIFTY",
        action="BUY",
        quantity=10,
        order_type="MARKET",
        product_type="INTRADAY",
        validity="DAY",
    )
    d.update(kw)
    return B.build(**d)


def instrument(**kw):
    d = dict(
        exchange_segment="NSE_FNO",
        security_id="12345",
        symbol="NIFTY",
        instrument_type=InstrumentType.FUTURE,
        expiry=date(2026, 9, 24),
        lot_size=10,
        tick_size=0.05,
        contract_multiplier=1.0,
        eligibility=ELIGIBLE,
    )
    d.update(kw)
    return TradeInstrument(**d)


def test_market_intent_binds_exact_instrument():
    r = X.bind(intent(), instrument())
    assert isinstance(r, BoundExecutionInstruction)
    assert r.security_id == "12345"
    assert r.exchange_segment == "NSE_FNO"
    assert r.quantity == 10


def test_limit_price_on_tick_grid_is_accepted():
    r = X.bind(intent(order_type="LIMIT", limit_price=101.50),
               instrument())
    assert r.limit_price == 101.50


def test_limit_price_off_tick_grid_is_rejected():
    with pytest.raises(ValueError, match="limit_price_not_on_tick_grid"):
        X.bind(intent(order_type="LIMIT", limit_price=101.53),
               instrument())


def test_quantity_must_be_lot_aligned():
    with pytest.raises(ValueError, match="bound_quantity_not_lot_aligned"):
        X.bind(intent(quantity=15), instrument())


def test_symbol_mismatch_is_rejected():
    with pytest.raises(ValueError, match="intent_instrument_symbol_mismatch"):
        X.bind(intent(underlying_key="BANKNIFTY"), instrument())


def test_security_id_is_taken_only_from_selected_instrument():
    r = X.bind(intent(), instrument(security_id="SEC-REAL"))
    assert r.security_id == "SEC-REAL"


def test_option_metadata_is_bound():
    r = X.bind(
        intent(underlying_key="NIFTY"),
        instrument(
            instrument_type=InstrumentType.OPTION,
            security_id="OPT1",
            expiry=date(2026, 9, 24),
            strike=25000,
            option_type=OptionType.CE,
            lot_size=10,
        ),
    )
    assert r.strike == 25000
    assert r.option_type == OptionType.CE
    assert r.expiry == date(2026, 9, 24)


def test_zero_tick_size_rejected_at_instrument_boundary():
    with pytest.raises(ValueError, match="tick_size_must_be_positive"):
        instrument(tick_size=0)


def test_market_order_has_no_limit_price():
    r = X.bind(intent(order_type="MARKET"), instrument())
    assert r.limit_price is None


def test_bound_instruction_keeps_strategy_version():
    r = X.bind(intent(strategy_version="2.5.0"), instrument())
    assert r.strategy_version == "2.5.0"


def test_bound_instruction_contains_no_credentials():
    r = X.bind(intent(), instrument())
    assert not hasattr(r, "access_token")
    assert not hasattr(r, "api_key")
    assert not hasattr(r, "api_secret")


def test_bound_instruction_is_not_broker_payload():
    r = X.bind(intent(), instrument())
    assert not hasattr(r, "api_payload")
    assert not hasattr(r, "place_order")


def test_option_requires_exact_contract_metadata():
    with pytest.raises(ValueError, match="option_expiry_required"):
        TradeInstrument(
            exchange_segment="NSE_FNO",
            security_id="OPT2",
            symbol="NIFTY",
            instrument_type=InstrumentType.OPTION,
            strike=25000,
            option_type=OptionType.CE,
            lot_size=10,
            tick_size=0.05,
            contract_multiplier=1.0,
            eligibility=ELIGIBLE,
        )
