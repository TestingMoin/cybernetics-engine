from __future__ import annotations

import uvicorn

from app.config.settings import Settings
from app.api.server import app


def main() -> None:
    settings = Settings.from_env()
    uvicorn.run(app, host=settings.api_host, port=settings.api_port, log_level="info")


if __name__ == "__main__":
    main()
