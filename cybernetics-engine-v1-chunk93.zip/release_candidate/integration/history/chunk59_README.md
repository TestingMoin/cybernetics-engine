# Cybernetics Trading Engine — Chunk 59

Dhan provides a Live Order Update WebSocket at `wss://api-order-update.dhan.co`.
It streams JSON order updates containing fields including order identifiers,
`LastUpdatedTime`, traded quantities, average traded price, `CorrelationId`
and status. citeturn842086search0

This chunk adds:
WebSocket event → normalization → duplicate/out-of-order/terminal-regression
checks → canonical lifecycle event.

Duplicate messages are ignored. Older events are marked stale. Missing ordering
timestamps after prior state, or terminal-state regression, produces
`SNAPSHOT_REQUIRED` so REST reconciliation can establish truth.

No DB mutation, Position Manager mutation, order submission, or automatic retry
is performed here.
