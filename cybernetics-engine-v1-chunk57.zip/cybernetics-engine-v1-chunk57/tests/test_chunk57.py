import pytest

from cybernetics.dhan.payload import DhanOrderPayload
from cybernetics.dhan.submission import (
    DhanExecutionPolicy, DhanOrderSubmissionAdapter, DhanSubmissionState
)

class FakeTransport:
    def __init__(self, response=None, exc=None):
        self.response=response or {"orderId":"OID1","orderStatus":"PENDING"}
        self.exc=exc
        self.calls=[]

    def post_json(self, *, path, headers, json_body):
        self.calls.append((path,headers,json_body))
        if self.exc: raise self.exc
        return self.response

class Token:
    def __init__(self,value="TOKEN"): self.value=value
    def __call__(self): return self.value

def payload():
    return DhanOrderPayload(
        dhanClientId="100001",
        correlationId="CORR57",
        transactionType="BUY",
        exchangeSegment="NSE_FNO",
        productType="INTRADAY",
        orderType="MARKET",
        validity="DAY",
        securityId="12345",
        quantity=10,
    )

def policy(**kw):
    d=dict(engine_running=True,live_authorized=True,
           emergency_stop=False,order_submission_enabled=True)
    d.update(kw)
    return DhanExecutionPolicy(**d)

def test_submission_calls_injected_transport():
    t=FakeTransport()
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy())
    r=a.submit(payload())
    assert r.state==DhanSubmissionState.SUBMITTED
    assert r.broker_order_id=="OID1"
    assert t.calls[0][0]=="/v2/orders"

def test_access_token_is_only_injected_as_header():
    t=FakeTransport()
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token("SECRET"),policy=policy())
    a.submit(payload())
    headers=t.calls[0][1]
    assert headers["access-token"]=="SECRET"

def test_emergency_stop_blocks_before_transport():
    t=FakeTransport()
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy(emergency_stop=True))
    r=a.submit(payload())
    assert r.state==DhanSubmissionState.BLOCKED
    assert not t.calls

def test_engine_off_blocks():
    t=FakeTransport()
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy(engine_running=False))
    assert a.submit(payload()).reason=="engine_not_running"
    assert not t.calls

def test_live_auth_missing_blocks():
    t=FakeTransport()
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy(live_authorized=False))
    assert a.submit(payload()).reason=="live_authorization_missing"
    assert not t.calls

def test_order_submission_disabled_blocks():
    t=FakeTransport()
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy(order_submission_enabled=False))
    assert a.submit(payload()).reason=="order_submission_disabled"
    assert not t.calls

def test_missing_token_rejected():
    t=FakeTransport()
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(""),policy=policy())
    r=a.submit(payload())
    assert r.state==DhanSubmissionState.REJECTED
    assert not t.calls

def test_timeout_is_unknown_and_not_retried():
    t=FakeTransport(exc=TimeoutError())
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy())
    r=a.submit(payload())
    assert r.state==DhanSubmissionState.UNKNOWN
    assert "no_retry" in r.reason
    assert len(t.calls)==1

def test_connection_error_is_unknown():
    t=FakeTransport(exc=ConnectionError())
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy())
    r=a.submit(payload())
    assert r.state==DhanSubmissionState.UNKNOWN

def test_broker_rejection_is_rejected_with_order_id():
    t=FakeTransport(response={"orderId":"OID9","orderStatus":"REJECTED"})
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy())
    r=a.submit(payload())
    assert r.state==DhanSubmissionState.REJECTED
    assert r.broker_order_id=="OID9"

def test_missing_order_id_is_unknown():
    t=FakeTransport(response={"orderStatus":"PENDING"})
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy())
    r=a.submit(payload())
    assert r.state==DhanSubmissionState.UNKNOWN

def test_payload_not_mutated():
    p=payload(); before=p.as_dict()
    t=FakeTransport()
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy())
    a.submit(p)
    assert p.as_dict()==before

def test_no_internal_retry_loop():
    t=FakeTransport(exc=TimeoutError())
    a=DhanOrderSubmissionAdapter(transport=t,access_token_provider=Token(),policy=policy())
    a.submit(payload())
    assert len(t.calls)==1
