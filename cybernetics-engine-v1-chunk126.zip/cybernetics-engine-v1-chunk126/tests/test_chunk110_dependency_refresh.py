from cybernetics.config.settings import DeploymentConfig
from cybernetics.runtime.production import (
    RuntimeDependencyState,
    build_production_runtime,
)
from cybernetics.runtime.state import ControlState, EmergencyState


class MutableProbe:
    def __init__(self, value=True):
        self.value = value


def test_runtime_refresh_updates_changed_dependency_state(tmp_path):
    cfg = DeploymentConfig()
    cfg.validate_filesystem()
    probe = MutableProbe(True)
    state = RuntimeDependencyState(
        engine_running=True,
        control_state=ControlState.RUNNING,
        emergency_state=EmergencyState.CLEAR,
        recovery_clear=True,
        orders_reconciled=True,
        positions_reconciled=True,
    )
    app = build_production_runtime(
        cfg,
        dependency_state=state,
        market_feed_runtime=type('Feed', (), {
            'market_data_ready': lambda self: probe.value
        })(),
    )
    app.start()
    assert app.last_snapshot.inputs.market_data_ready is True

    probe.value = False
    refreshed = app.run_cycle()
    assert refreshed.inputs.market_data_ready is False
    assert refreshed.readiness.engine_ready is False
    app.stop()


def test_runtime_refresh_invokes_injected_probe_each_cycle(tmp_path):
    cfg = DeploymentConfig()
    calls = {'n': 0}

    class Feed:
        def market_data_ready(self):
            calls['n'] += 1
            return True

    state = RuntimeDependencyState(engine_running=True)
    app = build_production_runtime(
        cfg, dependency_state=state, market_feed_runtime=Feed()
    )
    app.start()
    before = calls['n']
    app.run_cycle()
    assert calls['n'] >= before + 1
    app.stop()
