from __future__ import annotations

import importlib.util
from pathlib import Path
from types import ModuleType
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
LEGACY_PATH = BASE_DIR / "master_engine_legacy.py"


def _load_legacy() -> ModuleType:
    spec = importlib.util.spec_from_file_location("cybernetics_options_legacy", LEGACY_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load options engine: {LEGACY_PATH}")
    module = importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


_legacy = _load_legacy()

# Preserve the existing analytics models/functions without duplicating or rewriting
# their mathematical implementation in this integration layer.
OptionType = _legacy.OptionType
Buildup = _legacy.Buildup
ContractSpec = _legacy.ContractSpec
OptionQuote = _legacy.OptionQuote
Chain = _legacy.Chain
Finding = _legacy.Finding
Position = _legacy.Position
ChainReport = _legacy.ChainReport
OptionsMasterEngine = _legacy.OptionsMasterEngine
DataQualityReport = _legacy.DataQualityReport
LessonRecord = _legacy.LessonRecord


class OptionsEngineAdapter:
    """Dhan-independent adapter around the existing Options Master Engine.

    This class is analytics-only. It does not know how to place/cancel broker
    orders and therefore cannot bypass the engine's future risk/execution gates.
    """

    def __init__(self, engine: Any | None = None) -> None:
        self.engine = engine or OptionsMasterEngine()

    def analyze(self, chain: Any, underlying_price: float, expiry: Any | None = None) -> Any:
        return self.engine.analyze(chain, underlying_price, expiry)

    def audit(self, chain: Any) -> Any:
        return _legacy.audit_chain(chain)

    @staticmethod
    def build_chain(rows: list[dict[str, Any]], source: str = "") -> Any:
        return OptionsMasterEngine.from_rows(rows, source=source)
