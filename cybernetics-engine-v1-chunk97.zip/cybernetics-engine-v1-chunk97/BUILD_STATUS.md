# Cybernetics Trading Engine — Chunk 97

## Scope
Deployment configuration boundary and explicit fail-closed environment contract.

## Changes
- Added `cybernetics.config.DeploymentConfig` with strict environment parsing.
- Added explicit PAPER/LIVE trading mode enum.
- Added production-only LIVE mode requirement.
- Added independent live approval ID requirement.
- Added order-submission safety invariant requiring explicit LIVE mode plus approval.
- Added filesystem path validation for data and secret directories.
- Updated canonical CLI entrypoint to load and validate deployment configuration before runtime startup.
- Added `.env.example` containing safe paper defaults and no credentials.

## Validation
- compileall: PASS
- pytest: **815 passed**
- source CLI self-check: PASS
- source CLI once: PASS
- wheel build: PASS
- clean virtualenv wheel install: PASS
- installed CLI self-check: PASS
- packaged schema/config check: PASS
- default mode: PAPER
- new trades allowed: false
- live authorization: invalid
- no Dhan submission or PostgreSQL production connection performed

## Release Status
RELEASE-CANDIDATE — configuration boundary validated locally. VPS deployment remains disabled.
