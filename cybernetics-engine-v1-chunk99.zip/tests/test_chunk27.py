from cybernetics.order_management.idempotency import IdempotencyRecord
from cybernetics.persistence.memory_ledger import InMemoryOrderLedger
from cybernetics.order_management.unknown_resolver import UnknownOrderResolver, ResolutionState
from cybernetics.order_management.retry_guard import SafeRetryGuard, RetryDecision

class FakeBroker:
    def __init__(self, orders):
        self.orders = orders
    def get_orders(self):
        return list(self.orders)

def unknown_store(key="K1"):
    store=InMemoryOrderLedger()
    assert store.put_once(IdempotencyRecord(key,None,"UNKNOWN"))
    return store

def test_exact_match_resolves_accepted():
    s=unknown_store()
    b=FakeBroker([{"client_order_key":"K1","broker_order_id":"B1","status":"FILLED"}])
    r=UnknownOrderResolver(b,s).resolve("K1")
    assert r.state==ResolutionState.RESOLVED_ACCEPTED
    assert s.get("K1").broker_order_id=="B1"

def test_rejected_allows_safe_new_submission():
    s=unknown_store()
    b=FakeBroker([{"client_order_key":"K1","broker_order_id":"B1","status":"REJECTED"}])
    r=UnknownOrderResolver(b,s)
    assert r.resolve("K1").state==ResolutionState.RESOLVED_REJECTED
    assert SafeRetryGuard(r).decide("K1")==RetryDecision.ALLOW_NEW_SUBMISSION

def test_still_unknown_blocks_retry():
    s=unknown_store()
    b=FakeBroker([])
    r=UnknownOrderResolver(b,s)
    assert r.resolve("K1").state==ResolutionState.STILL_UNKNOWN
    assert SafeRetryGuard(r).decide("K1")==RetryDecision.BLOCK

def test_ambiguous_exact_matches_block():
    s=unknown_store()
    b=FakeBroker([
        {"client_order_key":"K1","broker_order_id":"B1","status":"OPEN"},
        {"client_order_key":"K1","broker_order_id":"B2","status":"OPEN"},
    ])
    r=UnknownOrderResolver(b,s)
    assert r.resolve("K1").state==ResolutionState.AMBIGUOUS
    assert SafeRetryGuard(r).decide("K1")==RetryDecision.BLOCK

def test_fuzzy_match_is_not_used():
    s=unknown_store("K2")
    b=FakeBroker([{"client_order_key":"OTHER","broker_order_id":"B9","status":"REJECTED",
                   "symbol":"NIFTY","side":"BUY","quantity":50}])
    r=UnknownOrderResolver(b,s)
    assert r.resolve("K2").state==ResolutionState.STILL_UNKNOWN

def test_open_broker_order_is_bound_but_retry_remains_blocked():
    s=unknown_store()
    b=FakeBroker([{"client_order_key":"K1","broker_order_id":"B1","status":"OPEN"}])
    r=UnknownOrderResolver(b,s)
    assert r.resolve("K1").state==ResolutionState.RESOLVED_ACCEPTED
    assert SafeRetryGuard(r).decide("K1")==RetryDecision.BLOCK
