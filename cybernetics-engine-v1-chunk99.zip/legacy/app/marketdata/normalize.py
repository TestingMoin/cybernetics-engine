from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum

from app.marketdata.events import MarketEvent


class DataQuality(StrEnum):
    OK = "ok"
    WARN = "warn"
    REJECT = "reject"


@dataclass(frozen=True, slots=True)
class NormalizedTick:
    exchange_segment: int
    security_id: str
    observed_at: datetime
    trade_at: datetime | None
    price: float | None
    quantity: int | None
    cumulative_volume: int | None
    open_interest: int | None
    best_bid: float | None
    best_ask: float | None
    total_bid_quantity: int | None
    total_ask_quantity: int | None
    day_open: float | None
    day_high: float | None
    day_low: float | None
    prev_close: float | None
    source_packet: str
    quality: DataQuality
    quality_reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class InstrumentState:
    prev_close: float | None = None
    open_interest: int | None = None
    volume: int | None = None
    price: float | None = None
    best_bid: float | None = None
    best_ask: float | None = None
    total_buy_quantity: int | None = None
    total_sell_quantity: int | None = None
    day_open: float | None = None
    day_high: float | None = None
    day_low: float | None = None


class MarketNormalizer:
    """Merges asynchronous Dhan packets into a canonical per-security state."""

    def __init__(self, future_tolerance_seconds: int = 10, max_reason_count: int = 8) -> None:
        self.future_tolerance_seconds = future_tolerance_seconds
        self.max_reason_count = max_reason_count
        self._state: dict[tuple[int, str], InstrumentState] = {}

    def _merge(self, event: MarketEvent) -> InstrumentState:
        key = (event.exchange_segment, event.security_id)
        old = self._state.get(key, InstrumentState())
        new = InstrumentState(
            prev_close=event.prev_close if event.prev_close is not None else old.prev_close,
            open_interest=event.open_interest if event.open_interest is not None else old.open_interest,
            volume=event.volume if event.volume is not None else old.volume,
            price=event.last_price if event.last_price is not None else old.price,
            best_bid=(next((d.price for d in event.depth if d.side == "bid" and d.price > 0), None) if event.depth else None) or old.best_bid,
            best_ask=(next((d.price for d in event.depth if d.side == "ask" and d.price > 0), None) if event.depth else None) or old.best_ask,
            total_buy_quantity=event.total_buy_quantity if event.total_buy_quantity is not None else old.total_buy_quantity,
            total_sell_quantity=event.total_sell_quantity if event.total_sell_quantity is not None else old.total_sell_quantity,
            day_open=event.day_open if event.day_open is not None else old.day_open,
            day_high=event.day_high if event.day_high is not None else old.day_high,
            day_low=event.day_low if event.day_low is not None else old.day_low,
        )
        self._state[key] = new
        return new

    def normalize(self, event: MarketEvent) -> NormalizedTick:
        state = self._merge(event)
        reasons: list[str] = []
        price = state.price
        if price is not None and price <= 0:
            reasons.append("non_positive_price")
        trade_at = event.trade_time
        if trade_at is not None:
            now = datetime.now(timezone.utc)
            if trade_at > now:
                delta = (trade_at - now).total_seconds()
                if delta > self.future_tolerance_seconds:
                    reasons.append("trade_timestamp_in_future")
        if state.best_bid is not None and state.best_ask is not None and state.best_bid > state.best_ask:
            reasons.append("crossed_best_bid_ask")
        if state.day_low is not None and state.day_high is not None and state.day_low > state.day_high:
            reasons.append("invalid_day_range")
        if event.packet_kind == "disconnect":
            reasons.append("feed_disconnect")
        if price is None and event.packet_kind in {"ticker", "quote", "full", "index"}:
            reasons.append("missing_price")

        quality = DataQuality.REJECT if any(r in reasons for r in ("non_positive_price", "crossed_best_bid_ask", "invalid_day_range", "trade_timestamp_in_future")) else DataQuality.OK
        if quality is DataQuality.OK and reasons:
            quality = DataQuality.WARN
        return NormalizedTick(
            exchange_segment=event.exchange_segment,
            security_id=event.security_id,
            observed_at=event.received_at,
            trade_at=trade_at,
            price=price,
            quantity=event.last_quantity,
            cumulative_volume=state.volume,
            open_interest=state.open_interest,
            best_bid=state.best_bid,
            best_ask=state.best_ask,
            total_bid_quantity=state.total_buy_quantity,
            total_ask_quantity=state.total_sell_quantity,
            day_open=state.day_open,
            day_high=state.day_high,
            day_low=state.day_low,
            prev_close=state.prev_close,
            source_packet=event.packet_kind,
            quality=quality,
            quality_reasons=tuple(reasons[:self.max_reason_count]),
        )

    def snapshot(self, exchange_segment: int, security_id: str) -> InstrumentState | None:
        return self._state.get((exchange_segment, security_id))
