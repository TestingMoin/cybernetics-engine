from datetime import datetime, timedelta, timezone
from cybernetics.signals.lifecycle import (
    SignalLifecycleManager,
    SignalLifecycleState,
    InvalidationReason,
)

NOW=datetime(2026,1,1,tzinfo=timezone.utc)

def manager():
    return SignalLifecycleManager(now=lambda: NOW)

def test_observed_to_active():
    m=manager()
    e=m.register("S1",created_at=NOW,ttl=timedelta(seconds=60))
    assert e.state is SignalLifecycleState.OBSERVED and e.valid
    e=m.activate("S1")
    assert e.state is SignalLifecycleState.ACTIVE and e.valid

def test_terminal_invalidation_blocks_reactivation():
    m=manager(); m.register("S2",created_at=NOW,ttl=timedelta(seconds=60))
    m.activate("S2")
    e=m.invalidate("S2",InvalidationReason.EXPLICIT)
    assert e.state is SignalLifecycleState.INVALIDATED and not e.valid
    assert m.activate("S2").state is SignalLifecycleState.INVALIDATED

def test_expiry():
    t={"now":NOW}
    m=SignalLifecycleManager(now=lambda: t["now"])
    m.register("S3",created_at=NOW,ttl=timedelta(seconds=5))
    m.activate("S3")
    t["now"]=NOW+timedelta(seconds=6)
    e=m.evaluate("S3")
    assert e.state is SignalLifecycleState.EXPIRED and not e.valid

def test_not_expired_before_ttl():
    t={"now":NOW}
    m=SignalLifecycleManager(now=lambda: t["now"])
    m.register("S4",created_at=NOW,ttl=timedelta(seconds=5))
    m.activate("S4")
    t["now"]=NOW+timedelta(seconds=4)
    e=m.evaluate("S4")
    assert e.state is SignalLifecycleState.ACTIVE and e.valid

def test_supersession_records_replacement():
    m=manager()
    m.register("S5",created_at=NOW,ttl=timedelta(seconds=60))
    m.register("S6",created_at=NOW,ttl=timedelta(seconds=60))
    e=m.supersede("S5","S6")
    assert e.state is SignalLifecycleState.SUPERSEDED
    assert m.metadata("S5")["superseded_by"]=="S6"

def test_terminal_state_is_validity_blocker():
    m=manager(); m.register("S7",created_at=NOW,ttl=timedelta(seconds=60))
    m.invalidate("S7",InvalidationReason.DATA_STALE)
    assert m.evaluate("S7").valid is False

def test_active_signal_is_valid():
    m=manager(); m.register("S8",created_at=NOW,ttl=timedelta(seconds=60))
    m.activate("S8")
    assert m.evaluate("S8").valid is True

def test_invalidation_reason_is_preserved():
    m=manager(); m.register("S9",created_at=NOW,ttl=timedelta(seconds=60))
    m.invalidate("S9",InvalidationReason.MARKET_STATE_INVALID)
    assert m.metadata("S9")["invalidation_reason"] is InvalidationReason.MARKET_STATE_INVALID
