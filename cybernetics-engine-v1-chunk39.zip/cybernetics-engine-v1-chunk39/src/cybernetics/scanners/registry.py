from .models import ScannerRuntime,ScannerRuntimeKey,ScannerState
class ScannerRuntimeRegistry:
 def __init__(self,on_event=None): self._items={};self._on_event=on_event
 def create(self,key,config_version=1):
  if key in self._items: raise ValueError("scanner_runtime_already_exists")
  r=ScannerRuntime(key);self._items[key]=r;return r
 def get(self,key):
  if key not in self._items: raise KeyError("scanner_runtime_not_found")
  return self._items[key]
 def start(self,key): self.get(key).state=ScannerState.RUNNING
 def degrade(self,key,reason): self.get(key).state=ScannerState.DEGRADED;self.get(key).state_data["degraded_reason"]=reason
