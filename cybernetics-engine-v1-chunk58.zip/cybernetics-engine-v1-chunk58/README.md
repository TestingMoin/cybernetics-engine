# Cybernetics Trading Engine — Chunk 58

## Broker Response Normalization & Order Lifecycle Binding

This chunk normalizes Dhan order responses and maps them into the engine's
internal order lifecycle.

Dhan V2 order/status APIs expose statuses such as TRANSIT, PENDING,
PART_TRADED, TRADED, REJECTED, CANCELLED and EXPIRED. Dhan's Super Order
workflow also uses CLOSED and TRIGGERED. GET order responses provide
`filledQty`, `remainingQuantity` and `averageTradedPrice`, which are preserved
by this model. citeturn752019search0turn752019search3turn752019search6

Mapping:

Dhan PENDING/TRANSIT -> internal PENDING
Dhan PART_TRADED     -> internal PARTIAL
Dhan TRADED/CLOSED   -> internal FILLED
Dhan REJECTED        -> internal REJECTED
Dhan CANCELLED       -> internal CANCELLED
Dhan EXPIRED         -> internal EXPIRED
Unknown              -> internal UNKNOWN

This chunk deliberately does not:
- write the database
- mutate Position Manager state
- assume a fill solely from an HTTP response
- submit or cancel orders

The existing Order Manager, persistent ledger, reconciliation engine and
Position Manager remain the authoritative downstream integration points.
