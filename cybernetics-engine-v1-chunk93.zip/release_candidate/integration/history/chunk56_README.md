# Cybernetics Trading Engine — Chunk 56

## Dhan V2 Broker Payload Mapper

This is the adapter boundary that maps the broker-neutral
`BoundExecutionInstruction` into a Dhan V2-compatible order request payload.

The mapper validates:
- Dhan exchange segment
- product type
- validity
- BUY/SELL transaction type
- positive quantity
- disclosed quantity
- MARKET/LIMIT order semantics
- LIMIT price
- correlation ID length and allowed characters
- Dhan client ID presence

Credentials and access tokens are deliberately absent. Authentication is handled
by the existing Dhan authentication/transport layers.

This chunk creates a payload only. It does NOT perform POST `/v2/orders`,
does not retry, and does not send anything to Dhan.

Dhan-specific order fields in this mapper are based on the official Dhan V2 Orders
documentation. citeturn983063search0
