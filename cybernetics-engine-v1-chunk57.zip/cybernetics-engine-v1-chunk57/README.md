# Cybernetics Trading Engine — Chunk 57

## Dhan Order Submission Adapter

This chunk establishes the final broker submission boundary.

Flow:

`Comprehensive Pre-Trade Gate`
→ `Execution Intent`
→ `Instrument Binding`
→ `Dhan Payload`
→ `DhanOrderSubmissionAdapter`
→ existing Dhan REST transport
→ Dhan

The current Dhan V2 order-placement endpoint is `/v2/orders` and uses the
`access-token` header. Order placement is subject to the broker's static-IP
whitelisting requirement. citeturn213076search0

Safety:
- live submission disabled by default
- emergency stop blocks before transport
- engine must be running
- live authorization required
- an additional explicit order-submission enable flag is required
- access tokens are injected, never stored in this adapter
- POST timeouts/connection uncertainty return `UNKNOWN`
- no blind retry of non-idempotent order placement
- broker order ID is required to classify a submission as accepted

This chunk does not perform any real network call during build/tests. Production
deployment must connect the adapter to the existing Dhan REST transport/rate-limit
layer rather than creating a second HTTP stack.
