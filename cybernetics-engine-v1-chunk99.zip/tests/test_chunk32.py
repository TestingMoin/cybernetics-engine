import asyncio
from cybernetics.websocket.subscriptions import SubscriptionManager, SubscriptionMode, Instrument
from cybernetics.websocket.manager import DhanMarketFeedManager, FeedState, ReconnectPolicy

def instruments(n):
    return [Instrument("NSE_FNO",str(i)) for i in range(n)]

def test_subscription_chunks_at_100():
    s=SubscriptionManager()
    s.set_desired(SubscriptionMode.FULL,instruments(205))
    msgs=s.messages(SubscriptionMode.FULL)
    assert [m["InstrumentCount"] for m in msgs]==[100,100,5]
    assert all(m["RequestCode"]==21 for m in msgs)

def test_unsubscribe_uses_matching_code():
    s=SubscriptionManager()
    s.set_desired(SubscriptionMode.QUOTE,instruments(2))
    assert s.messages(SubscriptionMode.QUOTE,subscribe=False)[0]["RequestCode"]==18

def test_connection_limit_is_5000():
    s=SubscriptionManager()
    s.set_desired(SubscriptionMode.TICKER,instruments(5000))
    try:
        s.add(SubscriptionMode.TICKER,[Instrument("NSE_FNO","5001")])
        assert False
    except ValueError as e:
        assert str(e)=="connection_instrument_limit_exceeded"

def test_manager_url_uses_current_token():
    m=DhanMarketFeedManager(lambda:{"access-token":"ABC"},"123",lambda url:None)
    assert "token=ABC" in m.url()
    assert "clientId=123" in m.url()

def test_connect_resubscribes_all_modes():
    sent=[]
    class Sock:
        async def send_json(self,x): sent.append(x)
        async def recv(self): raise ConnectionError("done")
    async def factory(url): return Sock()
    s=SubscriptionManager()
    s.set_desired(SubscriptionMode.TICKER,instruments(1))
    s.set_desired(SubscriptionMode.QUOTE,instruments(1))
    s.set_desired(SubscriptionMode.FULL,instruments(1))
    m=DhanMarketFeedManager(lambda:{"access-token":"T"},"CID",factory,s)
    asyncio.run(m.connect_once())
    assert [x["RequestCode"] for x in sent]==[15,17,21]
    assert m.state==FeedState.RUNNING

def test_reconnect_backoff_is_exponential_and_capped():
    sleeps=[]
    class Bad:
        async def __call__(self,url):
            raise ConnectionError("bad")
    async def slp(x):
        sleeps.append(x)
        # Stop after two attempts by cancellation through factory condition elsewhere.
    calls=[0]
    async def factory(url):
        calls[0]+=1
        raise ConnectionError("bad")
    m=DhanMarketFeedManager(lambda:{"access-token":"T"},"CID",factory,
        reconnect=ReconnectPolicy(base_delay=1,max_delay=3,max_attempts=3),sleep=slp)
    asyncio.run(m.run())
    assert sleeps==[1,2,3]
    assert m.state==FeedState.FAILED

def test_message_callback_receives_binary_payload():
    received=[]
    class Sock:
        def __init__(self): self.count=0
        async def send_json(self,x): pass
        async def recv(self):
            self.count+=1
            if self.count==1: return b"binary"
            raise ConnectionError("stop")
    async def factory(url): return Sock()
    async def cb(msg): received.append(msg)
    s=SubscriptionManager()
    m=DhanMarketFeedManager(lambda:{"access-token":"T"},"CID",factory,s,on_message=cb)
    async def run_consume():
        await m.connect_once()
        try:
            await m._consume()
        except ConnectionError:
            pass
    asyncio.run(run_consume())
    assert received==[b"binary"]

def test_invalid_client_id_rejected():
    try:
        DhanMarketFeedManager(lambda:{"access-token":"T"},"",lambda u:None)
        assert False
    except ValueError as e:
        assert str(e)=="client_id_required"
