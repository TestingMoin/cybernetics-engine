# Build Status — Chunk 67

compileall: PASS
pytest: PASS (13/13)
schema_version migration: INCLUDED
fill_ledger migration: INCLUDED
fill_outbox migration: INCLUDED
startup schema validation: INCLUDED
production DB mutation during build: NOT PERFORMED
broker calls: NOT PRESENT
