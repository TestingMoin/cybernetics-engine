from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class BrokerOrderRequest:
    symbol: str
    side: str
    quantity: int
    order_type: str
    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    product_type: str = "INTRADAY"
    exchange_segment: str = "NSE_FNO"

@dataclass(frozen=True)
class BrokerOrderResult:
    broker: str
    accepted: bool
    broker_order_id: Optional[str]
    status: str
    message: str = ""
