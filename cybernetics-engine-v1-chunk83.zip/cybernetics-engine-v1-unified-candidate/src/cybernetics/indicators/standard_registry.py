from .registry import IndicatorRegistry,IndicatorSpec,IndicatorTier
from .library import *
def build_standard_registry():
 r=IndicatorRegistry()
 specs=[
 ("EMA",ema),("SMA",sma),("WMA",wma),("RSI",rsi),("ATR",atr),("BB",bollinger_bands),("ROC",roc),
 ("HIGHEST",highest),("LOWEST",lowest),("STOCH_K",stochastic_k),("STOCH_D",stochastic_d),
 ("MACD",macd),("ADX",adx),("OBV",obv),("VWAP",vwap)]
 for i,(name,fn) in enumerate(specs):
  r.register(IndicatorSpec(name,"1.0.0","STANDARD",IndicatorTier.CORE if i<9 else IndicatorTier.ADVANCED,fn))
 return r
