from cybernetics.recovery.reconciler import (
    RecoveryCase, RecoveryState, StateSnapshot,
    FillRecoveryCoordinator, ReconciliationResult,
    ReconcileDisposition,
)
from cybernetics.recovery.policy import RecoveryPolicy, RecoveryAction


class Store:
    def __init__(self):
        self.calls=[]
    def save_required(self, case): self.calls.append(("save",case.recovery_id))
    def mark_in_progress(self, rid): self.calls.append(("progress",rid))
    def mark_resolved(self, rid): self.calls.append(("resolved",rid))
    def mark_blocked(self, rid, reason): self.calls.append(("blocked",rid,reason))
    def list_open(self): return []


class Broker:
    def __init__(self, order=("O1",), positions=None):
        self.order=order
        self.positions=positions or {}
    def get_order(self, order_id):
        return {} if self.order else None
    def get_positions(self):
        return self.positions


def pos(qty=25, side="BUY", price=100.0):
    return StateSnapshot(qty, side, price)


def case():
    return RecoveryCase("R1","F1","O1","T1","fill processing failed")


def test_recovery_states_exist():
    assert RecoveryState.REQUIRED.value == "RECOVERY_REQUIRED"
    assert RecoveryState.BLOCKED.value == "RECOVERY_BLOCKED"


def test_register_persists_case():
    s=Store()
    FillRecoveryCoordinator(s,Broker()).register(case())
    assert s.calls == [("save","R1")]


def test_compare_consistent_positions():
    r=FillRecoveryCoordinator.compare_positions(pos(),pos())
    assert r.disposition is ReconcileDisposition.CONSISTENT
    assert r.safe_to_resume_new_trades


def test_compare_both_absent_is_consistent():
    r=FillRecoveryCoordinator.compare_positions(None,None)
    assert r.disposition is ReconcileDisposition.CONSISTENT


def test_broker_only_blocks():
    r=FillRecoveryCoordinator.compare_positions(None,pos())
    assert r.disposition is ReconcileDisposition.BROKER_AHEAD
    assert not r.safe_to_resume_new_trades


def test_internal_only_blocks():
    r=FillRecoveryCoordinator.compare_positions(pos(),None)
    assert r.disposition is ReconcileDisposition.INTERNAL_AHEAD
    assert not r.safe_to_resume_new_trades


def test_side_mismatch_blocks():
    r=FillRecoveryCoordinator.compare_positions(pos(side="BUY"),pos(side="SELL"))
    assert r.disposition is ReconcileDisposition.CONFLICT
    assert not r.safe_to_resume_new_trades


def test_quantity_mismatch_blocks():
    r=FillRecoveryCoordinator.compare_positions(pos(25),pos(50))
    assert r.disposition is ReconcileDisposition.CONFLICT


def test_price_mismatch_blocks():
    r=FillRecoveryCoordinator.compare_positions(pos(price=100),pos(price=102))
    assert r.disposition is ReconcileDisposition.CONFLICT


def test_recovery_resolves_consistent_case():
    s=Store()
    c=FillRecoveryCoordinator(s,Broker(positions={"NIFTY":pos()}))
    r=c.recover_case(
        case(),
        internal_order={"status":"TRADED"},
        internal_position=pos(),
        security_id="NIFTY",
    )
    assert r.disposition is ReconcileDisposition.CONSISTENT
    assert ("resolved","R1") in s.calls


def test_missing_broker_order_blocks():
    s=Store()
    c=FillRecoveryCoordinator(s,Broker(order=()))
    r=c.recover_case(
        case(), internal_order={"status":"TRADED"},
        internal_position=pos(), security_id="NIFTY"
    )
    assert r.disposition is ReconcileDisposition.MISSING_BROKER
    assert any(x[0]=="blocked" for x in s.calls)


def test_position_conflict_blocks_case():
    s=Store()
    c=FillRecoveryCoordinator(s,Broker(positions={"NIFTY":pos(50)}))
    r=c.recover_case(
        case(), internal_order={"status":"TRADED"},
        internal_position=pos(25), security_id="NIFTY"
    )
    assert r.disposition is ReconcileDisposition.CONFLICT
    assert any(x[0]=="blocked" for x in s.calls)


def test_recovery_policy_resolves_only_with_consistent_evidence():
    d=RecoveryPolicy().decide(consistent=True, broker_order_found=True)
    assert d.action is RecoveryAction.RESOLVE


def test_recovery_policy_human_review_for_missing_broker_order():
    d=RecoveryPolicy().decide(consistent=False, broker_order_found=False)
    assert d.action is RecoveryAction.REQUIRE_HUMAN_REVIEW


def test_recovery_policy_blocks_new_trades_for_mismatch():
    d=RecoveryPolicy().decide(consistent=False, broker_order_found=True)
    assert d.action is RecoveryAction.BLOCK_NEW_TRADES


def test_coordinator_contains_no_order_submission_endpoint():
    from pathlib import Path
    src=Path("src/cybernetics/recovery/reconciler.py").read_text()
    assert "/v2/orders" not in src
    assert "place_order" not in src
    assert "submit_order" not in src
