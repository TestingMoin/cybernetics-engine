from pathlib import Path
import json
import re

ROOT=Path(".")
AUDIT=ROOT/"audit"

def test_inventory_exists():
    assert (AUDIT/"chunk_inventory.csv").exists()

def test_findings_exists():
    assert (AUDIT/"integration_findings.json").exists()

def test_merge_rules_exists():
    assert (ROOT/"integration"/"CANONICAL_MERGE_RULES.md").exists()

def test_inventory_contains_80_chunks():
    import csv
    rows=list(csv.DictReader((AUDIT/"chunk_inventory.csv").open(encoding="utf-8")))
    assert len(rows)==80
    assert rows[0]["chunk"]=="2"
    assert rows[-1]["chunk"]=="81"

def test_inventory_has_sha256():
    import csv
    rows=list(csv.DictReader((AUDIT/"chunk_inventory.csv").open(encoding="utf-8")))
    assert all(re.fullmatch(r"[0-9a-f]{64}",r["sha256"]) for r in rows)

def test_findings_reports_conflicts_without_resolving_them():
    data=json.loads((AUDIT/"integration_findings.json").read_text(encoding="utf-8"))
    assert data["chunks_found"]==80
    assert len(data["duplicate_paths_conflicting"])==5
    assert "cybernetics-engine-v1/app/broker/dhan.py" in data["duplicate_paths_conflicting"]

def test_audit_does_not_claim_production_merge():
    rules=(ROOT/"integration"/"CANONICAL_MERGE_RULES.md").read_text(encoding="utf-8")
    assert "No archive is treated as a production deployment artifact" in rules

def test_conflicting_main_py_is_flagged():
    data=json.loads((AUDIT/"integration_findings.json").read_text(encoding="utf-8"))
    assert "cybernetics-engine-v1/main.py" in data["duplicate_paths_conflicting"]

def test_conflicting_requirements_are_flagged():
    data=json.loads((AUDIT/"integration_findings.json").read_text(encoding="utf-8"))
    assert "cybernetics-engine-v1/requirements.txt" in data["duplicate_paths_conflicting"]

def test_no_secrets_are_in_audit_artifact():
    for p in ROOT.rglob("*"):
        if p.is_file() and p.suffix in {".json",".csv",".md"}:
            s=p.read_text(errors="ignore").lower()
            assert "dhan_access_token=" not in s
            assert "api_secret=" not in s
