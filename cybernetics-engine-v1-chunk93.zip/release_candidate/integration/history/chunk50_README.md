# Cybernetics Trading Engine — Chunk 50

## Risk Engine Request Evaluator

This chunk adds the deterministic evaluation boundary for `StrategyRiskRequest`.

The evaluator checks:
- emergency-stop state
- live authorization when the request explicitly targets live mode
- proposed quantity validity
- contract multiplier validity
- entry price validity
- maximum open exposure
- margin capacity guard
- stop-distance trade risk
- daily loss limit

Exit requests are treated separately so protective exits are not rejected merely
because entry-specific risk checks do not apply.

This evaluator is **not** the complete sizing engine and does not submit orders.
The `proposed_quantity` is an explicit downstream input for evaluation; strategy
code is not granted sizing authority.

The existing PreTrade Gate / Execution Coordinator remains downstream.
