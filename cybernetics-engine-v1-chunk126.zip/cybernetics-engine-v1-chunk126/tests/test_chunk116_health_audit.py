from cybernetics.audit import HealthAuditEmitter, InMemoryAuditStore
from cybernetics.watchdog.health import Health, HealthRegistry


def test_registry_health_change_emits_once_and_only_on_change():
    sink = InMemoryAuditStore()
    emitter = HealthAuditEmitter(sink)
    registry = HealthRegistry()
    registry.beat("db", health=Health.HEALTHY, now=1.0)
    first = emitter.observe_registry(registry)
    assert len(first) == 1
    second = emitter.observe_registry(registry)
    assert second == []
    registry.fail("db", "connection_lost", now=2.0)
    third = emitter.observe_registry(registry)
    assert len(third) == 1
    assert third[0].event_type == "COMPONENT_HEALTH"
    assert third[0].severity == "ERROR"


def test_feed_health_deduplication_and_severity():
    sink = InMemoryAuditStore()
    emitter = HealthAuditEmitter(sink)
    assert emitter.emit_feed_state(1, "HEALTHY", timestamp=1.0) is not None
    assert emitter.emit_feed_state(1, "HEALTHY", timestamp=1.0) is None
    event = emitter.emit_feed_state(1, "STALE", detail="no_packets", timestamp=2.0)
    assert event is not None
    assert event.severity == "ERROR"
