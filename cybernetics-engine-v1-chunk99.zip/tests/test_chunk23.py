from cybernetics.brokers.interface import BrokerAdapter, BrokerOrderRequest, BrokerOrderResult
from cybernetics.brokers.router import BrokerRoute, MultiBrokerRouter, NullBrokerAdapter
from cybernetics.brokers.dhan import DhanV2Adapter

class FakeBroker(BrokerAdapter):
    name="FAKE"
    def health(self): return {"ok":True}
    def get_positions(self): return []
    def get_orders(self): return []
    def place_order(self, request): return BrokerOrderResult(self.name,True,"F1","ACCEPTED")
    def cancel_order(self, broker_order_id): return BrokerOrderResult(self.name,True,broker_order_id,"CANCELLED")

def req():
    return BrokerOrderRequest("NIFTY","BUY",10,"MARKET")

def test_disabled_route_blocks():
    r=MultiBrokerRouter()
    r.register(BrokerRoute("dhan","DHAN_V2",DhanV2Adapter()))
    out=r.place("dhan",req())
    assert out.status=="BLOCKED"

def test_enabled_route_delegates():
    r=MultiBrokerRouter()
    r.register(BrokerRoute("b2","FAKE",FakeBroker()))
    r.enable("b2")
    out=r.place("b2",req())
    assert out.accepted and out.broker_order_id=="F1"

def test_multiple_adapters_can_coexist():
    r=MultiBrokerRouter()
    r.register(BrokerRoute("b2","FAKE",FakeBroker()))
    r.register(BrokerRoute("null","NULL",NullBrokerAdapter()))
    assert len(r.list_routes())==2

def test_dhan_adapter_has_no_live_io_here():
    a=DhanV2Adapter()
    assert a.health()["live_io_enabled"] is False
    assert a.place_order(req()).status=="BLOCKED"

def test_strategy_does_not_need_broker_specific_types():
    request=req()
    assert request.symbol=="NIFTY" and request.exchange_segment=="NSE_FNO"
