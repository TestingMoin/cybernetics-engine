from datetime import datetime, timezone, timedelta
from pathlib import Path
import os, tempfile

from cybernetics.auth.token_manager import DhanTokenManager, TokenState
from cybernetics.auth.secret_provider import EnvSecretProvider, FileSecretProvider

NOW=datetime(2026,9,7,9,0,0,tzinfo=timezone.utc)

def test_generated_token_is_stored_and_state_is_valid():
    def transport(method,url,**kwargs):
        return {"accessToken":"TOKEN1","expiryTime":"2026-09-08T14:30:00+05:30"}
    m=DhanTokenManager("123",transport,now=lambda:NOW)
    r=m.generate_with_totp("pin","123456")
    assert r.access_token=="TOKEN1"
    assert m.state()==TokenState.VALID
    assert m.authorization_header()["access-token"]=="TOKEN1"

def test_refresh_margin_moves_valid_to_renew_required():
    m=DhanTokenManager("123",lambda *a,**k:{},now=lambda:NOW,
                       refresh_margin=timedelta(hours=6))
    m.set_token("T",NOW+timedelta(hours=5))
    assert m.state()==TokenState.RENEW_REQUIRED

def test_expired_token_is_blocked():
    m=DhanTokenManager("123",lambda *a,**k:{},now=lambda:NOW)
    m.set_token("T",NOW-timedelta(seconds=1))
    assert m.state()==TokenState.EXPIRED
    try:
        m.authorization_header()
        assert False
    except RuntimeError as e:
        assert str(e)=="access_token_expired"

def test_expired_token_cannot_be_renewed():
    m=DhanTokenManager("123",lambda *a,**k:{},now=lambda:NOW)
    m.set_token("T",NOW-timedelta(seconds=1))
    try:
        m.renew()
        assert False
    except RuntimeError as e:
        assert str(e)=="token_already_expired"

def test_renew_uses_current_token():
    calls=[]
    def transport(method,url,**kwargs):
        calls.append((method,url,kwargs))
        return {"accessToken":"T2","expiryTime":"2026-09-08T14:30:00+05:30"}
    m=DhanTokenManager("123",transport,now=lambda:NOW)
    m.set_token("T1",NOW+timedelta(hours=1))
    out=m.renew()
    assert out.access_token=="T2"
    assert calls[0][2]["headers"]["access-token"]=="T1"

def test_environment_secret_provider():
    os.environ["CTE_TEST_SECRET"]="abc"
    assert EnvSecretProvider().get("TEST_SECRET")=="abc"
    del os.environ["CTE_TEST_SECRET"]

def test_file_secret_provider_rejects_broad_permissions():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/"TOKEN"
        p.write_text("secret")
        p.chmod(0o644)
        try:
            FileSecretProvider(d).get("TOKEN")
            assert False
        except PermissionError:
            assert True

def test_file_secret_provider_accepts_0600():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/"TOKEN"
        p.write_text("secret")
        p.chmod(0o600)
        assert FileSecretProvider(d).get("TOKEN")=="secret"
