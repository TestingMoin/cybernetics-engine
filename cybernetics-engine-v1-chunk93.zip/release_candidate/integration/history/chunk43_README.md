# Cybernetics Trading Engine — Chunk 43

## Market Event -> Scanner -> Indicator -> Signal Registry Integration

This chunk connects the market-data dispatch boundary to indicator processing and the
Signal Registry through dependency injection.

Flow:
market event -> explicit scanner routing -> isolated runtime -> indicator boundary
-> optional signal factory -> Signal Registry.

Safety:
- unrouted events stop before indicator processing;
- missing OHLCV stops indicator processing;
- signal registration is separate from order execution;
- duplicate signal IDs are rejected;
- no broker calls are present.

No confluence, strategy, risk, pre-trade or execution logic is introduced here.
