# Cybernetics Trading Engine — Chunk 96

## Scope
Production dependency and packaging audit. This chunk establishes a reproducible Python package boundary, packages the canonical PostgreSQL schema as package data, and validates clean installation and CLI startup without enabling live trading.

## Changes
- Added PEP 517/518 setuptools build configuration.
- Added explicit package discovery for `src/cybernetics*`.
- Packaged `cybernetics.db/schema.sql` as package data.
- Added canonical schema resource resolver via `importlib.resources`.
- Updated schema consumers to use the shared resolver instead of fragile project-root-relative paths.
- Added console entry point `cybernetics-engine`.
- Added Chunk 96 regression tests for packaged schema resolution and installed CLI self-check.

## Validation
- `python -m compileall -q src`: PASS
- `pytest -q`: **805 passed**
- Wheel build with `pip wheel . --no-deps --no-build-isolation`: PASS
- Clean virtualenv install from locally built wheel: PASS
- `python -m cybernetics --self-check`: PASS
- `cybernetics-engine --self-check`: PASS
- Self-check confirms `new_trades_allowed: false` and `live_authorization_invalid`.
- No Dhan order submission or production database connection performed.

## Wheel SHA256
`4f5f27558f4c04d670ae24110b8905893be807446f2a1bff4f6019f561540411`

## Release Status
RELEASE-CANDIDATE — Chunk 96 validated locally. VPS deployment remains disabled.
