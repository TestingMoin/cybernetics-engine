from cybernetics.runtime.control import ControlAction, ControlState, ControlStateMachine, GuardedController
from cybernetics.runtime.control_recovery import ControlRecoveryIntegration
from cybernetics.runtime.persistent_control_recovery import PersistentControlRecoveryIntegration
from cybernetics.runtime.failure_handling import RuntimeDependencyFailureHandler
from cybernetics.runtime.state import EmergencyState


class Result:
    rowcount = 1


class FakeTx:
    def __init__(self): self.calls = []
    def execute(self, sql, params=()): self.calls.append((sql, params)); return Result()
    def __enter__(self): return self
    def __exit__(self, *args): pass


def healthy():
    return {n: True for n in RuntimeDependencyFailureHandler.CRITICAL_DEPENDENCIES}


def controller_at_stop():
    c = GuardedController(ControlStateMachine(ControlState.ENGINE_OFF))
    c.apply(ControlAction.START); c.apply(ControlAction.START_SUCCESS); c.apply(ControlAction.STOP_NEW_TRADES)
    return c


def test_observe_is_durably_audited():
    c=controller_at_stop(); tx=FakeTx(); i=PersistentControlRecoveryIntegration(ControlRecoveryIntegration(c), lambda:tx, lambda:"e1")
    bad=healthy(); bad["broker"]=False
    s=i.observe(bad, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert s.reason == "critical_dependencies_unhealthy"
    assert len(tx.calls)==1 and "control_recovery_audit" in tx.calls[0][0]
    assert tx.calls[0][1][0] == "e1"


def test_resume_is_durably_audited_after_guarded_transition():
    c=controller_at_stop(); tx=FakeTx(); ids=iter(["o1","o2","r1"])
    i=PersistentControlRecoveryIntegration(ControlRecoveryIntegration(c), lambda:tx, lambda:next(ids))
    bad=healthy(); bad["watchdog"]=False
    i.observe(bad, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    i.observe(healthy(), emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    s=i.explicit_resume(healthy(), emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert s.reason == "explicit_resume_approved"
    assert c.machine.state is ControlState.RUNNING
    assert tx.calls[-1][1][0] == "r1"


def test_duplicate_event_id_is_idempotent_boundary():
    c=controller_at_stop(); tx=FakeTx(); i=PersistentControlRecoveryIntegration(ControlRecoveryIntegration(c), lambda:tx, lambda:"same")
    i.observe(healthy(), emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    i.observe(healthy(), emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    assert len(tx.calls)==2
    assert all("ON CONFLICT (event_id) DO NOTHING" in x[0] for x in tx.calls)


def test_audit_contains_failures_as_json():
    c=controller_at_stop(); tx=FakeTx(); i=PersistentControlRecoveryIntegration(ControlRecoveryIntegration(c), lambda:tx, lambda:"e2")
    bad=healthy(); bad["market_data"]=False; bad["scanners"]=False
    i.observe(bad, emergency_state=EmergencyState.CLEAR, live_authorization_valid=False)
    params=tx.calls[0][1]
    assert 'market_data' in params[6] and 'scanners' in params[6]


def test_persistence_failure_does_not_bypass_control_decision():
    c=controller_at_stop()
    class Broken:
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def execute(self,*a): raise RuntimeError("db_down")
    i=PersistentControlRecoveryIntegration(ControlRecoveryIntegration(c), lambda:Broken(), lambda:"e3")
    bad=healthy(); bad["persistence"]=False
    try: i.observe(bad, emergency_state=EmergencyState.CLEAR, live_authorization_valid=True)
    except RuntimeError as e: assert str(e)=="db_down"
    assert c.machine.state is ControlState.STOP_NEW_TRADES


def test_schema_has_audit_table_and_required_migration():
    from cybernetics.persistence.migration import AUTHORITATIVE_MIGRATIONS, PRODUCTION_STARTUP_REQUIRED_TABLES
    from cybernetics.persistence.migration import ADDITIVE_MIGRATIONS
    assert [m.version for m in AUTHORITATIVE_MIGRATIONS] == [1]
    assert any(m.version==2 and m.name=="control_recovery_audit" for m in ADDITIVE_MIGRATIONS)
    assert "control_recovery_audit" not in PRODUCTION_STARTUP_REQUIRED_TABLES
