from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Any

from .instrument import TradeInstrument
from .intent import ExecutionIntent, ExecutionAction, OrderType


@dataclass(frozen=True)
class BindingValidation:
    passed: bool
    reason: str


@dataclass(frozen=True)
class BoundExecutionInstruction:
    """
    Broker-ready *boundary object* with the exact selected contract bound.

    It is still not a broker payload and contains no authentication or order
    submission command.
    """
    intent_id: str
    trade_id: str
    strategy_id: str
    strategy_version: str
    signal_id: str

    exchange_segment: str
    security_id: str
    symbol: str

    action: ExecutionAction
    order_type: OrderType
    quantity: int

    lot_size: int
    tick_size: float
    contract_multiplier: float

    expiry: Optional[object] = None
    strike: Optional[float] = None
    option_type: Optional[object] = None

    limit_price: Optional[float] = None
    product_type: str = "INTRADAY"
    validity: str = "DAY"
    metadata: dict[str, Any] = field(default_factory=dict)


class ExecutionIntentInstrumentBinder:
    """
    Binds an immutable ExecutionIntent to exactly one already-approved
    TradeInstrument.

    Revalidation is intentionally performed here because instrument metadata
    can become stale between selection and execution.
    """

    def bind(
        self,
        intent: ExecutionIntent,
        instrument: TradeInstrument,
    ) -> BoundExecutionInstruction:

        self._validate_identity(intent, instrument)
        self._validate_quantity(intent.quantity, instrument.lot_size)
        self._validate_price_tick(intent, instrument.tick_size)
        self._validate_option_contract(instrument)

        return BoundExecutionInstruction(
            intent_id=intent.intent_id,
            trade_id=intent.trade_id,
            strategy_id=intent.strategy_id,
            strategy_version=intent.strategy_version,
            signal_id=intent.signal_id,
            exchange_segment=instrument.exchange_segment,
            security_id=instrument.security_id,
            symbol=instrument.symbol,
            action=intent.action,
            order_type=intent.order_type,
            quantity=intent.quantity,
            lot_size=instrument.lot_size,
            tick_size=instrument.tick_size,
            contract_multiplier=instrument.contract_multiplier,
            expiry=instrument.expiry,
            strike=instrument.strike,
            option_type=instrument.option_type,
            limit_price=intent.limit_price,
            product_type=intent.product_type,
            validity=intent.validity,
            metadata=dict(intent.metadata),
        )

    @staticmethod
    def _validate_identity(
        intent: ExecutionIntent,
        instrument: TradeInstrument,
    ) -> None:
        if not instrument.exchange_segment or not instrument.security_id:
            raise ValueError("bound_instrument_identity_required")
        if not instrument.symbol:
            raise ValueError("bound_instrument_symbol_required")

        expected_symbol = intent.underlying_key.upper()
        if instrument.symbol.upper() != expected_symbol:
            raise ValueError("intent_instrument_symbol_mismatch")

    @staticmethod
    def _validate_quantity(quantity: int, lot_size: int) -> None:
        if quantity <= 0:
            raise ValueError("bound_quantity_must_be_positive")
        if lot_size <= 0:
            raise ValueError("bound_lot_size_must_be_positive")
        if quantity % lot_size != 0:
            raise ValueError("bound_quantity_not_lot_aligned")

    @staticmethod
    def _validate_price_tick(
        intent: ExecutionIntent,
        tick_size: float,
    ) -> None:
        if tick_size <= 0:
            raise ValueError("bound_tick_size_must_be_positive")

        if intent.order_type != OrderType.LIMIT:
            return

        price = intent.limit_price
        if price is None or price <= 0:
            raise ValueError("bound_limit_price_invalid")

        # Avoid binary floating-point equality. A price is valid when it is
        # effectively on the instrument's tick grid.
        units = round(price / tick_size)
        snapped = units * tick_size
        tolerance = max(1e-9, tick_size * 1e-9)
        if abs(price - snapped) > tolerance:
            raise ValueError("limit_price_not_on_tick_grid")

    @staticmethod
    def _validate_option_contract(instrument: TradeInstrument) -> None:
        # TradeInstrument already validates the required option fields.
        # Re-check here to protect the final binding boundary if this object
        # came from another serialization/deserialization path.
        if getattr(instrument, "instrument_type", None).value == "OPTION":
            if instrument.expiry is None:
                raise ValueError("bound_option_expiry_required")
            if instrument.strike is None or instrument.strike <= 0:
                raise ValueError("bound_option_strike_required")
            if instrument.option_type is None:
                raise ValueError("bound_option_type_required")
