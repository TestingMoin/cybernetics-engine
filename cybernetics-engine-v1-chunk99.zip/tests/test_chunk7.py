from datetime import date, datetime, timezone, timedelta
from decimal import Decimal

from cybernetics.futures.engine import FuturesEngine
from cybernetics.futures.models import ContractSpec, FuturesQuote
from cybernetics.futures.selector import ContractSelector, SelectionPolicy


def contract(expiry=date(2026, 10, 29)):
    return ContractSpec(
        security_id="12345", exchange="NSE", segment="NSE_FNO",
        underlying_symbol="NIFTY", trading_symbol="NIFTY-FUT",
        expiry=expiry, lot_size=75, tick_size=Decimal("0.05"), multiplier=Decimal("1")
    )


def main():
    c = contract()
    assert FuturesEngine.notional(c, Decimal("100")) == Decimal("7500")
    assert FuturesEngine.tick_value(c) == Decimal("3.75")
    assert FuturesEngine.mark_to_market(c, Decimal("100"), Decimal("102"), 2) == Decimal("300")

    e = FuturesEngine()
    e.register(c)
    t0 = datetime(2026, 9, 7, 10, 0, tzinfo=timezone.utc)
    e.ingest(FuturesQuote("12345", t0, Decimal("100"), Decimal("99.95"), Decimal("100.05"), 100, 1000, Decimal("98")))
    s = e.ingest(FuturesQuote("12345", t0 + timedelta(seconds=1), Decimal("101"), Decimal("100.95"), Decimal("101.05"), 130, 1075, Decimal("98")))
    assert s.oi_change == 75 and s.volume_change == 30 and s.basis == Decimal("3")
    assert FuturesEngine.spread(c, s.last_quote) == Decimal("0.10")

    contracts = [
        contract(date(2026, 9, 24)),
        contract(date(2026, 10, 29)),
        contract(date(2026, 11, 26)),
    ]
    contracts[0] = ContractSpec(**{**contracts[0].__dict__, "security_id": "1"})
    contracts[1] = ContractSpec(**{**contracts[1].__dict__, "security_id": "2"})
    contracts[2] = ContractSpec(**{**contracts[2].__dict__, "security_id": "3"})
    selected = ContractSelector.select(contracts, SelectionPolicy("NIFTY", date(2026, 9, 7)))
    assert selected.security_id == "1"

    try:
        e.ingest(FuturesQuote("12345", t0, Decimal("0")))
        raise AssertionError("invalid LTP accepted")
    except ValueError:
        pass

    print("Chunk 7 tests: 5/5 passed")


if __name__ == "__main__":
    main()
