# Cybernetics Trading Engine — Chunk 85

## WebSocket Interface Reconciliation & Canonicalization

The first concrete interface conflict from Chunk 83/84 is resolved.

Canonical:
`src/cybernetics/websocket/subscriptions.py`

Source selected:
Chunk 32 implementation.

The richer Chunk 32 subscription manager is compatible with the Chunk 33 feed
sharder/supervisor and preserves the required Dhan subscription functionality.

Validation covers:
- subscription modes
- Dhan subscribe/unsubscribe request codes
- 100-item message chunking
- 5000-item connection ceiling
- deterministic sharding
- feed supervisor health dependency
- deterministic subscription state

No Dhan broker/order execution is performed here.
