from __future__ import annotations
from dataclasses import dataclass
from enum import Enum

class EngineMode(str, Enum):
    STOPPED="STOPPED"
    RUNNING="RUNNING"

class EmergencyState(str, Enum):
    CLEAR="CLEAR"
    ACTIVE="ACTIVE"

@dataclass(frozen=True)
class RuntimeInputs:
    engine_mode: EngineMode
    control_state: str
    emergency_state: EmergencyState
    persistence_ready: bool
    recovery_clear: bool
    orders_reconciled: bool
    positions_reconciled: bool
    market_data_ready: bool
    scanner_health_ready: bool
    watchdog_healthy: bool
    broker_available: bool
    live_authorization_valid: bool

@dataclass(frozen=True)
class RuntimeReadiness:
    engine_ready: bool
    new_trades_allowed: bool
    reasons: tuple[str,...]

def evaluate_runtime(inputs: RuntimeInputs)->RuntimeReadiness:
    reasons=[]
    if inputs.engine_mode is not EngineMode.RUNNING: reasons.append("engine_not_running")
    if inputs.persistence_ready is False: reasons.append("persistence_not_ready")
    if inputs.recovery_clear is False: reasons.append("recovery_not_clear")
    if inputs.orders_reconciled is False: reasons.append("orders_not_reconciled")
    if inputs.positions_reconciled is False: reasons.append("positions_not_reconciled")
    if inputs.market_data_ready is False: reasons.append("market_data_not_ready")
    if inputs.scanner_health_ready is False: reasons.append("scanner_health_not_ready")
    if inputs.watchdog_healthy is False: reasons.append("watchdog_not_healthy")
    if inputs.broker_available is False: reasons.append("broker_unavailable")
    if inputs.emergency_state is EmergencyState.ACTIVE: reasons.append("emergency_stop_active")
    engine_blockers={
        "engine_not_running","persistence_not_ready","recovery_not_clear",
        "orders_not_reconciled","positions_not_reconciled","market_data_not_ready",
        "scanner_health_not_ready","watchdog_not_healthy","broker_unavailable",
    }
    engine_ready=not any(r in engine_blockers for r in reasons)
    if not inputs.live_authorization_valid:
        reasons.append("live_authorization_invalid")
    new_trades_allowed=(
        engine_ready
        and inputs.emergency_state is EmergencyState.CLEAR
        and inputs.control_state=="RUNNING"
        and inputs.live_authorization_valid
    )
    return RuntimeReadiness(engine_ready,new_trades_allowed,tuple(reasons))
