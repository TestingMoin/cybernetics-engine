from cybernetics.runtime.market_feed import (
    MarketFeedRuntimeWiring,
    build_market_feed_wiring,
)


class HealthyFeed:
    def safe_for_market_state(self):
        return True


class UnhealthyFeed:
    def safe_for_market_state(self):
        return False


def test_healthy_feed_is_ready():
    wiring = build_market_feed_wiring(supervisor=HealthyFeed())
    assert wiring.market_data_ready() is True
    assert wiring.unhealthy() is False


def test_unhealthy_feed_blocks_readiness():
    wiring = MarketFeedRuntimeWiring(UnhealthyFeed())
    assert wiring.market_data_ready() is False
    assert wiring.unhealthy() is True


def test_probe_exception_fails_closed():
    class Broken:
        def safe_for_market_state(self):
            raise RuntimeError("feed unavailable")

    wiring = build_market_feed_wiring(supervisor=Broken())
    assert wiring.market_data_ready() is False


def test_custom_readiness_probe_is_used():
    calls = []

    def probe(component):
        calls.append(component)
        return True

    feed = UnhealthyFeed()
    wiring = build_market_feed_wiring(supervisor=feed, readiness=probe)
    assert wiring.market_data_ready() is True
    assert calls == [feed]


def test_missing_supervisor_rejected():
    try:
        build_market_feed_wiring(supervisor=None)
    except ValueError as exc:
        assert str(exc) == "market_feed_supervisor_required"
    else:
        raise AssertionError("expected ValueError")
