from app.control.state import ControlPlane


def test_live_requires_running_engine():
    cp = ControlPlane()
    try:
        cp.enable_live("test")
        assert False, "live authorization should fail while engine is stopped"
    except RuntimeError:
        pass


def test_stop_disables_live():
    cp = ControlPlane()
    cp.start_engine("test")
    cp.enable_live("test")
    assert cp.snapshot().live_authorized is True
    cp.stop_engine("test")
    assert cp.snapshot().live_authorized is False


def test_emergency_stop_is_stronger():
    cp = ControlPlane()
    cp.start_engine("test")
    cp.enable_live("test")
    cp.emergency_stop_now("test")
    s = cp.snapshot()
    assert s.engine_running is False
    assert s.live_authorized is False
    assert s.kill_switch is True
    assert s.emergency_stop is True
