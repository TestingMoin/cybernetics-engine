from datetime import datetime, timezone, timedelta
from cybernetics.indicators.standard_registry import build_standard_registry
from cybernetics.indicator_adapter.adapter import IndicatorStateAdapter, IndicatorExecutionError
from cybernetics.indicator_adapter.models import RuntimeIndicatorState

def test_each_runtime_has_independent_history():
    a=IndicatorStateAdapter(build_standard_registry(),max_history=50)
    s1=a.runtime("NIFTY","1m");s2=a.runtime("BANKNIFTY","1m")
    ts=datetime(2026,1,1,tzinfo=timezone.utc)
    for i in range(20):
        a.process(s1,timestamp=ts+timedelta(minutes=i),high=102+i,low=98+i,close=100+i,volume=100)
    out=a.process(s2,timestamp=ts,high=102,low=98,close=100,volume=100)
    assert out.values["EMA"] is None
    assert s2.observation_count==1 and s1.observation_count==20

def test_registry_indicators_are_executed_incrementally():
    a=IndicatorStateAdapter(build_standard_registry())
    s=a.runtime("NIFTY","1m")
    ts=datetime(2026,1,1,tzinfo=timezone.utc)
    out=None
    for i in range(30):
        out=a.process(s,timestamp=ts+timedelta(minutes=i),
                      high=102+i,low=98+i,close=100+i,volume=1000)
    assert out.values["EMA"] is not None
    assert out.values["RSI"] is not None
    assert "EMA" in out.ready

def test_state_records_latest_values():
    a=IndicatorStateAdapter(build_standard_registry())
    s=a.runtime("X","5m")
    ts=datetime(2026,1,1,tzinfo=timezone.utc)
    out=a.process(s,timestamp=ts,high=101,low=99,close=100,volume=10)
    assert s.last_timestamp==ts
    assert s.values["EMA"] is None
    assert out.security_id=="X"

def test_history_is_bounded():
    a=IndicatorStateAdapter(build_standard_registry(),max_history=3)
    s=a.runtime("X","1m")
    ts=datetime(2026,1,1,tzinfo=timezone.utc)
    for i in range(10):
        a.process(s,timestamp=ts+timedelta(minutes=i),
                  high=101,low=99,close=100,volume=1)
    h=a._history[("X","1m")]
    assert len(h["closes"])==3

def test_invalid_ohlc_rejected():
    a=IndicatorStateAdapter(build_standard_registry())
    s=a.runtime("X","1m")
    try:
        a.process(s,timestamp=datetime.now(timezone.utc),
                  high=99,low=100,close=100,volume=1)
        assert False
    except ValueError as e:
        assert str(e)=="invalid_ohlc"

def test_negative_volume_rejected():
    a=IndicatorStateAdapter(build_standard_registry())
    s=a.runtime("X","1m")
    try:
        a.process(s,timestamp=datetime.now(timezone.utc),
                  high=101,low=99,close=100,volume=-1)
        assert False
    except ValueError as e:
        assert str(e)=="negative_volume"

def test_unsupported_indicator_definition_is_explicitly_rejected():
    from cybernetics.indicators.registry import IndicatorRegistry,IndicatorSpec,IndicatorTier
    r=IndicatorRegistry()
    r.register(IndicatorSpec("CUSTOM","1.0","TEST",IndicatorTier.RESEARCH,lambda *args: 1))
    a=IndicatorStateAdapter(r)
    s=a.runtime("X","1m")
    try:
        a.process(s,timestamp=datetime.now(timezone.utc),high=101,low=99,close=100,volume=1)
        assert False
    except IndicatorExecutionError as e:
        assert "unsupported_indicator:CUSTOM" in str(e)
