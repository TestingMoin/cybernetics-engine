from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from typing import Optional, Any


class RiskAction(str, Enum):
    ENTER_LONG = "ENTER_LONG"
    ENTER_SHORT = "ENTER_SHORT"
    EXIT_LONG = "EXIT_LONG"
    EXIT_SHORT = "EXIT_SHORT"
    HOLD = "HOLD"
    NO_ACTION = "NO_ACTION"


@dataclass(frozen=True)
class StrategyRiskRequest:
    """
    Strategy-to-risk contract.

    Strategy supplies intent and explicit risk inputs such as stop reference,
    but never supplies final quantity, broker order payloads, or execution calls.
    """
    request_id: str
    strategy_id: str
    strategy_version: str
    signal_id: str
    trade_id: str
    underlying_key: str
    timeframe: str
    action: RiskAction
    timestamp: datetime

    entry_reference_price: Optional[float] = None
    stop_reference_price: Optional[float] = None
    target_reference_price: Optional[float] = None

    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.request_id or not self.strategy_id or not self.strategy_version:
            raise ValueError("risk_request_identity_required")
        if not self.signal_id or not self.trade_id or not self.underlying_key:
            raise ValueError("risk_request_context_required")
        if self.entry_reference_price is not None and self.entry_reference_price <= 0:
            raise ValueError("entry_reference_price_must_be_positive")
        if self.stop_reference_price is not None and self.stop_reference_price <= 0:
            raise ValueError("stop_reference_price_must_be_positive")
        if self.target_reference_price is not None and self.target_reference_price <= 0:
            raise ValueError("target_reference_price_must_be_positive")


@dataclass(frozen=True)
class RiskHandoffResult:
    accepted: bool
    reason: str
    request: StrategyRiskRequest


class StrategyRiskHandoff:
    """
    Pure handoff boundary. It validates request shape and separates strategy
    intent from the Risk Engine. No sizing, margin calculation, or execution is
    performed here.
    """

    EXECUTABLE_ACTIONS = {
        RiskAction.ENTER_LONG,
        RiskAction.ENTER_SHORT,
        RiskAction.EXIT_LONG,
        RiskAction.EXIT_SHORT,
    }

    def create_request(
        self,
        *,
        strategy_id: str,
        strategy_version: str,
        signal_id: str,
        trade_id: str,
        underlying_key: str,
        timeframe: str,
        action: RiskAction | str,
        timestamp: datetime,
        entry_reference_price: Optional[float] = None,
        stop_reference_price: Optional[float] = None,
        target_reference_price: Optional[float] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> RiskHandoffResult:
        try:
            normalized = action if isinstance(action, RiskAction) else RiskAction(str(action).upper())
        except ValueError:
            return RiskHandoffResult(
                False, "unsupported_risk_action",
                StrategyRiskRequest(
                    request_id="INVALID",
                    strategy_id=strategy_id,
                    strategy_version=strategy_version,
                    signal_id=signal_id or "INVALID",
                    trade_id=trade_id or "INVALID",
                    underlying_key=underlying_key or "INVALID",
                    timeframe=timeframe or "INVALID",
                    action=RiskAction.NO_ACTION,
                    timestamp=timestamp,
                    metadata=metadata or {},
                ),
            )

        request_id = f"{strategy_id}:{trade_id}:{signal_id}:{normalized.value}"

        request = StrategyRiskRequest(
            request_id=request_id,
            strategy_id=strategy_id,
            strategy_version=strategy_version,
            signal_id=signal_id,
            trade_id=trade_id,
            underlying_key=underlying_key,
            timeframe=timeframe,
            action=normalized,
            timestamp=timestamp,
            entry_reference_price=entry_reference_price,
            stop_reference_price=stop_reference_price,
            target_reference_price=target_reference_price,
            metadata=metadata or {},
        )

        if normalized in {RiskAction.HOLD, RiskAction.NO_ACTION}:
            return RiskHandoffResult(False, "non_executable_strategy_action", request)

        return RiskHandoffResult(True, "risk_request_created", request)
