# Cybernetics Trading Engine — Chunk 28

## Dhan V2 Order Adapter — Paper/Shadow First

This chunk creates the Dhan-specific order translation boundary using an injected transport.

Implemented:
- Place order request mapping.
- Get order by broker order ID.
- Get order by correlation ID.
- Cancel order.
- Dhan response normalization.
- API error normalization.
- Access-token header injection.
- Correlation ID propagation from the engine's client order key.

The adapter is directly testable without credentials or network access.

IMPORTANT:
- No real credentials are stored in source.
- No live order is submitted by the test suite.
- The adapter does not itself decide whether trading is allowed.
- ExecutionCoordinator / Risk / Idempotency / Reconciliation remain mandatory upstream controls.
