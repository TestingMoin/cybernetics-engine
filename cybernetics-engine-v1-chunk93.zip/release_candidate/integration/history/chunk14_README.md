# Cybernetics Trading Engine — Chunk 14

System Risk + Strategy Risk sizing + Pre-Trade gate.

Key rules:
- Contract/lot aligned quantity only.
- Stop-based risk sizing never forces a minimum lot.
- Margin availability is a hard constraint.
- Daily loss and exposure limits are hard constraints.
- Live authorization is independent from engine health.
- Kill switch and emergency stop are hard blockers.
- No broker execution exists in this chunk.
