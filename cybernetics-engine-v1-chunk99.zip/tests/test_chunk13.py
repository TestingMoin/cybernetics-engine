from cybernetics.quality.decision import Evidence, QualityEngine
from cybernetics.quality.policies import DEFAULT_GOLDEN_POLICIES

def test_accepts_aligned():
    q=QualityEngine().evaluate(direction="LONG",
       evidence=[Evidence("strategy","LONG",.9),Evidence("ichimoku","LONG",.8)],
       data_quality_ok=True,strategy_approved=True,regime="TREND_UP",
       min_score=.6,required_names=("strategy",))
    assert q.accepted and q.score > .6

def test_rejects_bad_data():
    q=QualityEngine().evaluate(direction="LONG",
       evidence=[Evidence("strategy","LONG",1)],
       data_quality_ok=False,strategy_approved=True)
    assert not q.accepted and "data_quality_failed" in q.reasons

def test_conflict_not_aligned():
    q=QualityEngine().evaluate(direction="LONG",
       evidence=[Evidence("strategy","LONG",.7),Evidence("gap","SHORT",1)],
       data_quality_ok=True,strategy_approved=True)
    assert q.score == .7

def test_missing_required():
    q=QualityEngine().evaluate(direction="LONG",evidence=[],
       data_quality_ok=True,strategy_approved=True,required_names=("strategy",))
    assert not q.accepted

def test_policies():
    assert len(DEFAULT_GOLDEN_POLICIES)==2
