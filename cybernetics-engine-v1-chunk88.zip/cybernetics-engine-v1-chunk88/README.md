# Cybernetics Trading Engine — Chunk 88

## Execution Instrument Interface Reconciliation

Canonical execution instrument module:
`cybernetics.execution.instrument`

Canonical source:
Chunk 54.

Chunk 55 is treated as a dependent binding boundary and must consume these
models rather than redefine them.

Validation covers instrument identity, option metadata, eligibility, deterministic
selection, and ambiguity rejection.
