from __future__ import annotations
from dataclasses import dataclass
from enum import Enum


class EngineMode(str, Enum):
    STOPPED = "STOPPED"
    RUNNING = "RUNNING"


class ControlState(str, Enum):
    RUNNING = "RUNNING"
    STOP_NEW_TRADES = "STOP_NEW_TRADES"
    EMERGENCY_STOP = "EMERGENCY_STOP"


@dataclass(frozen=True)
class RuntimeInputs:
    engine_mode: EngineMode
    control_state: ControlState
    persistence_ready: bool
    recovery_clear: bool
    orders_reconciled: bool
    positions_reconciled: bool
    market_data_ready: bool
    scanner_health_ready: bool
    watchdog_healthy: bool
    live_authorization_valid: bool
    broker_available: bool


@dataclass(frozen=True)
class RuntimeReadiness:
    engine_ready: bool
    new_trades_allowed: bool
    reasons: tuple[str, ...]


def evaluate_runtime(inputs: RuntimeInputs) -> RuntimeReadiness:
    reasons: list[str] = []

    if inputs.engine_mode is not EngineMode.RUNNING:
        reasons.append("engine_not_running")
    if inputs.control_state is ControlState.EMERGENCY_STOP:
        reasons.append("emergency_stop_active")
    if inputs.control_state is ControlState.STOP_NEW_TRADES:
        reasons.append("stop_new_trades")
    if not inputs.persistence_ready:
        reasons.append("persistence_not_ready")
    if not inputs.recovery_clear:
        reasons.append("recovery_not_clear")
    if not inputs.orders_reconciled:
        reasons.append("orders_not_reconciled")
    if not inputs.positions_reconciled:
        reasons.append("positions_not_reconciled")
    if not inputs.market_data_ready:
        reasons.append("market_data_not_ready")
    if not inputs.scanner_health_ready:
        reasons.append("scanner_health_not_ready")
    if not inputs.watchdog_healthy:
        reasons.append("watchdog_not_healthy")
    if not inputs.broker_available:
        reasons.append("broker_unavailable")

    engine_ready = not any(
        r in reasons for r in (
            "engine_not_running",
            "persistence_not_ready",
            "recovery_not_clear",
            "orders_not_reconciled",
            "positions_not_reconciled",
            "market_data_not_ready",
            "scanner_health_not_ready",
            "watchdog_not_healthy",
            "broker_unavailable",
        )
    )

    new_trades_allowed = (
        engine_ready
        and inputs.control_state is ControlState.RUNNING
        and inputs.live_authorization_valid
    )

    if not inputs.live_authorization_valid:
        reasons.append("live_authorization_invalid")

    return RuntimeReadiness(
        engine_ready=engine_ready,
        new_trades_allowed=new_trades_allowed,
        reasons=tuple(reasons),
    )
