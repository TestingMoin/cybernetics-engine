from cybernetics.instruments.identity import InstrumentIdentity,InstrumentType
from cybernetics.instruments.master import InstrumentMaster,InstrumentLifecycle
from cybernetics.instruments.contracts import ContractResolver

def rows():
    return [
        {"SECURITY_ID":"1","EXCHANGE_SEGMENT":"NSE_FNO","SYMBOL_NAME":"NIFTY",
         "INSTRUMENT":"INDEX"},
        {"SECURITY_ID":"2","EXCHANGE_SEGMENT":"NSE_FNO","SYMBOL_NAME":"NIFTY26SEP-FUT",
         "INSTRUMENT":"FUTIDX","UNDERLYING_SYMBOL":"NIFTY","EXPIRY":"2026-09-24","LOT_SIZE":"65"},
        {"SECURITY_ID":"3","EXCHANGE_SEGMENT":"NSE_FNO","SYMBOL_NAME":"NIFTY26SEP-25000-CE",
         "INSTRUMENT":"OPTIDX","UNDERLYING_SYMBOL":"NIFTY","EXPIRY":"2026-09-24",
         "OPTION_TYPE":"CALL","STRIKE":"25000","LOT_SIZE":"65"},
        {"SECURITY_ID":"4","EXCHANGE_SEGMENT":"NSE_FNO","SYMBOL_NAME":"NIFTY26OCT-25000-CE",
         "INSTRUMENT":"OPTIDX","UNDERLYING_SYMBOL":"NIFTY","EXPIRY":"2026-10-29",
         "OPTION_TYPE":"CALL","STRIKE":"25000","LOT_SIZE":"65"},
    ]

def test_load_creates_unverified_items():
    m=InstrumentMaster()
    change=m.load(rows())
    assert len(change.added)==4
    assert m.generation==1
    assert m.lifecycle(("NSE_FNO","3"))==InstrumentLifecycle.UNVERIFIED

def test_approval_makes_instrument_trade_eligible():
    m=InstrumentMaster();m.load(rows())
    m.approve(("NSE_FNO","3"))
    assert m.trade_eligible(("NSE_FNO","3")) is True

def test_contracts_are_data_driven():
    m=InstrumentMaster();m.load(rows())
    m.approve(("NSE_FNO","2"));m.approve(("NSE_FNO","3"));m.approve(("NSE_FNO","4"))
    r=ContractResolver(m)
    opts=r.options("NIFTY",strike=25000,option_type="CALL")
    assert [x.expiry for x in opts]==["2026-09-24","2026-10-29"]

def test_nearest_expiry_selection():
    m=InstrumentMaster();m.load(rows())
    for k in [("NSE_FNO","3"),("NSE_FNO","4")]: m.approve(k)
    r=ContractResolver(m)
    chosen=r.nearest_expiry(r.options("NIFTY",strike=25000),__import__("datetime").date(2026,9,7))
    assert chosen.instrument.security_id=="3"

def test_removed_instrument_is_no_longer_trade_eligible():
    m=InstrumentMaster();m.load(rows())
    m.approve(("NSE_FNO","3"))
    m.load(rows()[:-1])
    assert m.lifecycle(("NSE_FNO","4"))==InstrumentLifecycle.WARNING
    assert m.trade_eligible(("NSE_FNO","4")) is False

def test_changed_instrument_is_reported():
    m=InstrumentMaster();m.load(rows())
    changed=rows();changed[1]=dict(changed[1],LOT_SIZE="70")
    change=m.load(changed)
    assert any(x.security_id=="2" for x in change.changed)

def test_duplicate_security_segment_is_rejected():
    m=InstrumentMaster()
    dup=rows()+[rows()[0]]
    try:
        m.load(dup);assert False
    except ValueError as e:
        assert "duplicate_instrument_key" in str(e)

def test_invalid_lot_size_rejected():
    try:
        InstrumentIdentity("1","NSE_FNO","X",lot_size=0)
        assert False
    except ValueError as e:
        assert str(e)=="invalid_lot_size"

def test_unapproved_new_contract_does_not_appear_in_trade_selection():
    m=InstrumentMaster();m.load(rows())
    r=ContractResolver(m)
    assert r.options("NIFTY",strike=25000,option_type="CALL")==[]
