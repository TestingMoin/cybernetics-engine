# Cybernetics Trading Engine — Chunk 46

## Golden Strategy Decision Adapter

This chunk wires the supplied Pine strategy rules into the strategy-decision
boundary.

Implemented reproduction targets:
- NIFTY/SENSEX Golden Strategy
- BankNifty Golden Strategy

The implementation intentionally does **not** claim full TradingView parity.
It provides a deterministic first-pass rule adapter with explicit parity fields.
Full parity still requires historical timestamp-by-timestamp comparison of
indicators, crossover events, signals, entries, exits, SL/TP, positions, trade
count, fees/slippage, and P&L against the supplied Pine backtests.

Important:
- No broker/API calls.
- No order placement.
- No risk sizing.
- No execution.
- No strategy enhancement.
- The BankNifty SELL branch is represented as an EXIT_LONG state because the
  supplied Pine logic uses sellSignal primarily as an exit condition.
