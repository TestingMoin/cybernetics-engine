from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Underlying:
    id: str
    name: str
    symbol: str
    exchange: str
    asset_class: str
    fno: bool = False
    options_available: bool | None = None


NSE_INDEXES = (
    Underlying("IDX-NSE-01", "NIFTY 50", "NIFTY", "NSE", "INDEX", True),
    Underlying("IDX-NSE-02", "NIFTY Bank", "BANKNIFTY", "NSE", "INDEX", True),
    Underlying("IDX-NSE-03", "NIFTY Financial Services", "FINNIFTY", "NSE", "INDEX", True),
    Underlying("IDX-NSE-04", "NIFTY Midcap Select", "MIDCPNIFTY", "NSE", "INDEX", True),
    Underlying("IDX-NSE-05", "NIFTY Next 50", "NIFTYNXT50", "NSE", "INDEX", True),
    Underlying("IDX-NSE-06", "Nifty India FPI 150", "NIFTYFPI", "NSE", "INDEX", True),
)

BSE_PLANNED_INDEXES = (
    Underlying("IDX-BSE-01", "SENSEX", "SENSEX", "BSE", "INDEX", True),
    Underlying("IDX-BSE-02", "BANKEX", "BANKEX", "BSE", "INDEX", True),
    Underlying("IDX-BSE-03", "SENSEX 50 / SX50", "SENSEX50", "BSE", "INDEX", True),
)

# Source notes also identify BSE FOCUSED IT as a current derivative-chain candidate.
# Keep it explicitly unverified until instrument-master validation promotes it.
BSE_UNVERIFIED_CANDIDATES = (
    Underlying("IDX-BSE-U01", "BSE FOCUSED IT", "BSEFOCUSEDIT", "BSE", "INDEX", True, None),
)

MCX_GROUPS: dict[str, tuple[str, ...]] = {
    "GOLD": ("Gold", "Gold Mini", "Gold Guinea", "Gold Petal", "Gold Ten"),
    "SILVER": ("Silver", "Silver Mini", "Silver Micro", "Silver 100"),
    "CRUDE_OIL": ("Crude Oil", "Crude Oil Mini"),
    "NATURAL_GAS": ("Natural Gas", "Natural Gas Mini"),
    "ALUMINIUM": ("Aluminium", "Aluminium Mini"),
    "ZINC": ("Zinc", "Zinc Mini"),
    "COPPER_NICKEL_STEEL": ("Copper", "Nickel", "Steel Rebar"),
    "AGRICULTURE": (
        "Cardamom", "Cotton", "Cotton Seed Wash Oil", "Crude Palm Oil",
        "Kapas", "Mentha Oil",
    ),
    "COMMODITY_INDICES": (
        "MCX iCOMDEX", "BULLDEX", "METLDEX", "Gold Index", "Silver Index",
        "Copper Index", "Crude Oil Index",
    ),
}

# Logical scanner count: 6 NSE index + 3 planned BSE index + 9 MCX groups + 21 NSE stock groups.
# The actual software remains reusable/configuration-driven; this is not 39 code copies.
LOGICAL_SCANNER_GROUP_COUNT = 39
