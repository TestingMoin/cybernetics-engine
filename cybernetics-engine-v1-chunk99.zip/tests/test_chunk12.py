from cybernetics.strategies.models import StrategyContext
from cybernetics.strategies.golden import NiftySensexGoldenStrategy, BankNiftyGoldenStrategy
from cybernetics.strategies.research import SmartRenkoStrategy, SwingStructureForecast
from cybernetics.strategies.manifest import golden_manifest

def ctx(symbol="NIFTY", close=100.0, month=5, position_side="FLAT"):
    return StrategyContext(1.0,symbol,"1m",close,month,position_side)

def test_nifty_long_entry():
    s=NiftySensexGoldenStrategy()
    d=s.decide(ctx(), fast_ema=101, slow_ema=100, prev_fast_ema=99, prev_slow_ema=100,
               daily_fast=101,daily_slow=100)
    assert d.action=="ENTER_LONG" and d.stop_price==99.5 and d.target_price==101

def test_nifty_short_entry_allowed_by_source_logic():
    s=NiftySensexGoldenStrategy()
    d=s.decide(ctx(month=2), fast_ema=99, slow_ema=100, prev_fast_ema=101, prev_slow_ema=100,
               daily_fast=99,daily_slow=100)
    assert d.action=="ENTER_SHORT"

def test_banknifty_multifactor_entry():
    s=BankNiftyGoldenStrategy()
    d=s.decide(ctx("BANKNIFTY",100,4), daily_ema40=100,daily_ema120=99,daily_ema200=98, tf_filters_up=True, ema40=101,ema120=100,ema200=99, md_line=2.0, md_signal=1.0)
    assert d.action=="ENTER_LONG"

def test_smart_renko_is_research():
    s=SmartRenkoStrategy()
    d=s.decide(ctx(), fast_ema=101,slow_ema=100,prev_fast_ema=99,prev_slow_ema=100,adx=25,volume_ok=True,supertrend_up=True,in_trap=False)
    assert d.action=="ENTER_LONG"
    assert s.strategy_id.startswith("RESEARCH_")

def test_swing_forecast():
    s=SwingStructureForecast()
    x=s.forecast([1,2,3],[2,3,4],100,False)
    assert x and x["target"]>100 and len(x["fib_targets"])==3
