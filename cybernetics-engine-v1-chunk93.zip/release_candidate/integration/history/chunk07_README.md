# Cybernetics Trading Engine — Chunk 7

Futures contract/state foundation.

Adds:
- ContractSpec with lot size, tick size, multiplier and expiry
- ContractSelector over a prevalidated instrument master
- Futures quote validation and isolated per-security state
- OI/volume deltas and basis tracking
- Notional, tick-value and MTM analytics
- Bid/ask spread validation

This chunk is analytics/state only. It does not submit or cancel broker orders.

## Validation

```bash
python tests/test_chunk7.py
python -m compileall cybernetics
```
