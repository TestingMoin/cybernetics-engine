from __future__ import annotations

from fastapi import Depends, FastAPI, Header, HTTPException

from app.control.state import ControlPlane


control = ControlPlane()
app = FastAPI(title="Cybernetics Trading Engine Control API", version="0.1.0")


def auth(x_control_token: str | None = Header(default=None)) -> str:
    # Token validation is injected by main.py in production; never expose this API publicly.
    expected = __import__("os").getenv("CONTROL_API_TOKEN", "")
    if not expected or x_control_token != expected:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return "api"


@app.get("/health")
def health() -> dict:
    return {"ok": True, "service": "cybernetics-control-api"}


@app.get("/state", dependencies=[Depends(auth)])
def state() -> dict:
    return control.snapshot().__dict__


@app.post("/engine/start", dependencies=[Depends(auth)])
def start() -> dict:
    return control.start_engine("api").__dict__


@app.post("/engine/stop", dependencies=[Depends(auth)])
def stop() -> dict:
    return control.stop_engine("api").__dict__


@app.post("/live/enable", dependencies=[Depends(auth)])
def enable_live() -> dict:
    return control.enable_live("api").__dict__


@app.post("/live/disable", dependencies=[Depends(auth)])
def disable_live() -> dict:
    return control.disable_live("api").__dict__


@app.post("/kill-switch", dependencies=[Depends(auth)])
def kill_switch() -> dict:
    return control.activate_kill_switch("api").__dict__


@app.post("/emergency-stop", dependencies=[Depends(auth)])
def emergency_stop() -> dict:
    return control.emergency_stop_now("api").__dict__
