from __future__ import annotations
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class SizingRequest:
    capital: float
    risk_fraction: float
    price: float
    stop_price: float
    lot_size: int
    available_margin: float
    margin_per_lot: float
    max_lots: int

def size_by_stop_risk(req: SizingRequest) -> int:
    if min(req.capital, req.price, req.stop_price, req.margin_per_lot) <= 0:
        return 0
    if req.lot_size <= 0 or req.max_lots <= 0:
        return 0
    if not 0 < req.risk_fraction <= 1:
        return 0
    per_unit_risk = abs(req.price-req.stop_price)
    risk_budget = req.capital * req.risk_fraction
    lots_by_risk = math.floor(risk_budget / (per_unit_risk * req.lot_size))
    lots_by_margin = math.floor(req.available_margin / req.margin_per_lot)
    lots=max(0, min(lots_by_risk, lots_by_margin, req.max_lots))
    return lots * req.lot_size
