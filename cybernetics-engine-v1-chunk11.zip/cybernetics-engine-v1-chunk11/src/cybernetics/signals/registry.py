from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Literal
import time, uuid

Side = Literal["LONG","SHORT","NEUTRAL"]

@dataclass(frozen=True)
class SignalContext:
    signal_id: str
    timestamp: float
    exchange: str
    scanner_id: str
    instrument: str
    underlying: str
    timeframe: str
    side: Side
    source: str
    score: float
    confidence: float
    regime: str | None = None
    evidence: tuple[str, ...] = ()
    invalidations: tuple[str, ...] = ()
    ttl_seconds: float = 60.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def expires_at(self) -> float:
        return self.timestamp + self.ttl_seconds

    def is_expired(self, now: float | None = None) -> bool:
        return (time.time() if now is None else now) >= self.expires_at

class SignalRegistry:
    def __init__(self, max_signals_per_key: int = 100):
        self._signals: dict[str, list[SignalContext]] = {}
        self.max_signals_per_key = max_signals_per_key

    def publish(self, signal: SignalContext) -> None:
        key = f"{signal.exchange}:{signal.scanner_id}:{signal.instrument}"
        bucket = self._signals.setdefault(key, [])
        bucket.append(signal)
        if len(bucket) > self.max_signals_per_key:
            del bucket[:-self.max_signals_per_key]

    def recent(self, exchange: str, scanner_id: str, instrument: str,
               now: float | None = None) -> list[SignalContext]:
        key = f"{exchange}:{scanner_id}:{instrument}"
        current = time.time() if now is None else now
        return [s for s in self._signals.get(key, []) if not s.is_expired(current)]

    def clear_expired(self, now: float | None = None) -> int:
        current = time.time() if now is None else now
        removed = 0
        for key in list(self._signals):
            before = len(self._signals[key])
            self._signals[key] = [s for s in self._signals[key] if not s.is_expired(current)]
            removed += before - len(self._signals[key])
            if not self._signals[key]:
                del self._signals[key]
        return removed

    def count(self) -> int:
        return sum(len(v) for v in self._signals.values())

def make_signal(**kwargs: Any) -> SignalContext:
    kwargs = dict(kwargs)
    kwargs.setdefault("timestamp", time.time())
    kwargs.setdefault("signal_id", str(uuid.uuid4()))
    return SignalContext(**kwargs)
