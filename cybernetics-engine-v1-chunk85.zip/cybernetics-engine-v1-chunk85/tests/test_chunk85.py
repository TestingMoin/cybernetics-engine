import asyncio
from datetime import datetime, timedelta, timezone

from cybernetics.websocket.subscriptions import (
    SubscriptionManager, SubscriptionMode, Instrument
)
from cybernetics.feed_supervisor.sharder import FeedSharder
from cybernetics.feed_supervisor.health import FeedHealthMonitor, FeedHealthState
from cybernetics.feed_supervisor.supervisor import FeedSupervisor


def instruments(n):
    return [Instrument("NSE_FNO", str(i)) for i in range(n)]


def test_subscription_chunking_uses_100():
    s=SubscriptionManager()
    s.set_desired(SubscriptionMode.FULL, instruments(205))
    msgs=s.messages(SubscriptionMode.FULL)
    assert [m["InstrumentCount"] for m in msgs]==[100,100,5]
    assert all(m["RequestCode"]==21 for m in msgs)


def test_unsubscribe_uses_correct_code():
    s=SubscriptionManager()
    s.set_desired(SubscriptionMode.QUOTE, instruments(2))
    assert s.messages(SubscriptionMode.QUOTE, subscribe=False)[0]["RequestCode"]==18


def test_connection_limit_is_5000():
    s=SubscriptionManager()
    s.set_desired(SubscriptionMode.TICKER, instruments(5000))
    try:
        s.add(SubscriptionMode.TICKER,[Instrument("NSE_FNO","5001")])
        assert False
    except ValueError as exc:
        assert str(exc)=="connection_instrument_limit_exceeded"


def test_subscription_state_add_remove():
    s=SubscriptionManager()
    one=Instrument("NSE_FNO","1")
    two=Instrument("NSE_FNO","2")
    s.add(SubscriptionMode.TICKER,[one,two])
    assert s.desired(SubscriptionMode.TICKER)=={one,two}
    s.remove(SubscriptionMode.TICKER,[one])
    assert s.desired(SubscriptionMode.TICKER)=={two}


def test_sorted_messages_are_deterministic():
    s1=SubscriptionManager()
    s2=SubscriptionManager()
    items=[Instrument("NSE_FNO",str(i)) for i in [4,1,3,2]]
    s1.set_desired(SubscriptionMode.FULL,items)
    s2.set_desired(SubscriptionMode.FULL,list(reversed(items)))
    assert s1.messages(SubscriptionMode.FULL)==s2.messages(SubscriptionMode.FULL)


def test_sharder_works_with_canonical_instrument():
    shards=FeedSharder().shard(instruments(5100))
    assert len(shards)==2
    assert [len(x.instruments) for x in shards]==[2550,2550]


def test_sharder_rejects_capacity_over_25000():
    try:
        FeedSharder().shard(instruments(25001))
        assert False
    except ValueError as exc:
        assert str(exc)=="universe_exceeds_feed_capacity"


def test_sharder_is_deterministic():
    s=FeedSharder(max_connections=3,per_connection_limit=4)
    assert s.shard(instruments(9))==s.shard(instruments(9))


def test_health_monitor_detects_stale():
    m=FeedHealthMonitor(stale_after=timedelta(seconds=10))
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    m.connected(1,t)
    m.received(1,t)
    assert m.evaluate(t+timedelta(seconds=11))[1] is FeedHealthState.STALE


def test_supervisor_needs_healthy_feed():
    s=FeedSupervisor(FeedSharder(max_connections=2,per_connection_limit=10))
    s.assign(instruments(12),SubscriptionMode.FULL)
    assert s.safe_for_market_state() is False
    for shard in s.assignment.shards:
        t=datetime.now(timezone.utc)
        s.health.connected(shard.shard_id,t)
        s.health.received(shard.shard_id,t)
    assert s.safe_for_market_state() is True


def test_supervisor_generation_changes_on_assignment():
    s=FeedSupervisor()
    a=s.assign(instruments(2))
    b=s.assign(instruments(3))
    assert b.generation==a.generation+1


def test_modes_have_all_dhan_codes():
    s=SubscriptionManager()
    s.set_desired(SubscriptionMode.TICKER,[Instrument("NSE_FNO","1")])
    s.set_desired(SubscriptionMode.QUOTE,[Instrument("NSE_FNO","1")])
    s.set_desired(SubscriptionMode.FULL,[Instrument("NSE_FNO","1")])
    assert [s.messages(m)[0]["RequestCode"] for m in SubscriptionMode]==[15,17,21]


def test_unsubscribe_codes_are_all_distinct():
    s=SubscriptionManager()
    for mode in SubscriptionMode:
        s.set_desired(mode,[Instrument("NSE_FNO","1")])
    assert [s.messages(m,subscribe=False)[0]["RequestCode"] for m in SubscriptionMode]==[16,18,22]


def test_canonical_module_exposes_manager_required_by_chunk32():
    assert hasattr(__import__(
        "cybernetics.websocket.subscriptions",
        fromlist=["SubscriptionManager"]
    ),"SubscriptionManager")


def test_feed_supervisor_consumes_same_instrument_type():
    i=Instrument("BSE_FNO","99")
    shards=FeedSharder().shard([i])
    assert shards[0].instruments==(i,)


def test_duplicate_instruments_do_not_duplicate_subscription_messages():
    s=SubscriptionManager()
    i=Instrument("NSE_FNO","1")
    s.set_desired(SubscriptionMode.FULL,[i,i,i])
    assert s.messages(SubscriptionMode.FULL)[0]["InstrumentCount"]==1


def test_invalid_large_subscription_is_blocked_before_messages():
    s=SubscriptionManager()
    try:
        s.set_desired(SubscriptionMode.FULL,instruments(5001))
        assert False
    except ValueError:
        assert s.messages(SubscriptionMode.FULL)==[]


def test_no_order_execution_endpoint():
    from pathlib import Path
    for p in Path("src/cybernetics").rglob("*.py"):
        src=p.read_text()
        assert "/v2/orders" not in src
        assert "place_order(" not in src
