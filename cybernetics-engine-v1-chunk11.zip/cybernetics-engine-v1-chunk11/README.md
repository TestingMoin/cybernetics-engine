# Cybernetics Trading Engine — Chunk 11

Deterministic Signal Registry + Signal Gateway.

A signal is intelligence, not an order. The registry records isolated, short-lived
signal contexts. The gateway validates identity, score, confidence and TTL.
No broker execution capability is exposed.
