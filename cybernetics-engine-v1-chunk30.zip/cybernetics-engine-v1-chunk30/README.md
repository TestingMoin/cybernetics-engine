# Cybernetics Trading Engine — Chunk 30

## Dhan REST Transport + Rate-Limit Governor + Retry/Backoff

This chunk creates the common REST transport layer used by the Dhan adapters.

### Dhan V2 rate budgets encoded from current official documentation
- Order APIs: 10/sec, 250/min, 1000/hour, 7000/day.
- Data APIs: 5/sec, 100000/day.
- Quote APIs: 1/sec.
- Non-trading APIs: 20/sec.

The governor uses sliding-window admission control.

### Retry safety

Retries are opt-in with `retry_safe=True`.

This is deliberate: a non-idempotent order submission must not be automatically
retried after a timeout merely because the HTTP request failed. Chunk 27's UNKNOWN
reconciliation and Chunk 25/26 idempotency layers remain responsible for ambiguous
order outcomes.

The token provider is called for each request attempt so the transport can use the
current valid access token.

No credentials are stored in this chunk.
