from dataclasses import dataclass
from enum import Enum
class IndicatorTier(str,Enum):
 CORE="CORE";ADVANCED="ADVANCED";RESEARCH="RESEARCH"
@dataclass(frozen=True)
class IndicatorSpec:
 indicator_id:str;version:str;family:str;tier:IndicatorTier;compute:object;description:str=""
class IndicatorRegistry:
 def __init__(self): self._items={}
 def register(self,s):
  if s.indicator_id in self._items: raise ValueError("indicator_already_registered")
  self._items[s.indicator_id]=s
 def get(self,i): return self._items[i]
 def all(self): return list(self._items.values())
