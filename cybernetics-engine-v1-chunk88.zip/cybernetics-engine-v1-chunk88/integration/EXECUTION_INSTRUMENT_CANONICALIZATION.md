# Chunk 88 — Execution Instrument Interface Reconciliation

## Conflict reviewed

The unified candidate reported `execution.instrument` as a conflicting path
between Chunk 54 and Chunk 55.

### Chunk 54
Provides the complete instrument contract:
- InstrumentType
- OptionType
- InstrumentEligibility
- TradeInstrument
- InstrumentSelectionRequest
- InstrumentSelector

### Chunk 55
Contains a compressed copy of:
- InstrumentType
- OptionType
- InstrumentEligibility
- TradeInstrument

It intentionally does not contain the selection boundary.

## Canonical decision

Chunk 54 is the canonical `cybernetics.execution.instrument` contract.

Chunk 55's repeated model definitions are not promoted as a second owner of
the module path. The execution-binding functionality from Chunk 55 must consume
the canonical Chunk 54 models.

This preserves:
- one definition of contract identity
- production-eligibility enforcement
- exact candidate matching
- ambiguous-selection rejection
- no security-ID invention

No broker order placement is introduced.
