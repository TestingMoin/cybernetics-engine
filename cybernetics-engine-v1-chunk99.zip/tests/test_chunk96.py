from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def test_packaged_schema_resource_is_readable() -> None:
    from cybernetics.db.schema import schema_path, schema_sql

    text = schema_sql()
    assert "CREATE TABLE IF NOT EXISTS orders" in text
    assert schema_path().name == "schema.sql"


def test_all_schema_consumers_use_shared_resolver() -> None:
    root = Path("src/cybernetics")
    targets = [
        root / "control/emergency_repository.py",
        root / "control/migration.py",
        root / "persistence/outbox.py",
        root / "persistence/migration.py",
        root / "persistence/fill_ledger.py",
    ]
    for path in targets:
        text = path.read_text()
        assert "from cybernetics.db.schema import schema_path" in text
        assert "parents[3] / \"sql\" / \"schema.sql\"" not in text


def test_package_cli_self_check() -> None:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(Path("src").resolve())
    result = subprocess.run(
        [sys.executable, "-m", "cybernetics", "--self-check"],
        capture_output=True,
        text=True,
        check=True,
        env=env,
    )
    assert '"new_trades_allowed": false' in result.stdout
