import json
import logging
from pathlib import Path

from cybernetics.runtime.logging import JsonFormatter, RuntimeLoggingConfig, configure_runtime_logging


def _record(message="hello", **kwargs):
    logger = logging.getLogger("test-record")
    return logger.makeRecord(logger.name, logging.INFO, __file__, 1, message, (), None, extra={"audit": kwargs})


def test_json_formatter_redacts_sensitive_values():
    text = JsonFormatter().format(_record(access_token="secret", symbol="NIFTY", nested={"api_secret": "x"}))
    payload = json.loads(text)
    assert payload["audit"]["access_token"] == "[REDACTED]"
    assert payload["audit"]["nested"]["api_secret"] == "[REDACTED]"
    assert payload["audit"]["symbol"] == "NIFTY"


def test_configure_runtime_logging_is_repeatable_and_writes_rotating_file(tmp_path: Path):
    target = tmp_path / "runtime.log"
    logger = configure_runtime_logging(RuntimeLoggingConfig(log_file=str(target), max_bytes=256, backup_count=1))
    logger.info("first", extra={"audit": {"pin": "1234"}})
    configure_runtime_logging(RuntimeLoggingConfig(log_file=str(target), max_bytes=256, backup_count=1))
    logging.getLogger("cybernetics").info("second")
    assert target.exists()
    content = target.read_text(encoding="utf-8")
    assert "1234" not in content
    assert '"message": "second"' in content


def test_logging_config_rejects_invalid_sizes():
    try:
        RuntimeLoggingConfig(max_bytes=0)
        assert False
    except ValueError as exc:
        assert str(exc) == "max_bytes_must_be_positive"
