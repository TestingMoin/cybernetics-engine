from cybernetics.execution.coordinator import ExecutionCoordinator, ExecutionContext
from cybernetics.execution.pipeline import ExecutionPipeline
from cybernetics.brokers.interface import BrokerAdapter, BrokerOrderRequest, BrokerOrderResult
from cybernetics.brokers.router import BrokerRoute, MultiBrokerRouter

class FakeBroker(BrokerAdapter):
    name = "FAKE"
    def health(self): return {"ok": True}
    def get_positions(self): return []
    def get_orders(self): return []
    def place_order(self, request):
        return BrokerOrderResult(self.name, True, "FAKE-1", "ACCEPTED")
    def cancel_order(self, broker_order_id):
        return BrokerOrderResult(self.name, True, broker_order_id, "CANCELLED")

def ctx(**overrides):
    d=dict(engine_running=True, live_authorized=True, emergency_stop=False,
           risk_approved=True, pretrade_approved=True,
           reconciliation_ok=True, broker_available=True)
    d.update(overrides)
    return ExecutionContext(**d)

def order():
    return BrokerOrderRequest("NIFTY", "BUY", 50, "MARKET")

def pipe(enabled=True):
    r=MultiBrokerRouter()
    r.register(BrokerRoute("fake", "FAKE", FakeBroker(), enabled))
    return ExecutionPipeline(ExecutionCoordinator(), r)

def test_all_gates_pass():
    out=pipe().execute(ctx(), "fake", order())
    assert out.executed is True
    assert out.broker_result.broker_order_id == "FAKE-1"

def test_live_authorization_blocks():
    out=pipe().execute(ctx(live_authorized=False), "fake", order())
    assert out.reason == "live_not_authorized"

def test_emergency_stop_blocks_first():
    out=pipe().execute(ctx(emergency_stop=True), "fake", order())
    assert out.reason == "emergency_stop_active"

def test_risk_blocks():
    out=pipe().execute(ctx(risk_approved=False), "fake", order())
    assert out.reason == "risk_rejected"

def test_reconciliation_blocks():
    out=pipe().execute(ctx(reconciliation_ok=False), "fake", order())
    assert out.reason == "reconciliation_not_ok"

def test_disabled_route_blocks():
    out=pipe(enabled=False).execute(ctx(), "fake", order())
    assert out.executed is False and out.status == "BLOCKED"
