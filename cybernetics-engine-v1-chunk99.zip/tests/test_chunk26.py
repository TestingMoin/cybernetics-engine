from cybernetics.order_management.idempotency import IdempotencyRecord, IdempotencyStore
from cybernetics.persistence.memory_ledger import InMemoryOrderLedger
from cybernetics.persistence.postgres_ledger import PostgresOrderLedger

def rec(k="K1", bid="B1", status="ACCEPTED"):
    return IdempotencyRecord(k, bid, status)

def test_store_survives_facade_recreation_when_backend_is_shared():
    backend = InMemoryOrderLedger()
    IdempotencyStore(backend).put_once(rec())
    second = IdempotencyStore(backend)
    assert second.get("K1").broker_order_id == "B1"
    assert second.put_once(rec()) is False

def test_memory_backend_update():
    backend = InMemoryOrderLedger()
    s = IdempotencyStore(backend)
    assert s.put_once(rec("K2", None, "UNKNOWN"))
    s.update(rec("K2", "B2", "ACCEPTED"))
    assert s.get("K2").broker_order_id == "B2"

def test_postgres_insert_sql_is_unique_key_safe():
    assert "ON CONFLICT (client_order_key) DO NOTHING" in PostgresOrderLedger.UPSERT_SQL

def test_postgres_select_targets_client_key():
    assert "WHERE client_order_key = %s" in PostgresOrderLedger.SELECT_SQL

def test_postgres_update_requires_existing_key():
    assert "WHERE client_order_key = %s" in PostgresOrderLedger.UPDATE_SQL

def test_schema_adds_unique_client_key_index():
    schema=(__import__("pathlib").Path(__file__).parents[1]/"src/cybernetics/persistence/schema.sql").read_text()
    assert "ux_orders_client_order_key" in schema
    assert "UNIQUE INDEX" in schema
