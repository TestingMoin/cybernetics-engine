import pytest

from cybernetics.runtime.dependencies import REQUIRED_RUNTIME_DEPENDENCIES, RuntimeDependencyBundle
from cybernetics.runtime.full_readiness import RuntimeCoreState, evaluate_full_runtime_readiness
from cybernetics.runtime.state import ControlState, EmergencyState, EngineMode


class Probe:
    def __init__(self, value=True):
        self.value = value


def make_bundle(value=True):
    components = {name: Probe(value) for name in REQUIRED_RUNTIME_DEPENDENCIES}
    probes = {name: (lambda obj: obj.value) for name in REQUIRED_RUNTIME_DEPENDENCIES}
    return RuntimeDependencyBundle.from_components(
        persistence=components["persistence"], recovery=components["recovery"],
        market_data=components["market_data"], scanners=components["scanners"],
        watchdog=components["watchdog"], control=components["control"], broker=components["broker"],
        readiness=probes,
    ), components


def ready_core(live=True):
    return RuntimeCoreState(
        engine_mode=EngineMode.RUNNING,
        control_state=ControlState.RUNNING,
        emergency_state=EmergencyState.CLEAR,
        orders_reconciled=True,
        positions_reconciled=True,
        live_authorization_valid=live,
    )


def test_all_gates_ready_produces_engine_ready_and_live_authorization_controls_entries():
    deps, _ = make_bundle(True)
    result = evaluate_full_runtime_readiness(deps, ready_core(True))
    assert result.readiness.engine_ready is True
    assert result.readiness.new_trades_allowed is True
    assert all(result.dependency_readiness.values())


def test_paper_like_core_remains_engine_ready_but_blocks_entries_when_live_auth_invalid():
    deps, _ = make_bundle(True)
    result = evaluate_full_runtime_readiness(deps, ready_core(False))
    assert result.readiness.engine_ready is True
    assert result.readiness.new_trades_allowed is False
    assert "live_authorization_invalid" in result.readiness.reasons


def test_each_critical_dependency_failure_blocks_engine_readiness():
    for dependency_name in tuple(name for name in REQUIRED_RUNTIME_DEPENDENCIES if name != "control"):
        deps, components = make_bundle(True)
        components[dependency_name].value = False
        result = evaluate_full_runtime_readiness(deps, ready_core(True))
        assert result.readiness.engine_ready is False
        assert result.dependency_readiness[dependency_name] is False


def test_emergency_stop_blocks_entries_even_when_every_dependency_is_ready():
    deps, _ = make_bundle(True)
    core = RuntimeCoreState(
        engine_mode=EngineMode.RUNNING,
        control_state=ControlState.EMERGENCY_STOP,
        emergency_state=EmergencyState.ACTIVE,
        orders_reconciled=True,
        positions_reconciled=True,
        live_authorization_valid=True,
    )
    result = evaluate_full_runtime_readiness(deps, core)
    assert result.readiness.engine_ready is True
    assert result.readiness.new_trades_allowed is False
    assert "emergency_stop_active" in result.readiness.reasons


def test_stop_new_trades_can_keep_engine_ready_but_blocks_entries():
    deps, _ = make_bundle(True)
    core = RuntimeCoreState(
        engine_mode=EngineMode.RUNNING,
        control_state=ControlState.STOP_NEW_TRADES,
        emergency_state=EmergencyState.CLEAR,
        orders_reconciled=True,
        positions_reconciled=True,
        live_authorization_valid=True,
    )
    result = evaluate_full_runtime_readiness(deps, core)
    assert result.readiness.engine_ready is True
    assert result.readiness.new_trades_allowed is False


def test_reconciliation_failure_is_a_core_readiness_gate():
    deps, _ = make_bundle(True)
    core = RuntimeCoreState(**{**ready_core(True).__dict__, "orders_reconciled": False})
    result = evaluate_full_runtime_readiness(deps, core)
    assert result.readiness.engine_ready is False
    assert "orders_not_reconciled" in result.readiness.reasons


def test_evaluation_is_side_effect_free_for_dependency_objects():
    deps, components = make_bundle(True)
    before = {name: obj.value for name, obj in components.items()}
    _ = evaluate_full_runtime_readiness(deps, ready_core(True))
    after = {name: obj.value for name, obj in components.items()}
    assert before == after


def test_dependency_probe_exception_fails_closed():
    components = {name: Probe(True) for name in REQUIRED_RUNTIME_DEPENDENCIES}
    probes = {name: (lambda obj: obj.value) for name in REQUIRED_RUNTIME_DEPENDENCIES}
    def broken(_):
        raise RuntimeError("probe failure")
    probes["watchdog"] = broken
    deps = RuntimeDependencyBundle.from_components(
        persistence=components["persistence"], recovery=components["recovery"],
        market_data=components["market_data"], scanners=components["scanners"],
        watchdog=components["watchdog"], control=components["control"], broker=components["broker"],
        readiness=probes,
    )
    with pytest.raises(RuntimeError):
        evaluate_full_runtime_readiness(deps, ready_core(True))
